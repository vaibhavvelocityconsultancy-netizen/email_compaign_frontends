globalThis.__nitro_main__ = import.meta.url;
import { i as serve, r as NodeResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
import { i as toEventHandler, n as defineHandler, o as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/api-DiNx14Dp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"22f6-yY9S0JiBcVcJdoMqEXhwJV1zg7s\"",
		"mtime": "2026-10-17T06:57:03.391Z",
		"size": 8950,
		"path": "../public/assets/api-DiNx14Dp.js"
	},
	"/assets/arrow-up-right-Dv0z1hcs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a7-88uls2dUVl1N9hLuhBGa5TdSg3c\"",
		"mtime": "2026-10-17T06:57:03.392Z",
		"size": 167,
		"path": "../public/assets/arrow-up-right-Dv0z1hcs.js"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-10-03T04:55:01.345Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/assets/AuthLayout-C7fLr7ki.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1976-wQUiCkD4Qocg+3KJDO4uhf34O8k\"",
		"mtime": "2026-10-17T06:57:03.380Z",
		"size": 6518,
		"path": "../public/assets/AuthLayout-C7fLr7ki.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"ae-hLVBrSrDdpIw3Xl0dJPRkupPepQ\"",
		"mtime": "2026-10-03T04:55:01.345Z",
		"size": 174,
		"path": "../public/robots.txt"
	},
	"/assets/button-D0UaAm5H.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7e6f-o9HWpHiwisQ0cxmAxZxmdkPssH8\"",
		"mtime": "2026-10-17T06:57:03.392Z",
		"size": 32367,
		"path": "../public/assets/button-D0UaAm5H.js"
	},
	"/assets/calendar-days-5GeYs19G.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ee-0gJ1SgnZ967G/JBPJXOGGHpoPVg\"",
		"mtime": "2026-10-17T06:57:03.392Z",
		"size": 494,
		"path": "../public/assets/calendar-days-5GeYs19G.js"
	},
	"/assets/company-api-DUECAcEi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"315-E3qJPVs9vv9db5fzBgo/x0JOMig\"",
		"mtime": "2026-10-17T06:57:03.393Z",
		"size": 789,
		"path": "../public/assets/company-api-DUECAcEi.js"
	},
	"/assets/company-BZB7QiCT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"294b-DCEYCAmvcUqn+lwWG2vcmNjJ5ww\"",
		"mtime": "2026-10-17T06:57:03.393Z",
		"size": 10571,
		"path": "../public/assets/company-BZB7QiCT.js"
	},
	"/assets/country-C4DJTpz-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"92-16RPpvOWmB2A2k1I/E+KUmnGe8s\"",
		"mtime": "2026-10-17T06:57:03.393Z",
		"size": 146,
		"path": "../public/assets/country-C4DJTpz-.js"
	},
	"/assets/createLucideIcon-5JRSLlvH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4ab-2zmdx9sedX9IguCpilqTmk8qozQ\"",
		"mtime": "2026-10-17T06:57:03.393Z",
		"size": 1195,
		"path": "../public/assets/createLucideIcon-5JRSLlvH.js"
	},
	"/assets/customer-po-Dm8_DBXm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3309-xRUJuhnI/M9OobLtPvhIHpiwmRs\"",
		"mtime": "2026-10-17T06:57:03.393Z",
		"size": 13065,
		"path": "../public/assets/customer-po-Dm8_DBXm.js"
	},
	"/assets/dashboard-Bs6etAPD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2615-AiyHfEYZBg1AyxfcQCykyJC6l5o\"",
		"mtime": "2026-10-17T06:57:03.394Z",
		"size": 9749,
		"path": "../public/assets/dashboard-Bs6etAPD.js"
	},
	"/assets/dist-DYAUkNtW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12ac-BExCN2P/yQD5ISHqR+fzkG3tqJ4\"",
		"mtime": "2026-10-17T06:57:03.394Z",
		"size": 4780,
		"path": "../public/assets/dist-DYAUkNtW.js"
	},
	"/assets/DataTable-DGJqtzCb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3125e-Hhv+ywbgYQpDbK7zoSkUSVGYcUE\"",
		"mtime": "2026-10-17T06:57:03.381Z",
		"size": 201310,
		"path": "../public/assets/DataTable-DGJqtzCb.js"
	},
	"/assets/drawer-DhfOT8D-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"74d0-vVBZuuVieQ4/7MDdacxEkxu+ykk\"",
		"mtime": "2026-10-17T06:57:03.394Z",
		"size": 29904,
		"path": "../public/assets/drawer-DhfOT8D-.js"
	},
	"/assets/email-campaign-Y2LS2j8f.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"36e-wO4hRzwVzFzz7Q01RfROGUy00iQ\"",
		"mtime": "2026-10-17T06:57:03.394Z",
		"size": 878,
		"path": "../public/assets/email-campaign-Y2LS2j8f.js"
	},
	"/assets/email-campaign.campaigns-BjBrQIYE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"45d3-cSx6wTeXa9P+d2Y7Q/dABxTlZX0\"",
		"mtime": "2026-10-17T06:57:03.395Z",
		"size": 17875,
		"path": "../public/assets/email-campaign.campaigns-BjBrQIYE.js"
	},
	"/assets/email-campaign.logs-y2giOEv8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"97c-6nq5QLFg/Vg5kggrW4Ac4QsttLk\"",
		"mtime": "2026-10-17T06:57:03.395Z",
		"size": 2428,
		"path": "../public/assets/email-campaign.logs-y2giOEv8.js"
	},
	"/assets/email-campaign.sequences-PAMqYybu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2419-OomllQOMgrDgBZ7nUz3QSC0qRj0\"",
		"mtime": "2026-10-17T06:57:03.395Z",
		"size": 9241,
		"path": "../public/assets/email-campaign.sequences-PAMqYybu.js"
	},
	"/assets/email-campaign.templates-DsTl6vLq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ec5-zy9mjGoXox98b//OqMBOkkGUVkM\"",
		"mtime": "2026-10-17T06:57:03.396Z",
		"size": 7877,
		"path": "../public/assets/email-campaign.templates-DsTl6vLq.js"
	},
	"/assets/EmptyState-DDcb9rny.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"488-MMz196hHQkEJvDNQg8ibhv/PUZ4\"",
		"mtime": "2026-10-17T06:57:03.383Z",
		"size": 1160,
		"path": "../public/assets/EmptyState-DDcb9rny.js"
	},
	"/assets/eye-4pwqTTee.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"100-JNqbvsNOaTv7+BwwLZ9cpGPQV1s\"",
		"mtime": "2026-10-17T06:57:03.396Z",
		"size": 256,
		"path": "../public/assets/eye-4pwqTTee.js"
	},
	"/assets/file-text-CLhUqrtI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"181-DeFV4tXEJk1MdQaNxkP0mGeB0b8\"",
		"mtime": "2026-10-17T06:57:03.396Z",
		"size": 385,
		"path": "../public/assets/file-text-CLhUqrtI.js"
	},
	"/assets/EntityForm-bK7xVafJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11169-Z9rfH0Ycwqwq2oroOHuCp2D5H4I\"",
		"mtime": "2026-10-17T06:57:03.384Z",
		"size": 69993,
		"path": "../public/assets/EntityForm-bK7xVafJ.js"
	},
	"/assets/final-offer-0Q0UBFEN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"383b-f4DzUatBQCapLUNUeng5Qjy/R60\"",
		"mtime": "2026-10-17T06:57:03.397Z",
		"size": 14395,
		"path": "../public/assets/final-offer-0Q0UBFEN.js"
	},
	"/assets/form-D41_cX0T.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"465f-/9zzf1z+RCHz09VUU9zTwScGQg4\"",
		"mtime": "2026-10-17T06:57:03.397Z",
		"size": 18015,
		"path": "../public/assets/form-D41_cX0T.js"
	},
	"/assets/input-DoHRrl0J.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"269-Z37PxwpLdT0XoaiMbPHDKntH0xk\"",
		"mtime": "2026-10-17T06:57:03.397Z",
		"size": 617,
		"path": "../public/assets/input-DoHRrl0J.js"
	},
	"/assets/index-Cx2PLw8p.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"54a90-CqFFO75FvTrwqyU4+3mKx1r6tFE\"",
		"mtime": "2026-10-17T06:57:03.380Z",
		"size": 346768,
		"path": "../public/assets/index-Cx2PLw8p.js"
	},
	"/assets/jsx-runtime-OQpaS_Dv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e5d-QNoQHuwEkd4/8PZ1cKbcagI8N+0\"",
		"mtime": "2026-10-17T06:57:03.479Z",
		"size": 7773,
		"path": "../public/assets/jsx-runtime-OQpaS_Dv.js"
	},
	"/assets/leads-b_vHyq7d.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2073-pGTFrybR5RAIOne5A4RM+iW//1U\"",
		"mtime": "2026-10-17T06:57:03.552Z",
		"size": 8307,
		"path": "../public/assets/leads-b_vHyq7d.js"
	},
	"/assets/leads.form-DDzMQCHI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"463c-4zIivmeYpWY7P9ueSHzYfYBUrFM\"",
		"mtime": "2026-10-17T06:57:03.631Z",
		"size": 17980,
		"path": "../public/assets/leads.form-DDzMQCHI.js"
	},
	"/assets/link-CAl-Sa9v.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"17db-UaB2qKISyQ7zDYJuk87eq+59s5A\"",
		"mtime": "2026-10-17T06:57:03.656Z",
		"size": 6107,
		"path": "../public/assets/link-CAl-Sa9v.js"
	},
	"/assets/location-FSVxxy91.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b3b-LpYghIO3XNu5EzXD8b+lfbW8gKk\"",
		"mtime": "2026-10-17T06:57:03.666Z",
		"size": 6971,
		"path": "../public/assets/location-FSVxxy91.js"
	},
	"/assets/login-DDn0c4JO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"661-E7MoQE2KPdZkCntsLRwOiPgJ4dw\"",
		"mtime": "2026-10-17T06:57:03.666Z",
		"size": 1633,
		"path": "../public/assets/login-DDn0c4JO.js"
	},
	"/assets/marketing-Dir4KQHG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12f0-gx2723kcvBb+muWcafXShkdGyUY\"",
		"mtime": "2026-10-17T06:57:03.669Z",
		"size": 4848,
		"path": "../public/assets/marketing-Dir4KQHG.js"
	},
	"/assets/Match-5cQgR4sj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11a3-AZ+3Iyuz/y/s1dlAyWexMt/oCXk\"",
		"mtime": "2026-10-17T06:57:03.386Z",
		"size": 4515,
		"path": "../public/assets/Match-5cQgR4sj.js"
	},
	"/assets/matchContext-BLd14XSO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a2-Q9zaBz1LZIT8wotslK/zBebTFRQ\"",
		"mtime": "2026-10-17T06:57:03.671Z",
		"size": 162,
		"path": "../public/assets/matchContext-BLd14XSO.js"
	},
	"/assets/Modal-BZsGyKA9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"501-vgwcTW6YiVCexnZBgtRh2JrcaW8\"",
		"mtime": "2026-10-17T06:57:03.389Z",
		"size": 1281,
		"path": "../public/assets/Modal-BZsGyKA9.js"
	},
	"/assets/opportunities-Dhce4-d3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"448f-OPCyCdAiOmx1sTBGZpN9G7mO2kc\"",
		"mtime": "2026-10-17T06:57:03.671Z",
		"size": 17551,
		"path": "../public/assets/opportunities-Dhce4-d3.js"
	},
	"/assets/orders-BDLz9lUh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3182-0CReDGyBYV8VIlJ18j37VVoRs9o\"",
		"mtime": "2026-10-17T06:57:03.674Z",
		"size": 12674,
		"path": "../public/assets/orders-BDLz9lUh.js"
	},
	"/assets/order-dashboard-BpUTFLdY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5b8c7-7kKvJEJ4SPHgdVnuFX3Jxjz5m14\"",
		"mtime": "2026-10-17T06:57:03.673Z",
		"size": 374983,
		"path": "../public/assets/order-dashboard-BpUTFLdY.js"
	},
	"/assets/quotation-api-BzTvprZm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"176b-v+luZQnEF6O3/meNzB9+ICjNsvE\"",
		"mtime": "2026-10-17T06:57:03.676Z",
		"size": 5995,
		"path": "../public/assets/quotation-api-BzTvprZm.js"
	},
	"/assets/preload-helper-ChS5vP1f.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14b6-5pN2F/gz7jwue2SaYwdR+azX9Jw\"",
		"mtime": "2026-10-17T06:57:03.675Z",
		"size": 5302,
		"path": "../public/assets/preload-helper-ChS5vP1f.js"
	},
	"/assets/quotations-B5YaAGbc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5512-6dDngT+WGHbmgOrJDvHAvWETmZ8\"",
		"mtime": "2026-10-17T06:57:03.677Z",
		"size": 21778,
		"path": "../public/assets/quotations-B5YaAGbc.js"
	},
	"/assets/react-dom-Ch54GZ4s.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"20612-+DvTnf28xFOri7WU17yiDHFJqcc\"",
		"mtime": "2026-10-17T06:57:03.678Z",
		"size": 132626,
		"path": "../public/assets/react-dom-Ch54GZ4s.js"
	},
	"/assets/register-JHeGc40T.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a8a-vSBQnCnY1phxiTrjnGBW/PnfvPs\"",
		"mtime": "2026-10-17T06:57:03.679Z",
		"size": 2698,
		"path": "../public/assets/register-JHeGc40T.js"
	},
	"/assets/routes-ecovh3Ym.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b16-E+NxISqXt4AmR4h3BH04SuWU+uc\"",
		"mtime": "2026-10-17T06:57:03.735Z",
		"size": 2838,
		"path": "../public/assets/routes-ecovh3Ym.js"
	},
	"/assets/sales-DLPnmiQo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ad9-axH+KKO3rLJ3M56P8QEBFdXrV7I\"",
		"mtime": "2026-10-17T06:57:03.769Z",
		"size": 2777,
		"path": "../public/assets/sales-DLPnmiQo.js"
	},
	"/assets/save-CK_SGmB_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b7-pK8W1jFwv17lXTHkPFzxuMYFFJo\"",
		"mtime": "2026-10-17T06:57:03.772Z",
		"size": 439,
		"path": "../public/assets/save-CK_SGmB_.js"
	},
	"/assets/shopping-cart-DWwt8raz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"124-J67nHP5w/JXe66D/liMVBGY+YxU\"",
		"mtime": "2026-10-17T06:57:03.779Z",
		"size": 292,
		"path": "../public/assets/shopping-cart-DWwt8raz.js"
	},
	"/assets/StatCard-Ef07sW3W.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"252-9C6VNeWJ0/pLgsAbULCA2/Pp4MY\"",
		"mtime": "2026-10-17T06:57:03.389Z",
		"size": 594,
		"path": "../public/assets/StatCard-Ef07sW3W.js"
	},
	"/assets/StatusBadge-CxXEaw6p.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8bb-fPkXLfFUQP3n9v+pCeeLNqmWAwI\"",
		"mtime": "2026-10-17T06:57:03.390Z",
		"size": 2235,
		"path": "../public/assets/StatusBadge-CxXEaw6p.js"
	},
	"/assets/tabs-lUnYi1fc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dc7-QHHuXQfLedghMfnTKKwC7lKHBSw\"",
		"mtime": "2026-10-17T06:57:03.780Z",
		"size": 3527,
		"path": "../public/assets/tabs-lUnYi1fc.js"
	},
	"/assets/target-BOizoJuW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e2-MPvNTPxILto0pNiyXc+q/bNTxxw\"",
		"mtime": "2026-10-17T06:57:03.780Z",
		"size": 226,
		"path": "../public/assets/target-BOizoJuW.js"
	},
	"/assets/styles-Cf1aBGSh.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"1a4c0-Bv43DOKiSMq4/4zguq+D1x4Euqw\"",
		"mtime": "2026-10-17T06:57:03.841Z",
		"size": 107712,
		"path": "../public/assets/styles-Cf1aBGSh.css"
	},
	"/assets/tasks-OfWf9uOh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9a-OftQilAhsZEdfcVhZTY823+CUak\"",
		"mtime": "2026-10-17T06:57:03.780Z",
		"size": 154,
		"path": "../public/assets/tasks-OfWf9uOh.js"
	},
	"/assets/textarea-CY-dYm-r.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"203-a/hVfN4kZqdJhYWIX5BZMIRfrxA\"",
		"mtime": "2026-10-17T06:57:03.781Z",
		"size": 515,
		"path": "../public/assets/textarea-CY-dYm-r.js"
	},
	"/assets/triangle-alert-DsgdhYG4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"109-0xifL1ZKE/b+T32ezWrkIY1Yhsw\"",
		"mtime": "2026-10-17T06:57:03.781Z",
		"size": 265,
		"path": "../public/assets/triangle-alert-DsgdhYG4.js"
	},
	"/assets/types-CTeloYrU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dd0b-zsIg22ZdoXTAbzfv4J68hdh5pGc\"",
		"mtime": "2026-10-17T06:57:03.782Z",
		"size": 56587,
		"path": "../public/assets/types-CTeloYrU.js"
	},
	"/assets/useMatch-BaG-rLLV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"293-KExcr+4gY6Q9OHGlMyrzORv35Q0\"",
		"mtime": "2026-10-17T06:57:03.783Z",
		"size": 659,
		"path": "../public/assets/useMatch-BaG-rLLV.js"
	},
	"/assets/upload-CDjpU4YU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e6-qGJnU3dS/CcSjNF8tj4xH91LHfI\"",
		"mtime": "2026-10-17T06:57:03.783Z",
		"size": 230,
		"path": "../public/assets/upload-CDjpU4YU.js"
	},
	"/assets/useMutation-BT3iAFGa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1653-nNjx+xxahBncS6DWiQhSiKAwdb8\"",
		"mtime": "2026-10-17T06:57:03.783Z",
		"size": 5715,
		"path": "../public/assets/useMutation-BT3iAFGa.js"
	},
	"/assets/useNavigate-bMnaDzZT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e4-1WK6EHg77rU10hmcsan8jPuS534\"",
		"mtime": "2026-10-17T06:57:03.784Z",
		"size": 228,
		"path": "../public/assets/useNavigate-bMnaDzZT.js"
	},
	"/assets/useQuery-CRu0Hu6y.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"58ac-bqCQwjC2vq+w1I9Qe1m9VfieSyQ\"",
		"mtime": "2026-10-17T06:57:03.784Z",
		"size": 22700,
		"path": "../public/assets/useQuery-CRu0Hu6y.js"
	},
	"/assets/useRouter-FQeUpUVO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"97-B2HdYDV0WostxfIdUG9o6g8suBg\"",
		"mtime": "2026-10-17T06:57:03.784Z",
		"size": 151,
		"path": "../public/assets/useRouter-FQeUpUVO.js"
	},
	"/assets/useSelector-yWwUHw1M.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"839-Ino2rjLR00dlXcbqKgOSMMsQVxE\"",
		"mtime": "2026-10-17T06:57:03.820Z",
		"size": 2105,
		"path": "../public/assets/useSelector-yWwUHw1M.js"
	},
	"/assets/utils-DCvbpOtd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cb5-ddQe7nge4rkeuEehVJsFEDF3H9s\"",
		"mtime": "2026-10-17T06:57:03.840Z",
		"size": 3253,
		"path": "../public/assets/utils-DCvbpOtd.js"
	},
	"/assets/x-DFhNn4Ci.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9a-+N4AK71+X/v/1PnljiX9CCPZgs8\"",
		"mtime": "2026-10-17T06:57:03.840Z",
		"size": 154,
		"path": "../public/assets/x-DFhNn4Ci.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_NiyQIL = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_NiyQIL
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
