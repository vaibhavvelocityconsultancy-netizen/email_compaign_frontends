globalThis.__nitro_main__ = import.meta.url;
import { i as serve, r as NodeResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
import { i as toEventHandler, n as defineHandler, o as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-09-30T09:41:24.623Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/assets/api-reO6B3FC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"275a-dHTVhtqPhjYiKeUbt2FNhxCYNh0\"",
		"mtime": "2026-10-22T06:37:18.408Z",
		"size": 10074,
		"path": "../public/assets/api-reO6B3FC.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-09-30T09:41:24.624Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/arrow-up-right-Dv0z1hcs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a7-88uls2dUVl1N9hLuhBGa5TdSg3c\"",
		"mtime": "2026-10-22T06:37:18.408Z",
		"size": 167,
		"path": "../public/assets/arrow-up-right-Dv0z1hcs.js"
	},
	"/assets/AuthLayout-DaElTGrl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1976-pVSfdy/zLnsjapAMoQURwXrrEQE\"",
		"mtime": "2026-10-22T06:37:18.400Z",
		"size": 6518,
		"path": "../public/assets/AuthLayout-DaElTGrl.js"
	},
	"/assets/button-D0UaAm5H.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7e6f-o9HWpHiwisQ0cxmAxZxmdkPssH8\"",
		"mtime": "2026-10-22T06:37:18.409Z",
		"size": 32367,
		"path": "../public/assets/button-D0UaAm5H.js"
	},
	"/assets/calendar-days-5GeYs19G.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ee-0gJ1SgnZ967G/JBPJXOGGHpoPVg\"",
		"mtime": "2026-10-22T06:37:18.409Z",
		"size": 494,
		"path": "../public/assets/calendar-days-5GeYs19G.js"
	},
	"/assets/company-D0xO_JFd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"294b-jGUSqBW+tvDKOYWM3KHQ11qzaoU\"",
		"mtime": "2026-10-22T06:37:18.412Z",
		"size": 10571,
		"path": "../public/assets/company-D0xO_JFd.js"
	},
	"/assets/country-C4DJTpz-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"92-16RPpvOWmB2A2k1I/E+KUmnGe8s\"",
		"mtime": "2026-10-22T06:37:18.413Z",
		"size": 146,
		"path": "../public/assets/country-C4DJTpz-.js"
	},
	"/assets/company-api-CUq20SpY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"315-g3neNlZXS+OO9ahw91TOUVIIi4c\"",
		"mtime": "2026-10-22T06:37:18.412Z",
		"size": 789,
		"path": "../public/assets/company-api-CUq20SpY.js"
	},
	"/assets/createLucideIcon-5JRSLlvH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4ab-2zmdx9sedX9IguCpilqTmk8qozQ\"",
		"mtime": "2026-10-22T06:37:18.413Z",
		"size": 1195,
		"path": "../public/assets/createLucideIcon-5JRSLlvH.js"
	},
	"/assets/customer-po-BivPIFBg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3309-oGBxiw1PG0zQcHaM+9qnxZw+e90\"",
		"mtime": "2026-10-22T06:37:18.428Z",
		"size": 13065,
		"path": "../public/assets/customer-po-BivPIFBg.js"
	},
	"/assets/dashboard-1HdGO7de.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2615-g9VBiB1xk0UyOJIHchdG0FMX0MQ\"",
		"mtime": "2026-10-22T06:37:18.428Z",
		"size": 9749,
		"path": "../public/assets/dashboard-1HdGO7de.js"
	},
	"/assets/dist-DYAUkNtW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12ac-BExCN2P/yQD5ISHqR+fzkG3tqJ4\"",
		"mtime": "2026-10-22T06:37:18.428Z",
		"size": 4780,
		"path": "../public/assets/dist-DYAUkNtW.js"
	},
	"/assets/download-D3w4nNSD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e8-p80AcT8nznL+KIGm34Cvg0NZ7Yc\"",
		"mtime": "2026-10-22T06:37:18.429Z",
		"size": 232,
		"path": "../public/assets/download-D3w4nNSD.js"
	},
	"/assets/drawer-DhfOT8D-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"74d0-vVBZuuVieQ4/7MDdacxEkxu+ykk\"",
		"mtime": "2026-10-22T06:37:18.429Z",
		"size": 29904,
		"path": "../public/assets/drawer-DhfOT8D-.js"
	},
	"/assets/email-campaign-Y2LS2j8f.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"36e-wO4hRzwVzFzz7Q01RfROGUy00iQ\"",
		"mtime": "2026-10-22T06:37:18.429Z",
		"size": 878,
		"path": "../public/assets/email-campaign-Y2LS2j8f.js"
	},
	"/assets/DataTable-DGJqtzCb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3125e-Hhv+ywbgYQpDbK7zoSkUSVGYcUE\"",
		"mtime": "2026-10-22T06:37:18.405Z",
		"size": 201310,
		"path": "../public/assets/DataTable-DGJqtzCb.js"
	},
	"/assets/email-campaign.campaigns-CPlARS2p.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5d0a-LXJHy652V1Us3XFtWHWCLVf7p0E\"",
		"mtime": "2026-10-22T06:37:18.430Z",
		"size": 23818,
		"path": "../public/assets/email-campaign.campaigns-CPlARS2p.js"
	},
	"/assets/email-campaign.logs-BvWFw-f9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"97c-HWJrmzBVtGE4Ckc3FZjqtCnLk5k\"",
		"mtime": "2026-10-22T06:37:18.430Z",
		"size": 2428,
		"path": "../public/assets/email-campaign.logs-BvWFw-f9.js"
	},
	"/assets/email-campaign.sequences-71yG8FKd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2419-KzSrGMiZgt8AB59Z5y/u4zUNoCc\"",
		"mtime": "2026-10-22T06:37:18.431Z",
		"size": 9241,
		"path": "../public/assets/email-campaign.sequences-71yG8FKd.js"
	},
	"/assets/email-campaign.templates-CO-2VpT7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ec5-XUpTwoxae7vgFgZFIJS8rR1lGUk\"",
		"mtime": "2026-10-22T06:37:18.432Z",
		"size": 7877,
		"path": "../public/assets/email-campaign.templates-CO-2VpT7.js"
	},
	"/assets/EmptyState-DDcb9rny.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"488-MMz196hHQkEJvDNQg8ibhv/PUZ4\"",
		"mtime": "2026-10-22T06:37:18.405Z",
		"size": 1160,
		"path": "../public/assets/EmptyState-DDcb9rny.js"
	},
	"/assets/EntityForm-DI9VvHG8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11166-WGRB87JQx0TluoT9DAHW+rUkGyY\"",
		"mtime": "2026-10-22T06:37:18.406Z",
		"size": 69990,
		"path": "../public/assets/EntityForm-DI9VvHG8.js"
	},
	"/assets/eye-4pwqTTee.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"100-JNqbvsNOaTv7+BwwLZ9cpGPQV1s\"",
		"mtime": "2026-10-22T06:37:18.433Z",
		"size": 256,
		"path": "../public/assets/eye-4pwqTTee.js"
	},
	"/assets/file-text-CLhUqrtI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"181-DeFV4tXEJk1MdQaNxkP0mGeB0b8\"",
		"mtime": "2026-10-22T06:37:18.433Z",
		"size": 385,
		"path": "../public/assets/file-text-CLhUqrtI.js"
	},
	"/assets/final-offer-BZb8XWtB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"378c-V7vCYLr0DgH1b2zo9pZhrwmYjBY\"",
		"mtime": "2026-10-22T06:37:18.434Z",
		"size": 14220,
		"path": "../public/assets/final-offer-BZb8XWtB.js"
	},
	"/assets/form-ChatnuwC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"465f-qu1y2kPTBrB/gSMVFIlT2pBgoJw\"",
		"mtime": "2026-10-22T06:37:18.434Z",
		"size": 18015,
		"path": "../public/assets/form-ChatnuwC.js"
	},
	"/assets/input-DoHRrl0J.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"269-Z37PxwpLdT0XoaiMbPHDKntH0xk\"",
		"mtime": "2026-10-22T06:37:18.435Z",
		"size": 617,
		"path": "../public/assets/input-DoHRrl0J.js"
	},
	"/assets/jsx-runtime-OQpaS_Dv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e5d-QNoQHuwEkd4/8PZ1cKbcagI8N+0\"",
		"mtime": "2026-10-22T06:37:18.435Z",
		"size": 7773,
		"path": "../public/assets/jsx-runtime-OQpaS_Dv.js"
	},
	"/assets/lead-csv-template-DWkoXUIa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"222-0GI8VfbGxDfGaGtFKnVUP/qcROg\"",
		"mtime": "2026-10-22T06:37:18.435Z",
		"size": 546,
		"path": "../public/assets/lead-csv-template-DWkoXUIa.js"
	},
	"/assets/leads-K_yS2xDN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"269a-MPw5m9fhljkhovvds536lRaTjuk\"",
		"mtime": "2026-10-22T06:37:18.436Z",
		"size": 9882,
		"path": "../public/assets/leads-K_yS2xDN.js"
	},
	"/assets/leads.form-VB1i-G1A.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4405-qzH2YwPSxOXBL7HzANersmeYsaA\"",
		"mtime": "2026-10-22T06:37:18.436Z",
		"size": 17413,
		"path": "../public/assets/leads.form-VB1i-G1A.js"
	},
	"/assets/link-CAl-Sa9v.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"17db-UaB2qKISyQ7zDYJuk87eq+59s5A\"",
		"mtime": "2026-10-22T06:37:18.437Z",
		"size": 6107,
		"path": "../public/assets/link-CAl-Sa9v.js"
	},
	"/assets/index-BOAFozJS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"55733-Pjmji9oiCGnPOsZSKqm4qe3lw4Y\"",
		"mtime": "2026-10-22T06:37:18.399Z",
		"size": 350003,
		"path": "../public/assets/index-BOAFozJS.js"
	},
	"/assets/location-Bf2pRDZf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b3b-nzMKT4ZOU0nvfGvpqBatq++KLis\"",
		"mtime": "2026-10-22T06:37:18.437Z",
		"size": 6971,
		"path": "../public/assets/location-Bf2pRDZf.js"
	},
	"/assets/login-tCe9af03.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"661-6amw4+YWBKjiU9gOZeG2f1SZ++s\"",
		"mtime": "2026-10-22T06:37:18.437Z",
		"size": 1633,
		"path": "../public/assets/login-tCe9af03.js"
	},
	"/assets/marketing-CjTEv1p7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12f0-GweC700H3FG9mfloeBhomHSBpns\"",
		"mtime": "2026-10-22T06:37:18.438Z",
		"size": 4848,
		"path": "../public/assets/marketing-CjTEv1p7.js"
	},
	"/assets/Match-5cQgR4sj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11a3-AZ+3Iyuz/y/s1dlAyWexMt/oCXk\"",
		"mtime": "2026-10-22T06:37:18.406Z",
		"size": 4515,
		"path": "../public/assets/Match-5cQgR4sj.js"
	},
	"/assets/matchContext-BLd14XSO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a2-Q9zaBz1LZIT8wotslK/zBebTFRQ\"",
		"mtime": "2026-10-22T06:37:18.438Z",
		"size": 162,
		"path": "../public/assets/matchContext-BLd14XSO.js"
	},
	"/assets/Modal-BZsGyKA9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"501-vgwcTW6YiVCexnZBgtRh2JrcaW8\"",
		"mtime": "2026-10-22T06:37:18.407Z",
		"size": 1281,
		"path": "../public/assets/Modal-BZsGyKA9.js"
	},
	"/assets/opportunities-B61TPP2U.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"448f-cxA5wFLxj1agfNjTqqGwKy0HqhY\"",
		"mtime": "2026-10-22T06:37:18.438Z",
		"size": 17551,
		"path": "../public/assets/opportunities-B61TPP2U.js"
	},
	"/assets/orders-DQV5_lDs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3182-Mx5FagSYMdlEZM0cHaT65LYnLEU\"",
		"mtime": "2026-10-22T06:37:18.439Z",
		"size": 12674,
		"path": "../public/assets/orders-DQV5_lDs.js"
	},
	"/assets/preload-helper-C-BKGnPd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14c3-CG6GvXjtBPGfVFy/Clx+rDIOHA0\"",
		"mtime": "2026-10-22T06:37:18.443Z",
		"size": 5315,
		"path": "../public/assets/preload-helper-C-BKGnPd.js"
	},
	"/assets/quotation-api-CVEUxg14.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"176b-NUBsWYVn6JtAIw/xMIib5aHiw0o\"",
		"mtime": "2026-10-22T06:37:18.443Z",
		"size": 5995,
		"path": "../public/assets/quotation-api-CVEUxg14.js"
	},
	"/assets/order-dashboard-DVYFuuYa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5b8c7-278StcmNFfi4aS0tsHfXiY53FkE\"",
		"mtime": "2026-10-22T06:37:18.439Z",
		"size": 374983,
		"path": "../public/assets/order-dashboard-DVYFuuYa.js"
	},
	"/assets/quotations-CkDlEztM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"544c-Ct1uTKHG6Z3QKg4BD//MZBgiCyE\"",
		"mtime": "2026-10-22T06:37:18.443Z",
		"size": 21580,
		"path": "../public/assets/quotations-CkDlEztM.js"
	},
	"/assets/register-CSA7dnDK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a8a-FYuVpxO4J/3Ow7E3sDkd1xZi7BE\"",
		"mtime": "2026-10-22T06:37:18.444Z",
		"size": 2698,
		"path": "../public/assets/register-CSA7dnDK.js"
	},
	"/assets/react-dom-Ch54GZ4s.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"20612-+DvTnf28xFOri7WU17yiDHFJqcc\"",
		"mtime": "2026-10-22T06:37:18.444Z",
		"size": 132626,
		"path": "../public/assets/react-dom-Ch54GZ4s.js"
	},
	"/assets/routes-8ZgJtnui.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b16-AVny1mkAlCNSpvePvUs5jMBemoo\"",
		"mtime": "2026-10-22T06:37:18.445Z",
		"size": 2838,
		"path": "../public/assets/routes-8ZgJtnui.js"
	},
	"/assets/sales-DLPnmiQo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ad9-axH+KKO3rLJ3M56P8QEBFdXrV7I\"",
		"mtime": "2026-10-22T06:37:18.445Z",
		"size": 2777,
		"path": "../public/assets/sales-DLPnmiQo.js"
	},
	"/assets/save-CK_SGmB_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b7-pK8W1jFwv17lXTHkPFzxuMYFFJo\"",
		"mtime": "2026-10-22T06:37:18.445Z",
		"size": 439,
		"path": "../public/assets/save-CK_SGmB_.js"
	},
	"/assets/shopping-cart-DWwt8raz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"124-J67nHP5w/JXe66D/liMVBGY+YxU\"",
		"mtime": "2026-10-22T06:37:18.446Z",
		"size": 292,
		"path": "../public/assets/shopping-cart-DWwt8raz.js"
	},
	"/assets/StatCard-Ef07sW3W.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"252-9C6VNeWJ0/pLgsAbULCA2/Pp4MY\"",
		"mtime": "2026-10-22T06:37:18.407Z",
		"size": 594,
		"path": "../public/assets/StatCard-Ef07sW3W.js"
	},
	"/assets/StatusBadge-CxXEaw6p.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8bb-fPkXLfFUQP3n9v+pCeeLNqmWAwI\"",
		"mtime": "2026-10-22T06:37:18.407Z",
		"size": 2235,
		"path": "../public/assets/StatusBadge-CxXEaw6p.js"
	},
	"/assets/styles-Cl2wfANN.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"1a2cd-vzeUYetuG4fk2Let4C9VqcCA3JQ\"",
		"mtime": "2026-10-22T06:37:18.455Z",
		"size": 107213,
		"path": "../public/assets/styles-Cl2wfANN.css"
	},
	"/assets/tabs-D_mYgxvT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dc7-EmeFPCMtY3BrpEK4/dTApv9Yotc\"",
		"mtime": "2026-10-22T06:37:18.447Z",
		"size": 3527,
		"path": "../public/assets/tabs-D_mYgxvT.js"
	},
	"/assets/target-BOizoJuW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e2-MPvNTPxILto0pNiyXc+q/bNTxxw\"",
		"mtime": "2026-10-22T06:37:18.447Z",
		"size": 226,
		"path": "../public/assets/target-BOizoJuW.js"
	},
	"/assets/textarea-CY-dYm-r.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"203-a/hVfN4kZqdJhYWIX5BZMIRfrxA\"",
		"mtime": "2026-10-22T06:37:18.448Z",
		"size": 515,
		"path": "../public/assets/textarea-CY-dYm-r.js"
	},
	"/assets/tasks-OfWf9uOh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9a-OftQilAhsZEdfcVhZTY823+CUak\"",
		"mtime": "2026-10-22T06:37:18.448Z",
		"size": 154,
		"path": "../public/assets/tasks-OfWf9uOh.js"
	},
	"/assets/triangle-alert-DsgdhYG4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"109-0xifL1ZKE/b+T32ezWrkIY1Yhsw\"",
		"mtime": "2026-10-22T06:37:18.448Z",
		"size": 265,
		"path": "../public/assets/triangle-alert-DsgdhYG4.js"
	},
	"/assets/upload-CDjpU4YU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e6-qGJnU3dS/CcSjNF8tj4xH91LHfI\"",
		"mtime": "2026-10-22T06:37:18.449Z",
		"size": 230,
		"path": "../public/assets/upload-CDjpU4YU.js"
	},
	"/assets/types-CTeloYrU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dd0b-zsIg22ZdoXTAbzfv4J68hdh5pGc\"",
		"mtime": "2026-10-22T06:37:18.448Z",
		"size": 56587,
		"path": "../public/assets/types-CTeloYrU.js"
	},
	"/assets/useMatch-BaG-rLLV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"293-KExcr+4gY6Q9OHGlMyrzORv35Q0\"",
		"mtime": "2026-10-22T06:37:18.449Z",
		"size": 659,
		"path": "../public/assets/useMatch-BaG-rLLV.js"
	},
	"/assets/useMutation-BT3iAFGa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1653-nNjx+xxahBncS6DWiQhSiKAwdb8\"",
		"mtime": "2026-10-22T06:37:18.449Z",
		"size": 5715,
		"path": "../public/assets/useMutation-BT3iAFGa.js"
	},
	"/assets/useNavigate-bMnaDzZT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e4-1WK6EHg77rU10hmcsan8jPuS534\"",
		"mtime": "2026-10-22T06:37:18.453Z",
		"size": 228,
		"path": "../public/assets/useNavigate-bMnaDzZT.js"
	},
	"/assets/useQuery-CRu0Hu6y.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"58ac-bqCQwjC2vq+w1I9Qe1m9VfieSyQ\"",
		"mtime": "2026-10-22T06:37:18.453Z",
		"size": 22700,
		"path": "../public/assets/useQuery-CRu0Hu6y.js"
	},
	"/assets/useRouter-FQeUpUVO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"97-B2HdYDV0WostxfIdUG9o6g8suBg\"",
		"mtime": "2026-10-22T06:37:18.454Z",
		"size": 151,
		"path": "../public/assets/useRouter-FQeUpUVO.js"
	},
	"/assets/utils-DCvbpOtd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cb5-ddQe7nge4rkeuEehVJsFEDF3H9s\"",
		"mtime": "2026-10-22T06:37:18.455Z",
		"size": 3253,
		"path": "../public/assets/utils-DCvbpOtd.js"
	},
	"/assets/useSelector-yWwUHw1M.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"839-Ino2rjLR00dlXcbqKgOSMMsQVxE\"",
		"mtime": "2026-10-22T06:37:18.454Z",
		"size": 2105,
		"path": "../public/assets/useSelector-yWwUHw1M.js"
	},
	"/assets/x-DFhNn4Ci.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9a-+N4AK71+X/v/1PnljiX9CCPZgs8\"",
		"mtime": "2026-10-22T06:37:18.455Z",
		"size": 154,
		"path": "../public/assets/x-DFhNn4Ci.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_bwTFGA = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_bwTFGA
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
