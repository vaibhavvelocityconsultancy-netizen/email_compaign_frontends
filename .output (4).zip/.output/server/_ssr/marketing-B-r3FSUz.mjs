import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { S as getSequences, g as getEmailLogs, m as getBatches, y as getLeads } from "./api-C6hU-8Yn.mjs";
import { b as Link, g as Outlet, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as StatusBadge } from "./StatusBadge-BMe1mW6r.mjs";
import { n as LoadingRows, t as EmptyState } from "./EmptyState-C9iZmoiO.mjs";
import { t as StatCard } from "./StatCard-DjGEnZSv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/marketing-B-r3FSUz.js
var import_jsx_runtime = require_jsx_runtime();
function MarketingRouteView() {
	return useRouterState({ select: (state) => state.location.pathname === "/marketing" }) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketingDashboard, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {});
}
function MarketingDashboard() {
	const leads = useQuery({
		queryKey: ["leads"],
		queryFn: getLeads
	});
	const campaigns = useQuery({
		queryKey: ["campaigns"],
		queryFn: getBatches
	});
	const logs = useQuery({
		queryKey: ["logs"],
		queryFn: getEmailLogs
	});
	const sequences = useQuery({
		queryKey: ["sequences"],
		queryFn: getSequences
	});
	const seqName = (id) => sequences.data?.find((s) => s.id === id)?.name ?? "—";
	const activeCount = campaigns.data?.filter((c) => c.status === "active").length ?? 0;
	const sentTotal = logs.data?.filter((log) => log.status === "delivered").length ?? 0;
	const failedTotal = logs.data?.filter((l) => l.status === "failed").length ?? 0;
	const replyTotal = logs.data?.filter((log) => log.status === "replied").length ?? 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rise flex items-end justify-between",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-mono text-[11px] tracking-wide text-muted-foreground",
					children: "OVERVIEW"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-3xl font-bold tracking-tight",
					children: "Marketing dashboard"
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-4 lg:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "TOTAL LEADS",
						value: leads.data?.length ?? "…",
						sub: "across all sources",
						delay: 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "ACTIVE CAMPAIGNS",
						value: activeCount,
						sub: `${campaigns.data?.filter((c) => c.status === "paused").length ?? 0} paused`,
						delay: 40
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "EMAILS DELIVERED",
						value: sentTotal.toLocaleString(),
						sub: "all campaigns",
						tone: "good",
						delay: 80
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "EMAILS FAILED",
						value: failedTotal,
						sub: "delivery errors",
						tone: "bad",
						delay: 120
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "REPLIES",
						value: replyTotal.toLocaleString(),
						sub: "from campaign leads",
						tone: "good",
						delay: 160
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "TOTAL CAMPAIGNS",
						value: campaigns.data?.length ?? "…",
						sub: "across all statuses",
						delay: 200
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rise overflow-hidden rounded-xl border border-line bg-surface",
				style: { animationDelay: "240ms" },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-line px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-base font-semibold tracking-tight",
							children: "Recent campaigns"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-mono text-[11px] text-muted-foreground",
							children: [campaigns.data?.length ?? 0, " total"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/marketing/email-campaign/campaigns",
						search: { create: false },
						className: "h-8 rounded-md border border-line px-3 py-1.5 text-xs transition-colors hover:bg-background",
						children: "View all"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-line text-left font-mono text-[10px] tracking-wide text-muted-foreground uppercase",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-2.5 font-medium",
									children: "Campaign"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-2.5 font-medium",
									children: "Sequence"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-2.5 text-right font-medium",
									children: "Leads"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-2.5 text-right font-medium",
									children: "Emails Sent"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-2.5 text-right font-medium",
									children: "Replies"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-2.5 font-medium",
									children: "Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-2.5 text-right font-medium",
									children: "Actions"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y divide-line",
							children: campaigns.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingRows, { cols: 7 }) : !campaigns.data?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 7,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
									title: "No campaigns yet",
									hint: "Create your first campaign to start sending."
								})
							}) }) : campaigns.data.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "transition-colors hover:bg-background/60",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 font-medium",
										children: c.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 text-muted-foreground",
										children: seqName(c.sequenceId)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 text-right font-mono text-[13px]",
										children: c.leadIds.length
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 text-right font-mono text-[13px]",
										children: logs.data?.filter((log) => log.batchId === c.id && log.status === "delivered").length ?? 0
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 text-right font-mono text-[13px]",
										children: logs.data?.filter((log) => log.batchId === c.id && log.status === "replied").length ?? 0
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: c.status })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 text-right",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/marketing/email-campaign/campaigns",
											search: { create: false },
											className: "text-xs font-medium text-brand hover:underline",
											children: "View"
										})
									})
								]
							}, c.id))
						})]
					})
				})]
			})
		]
	});
}
//#endregion
export { MarketingRouteView as component };
