import { A as request, b as getOpportunities, y as getLeads } from "./api-C6hU-8Yn.mjs";
import { u as getQuotations } from "./quotation-api-Bt0Vcpr3.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/task-api-C76HK2dY.js
function dateSortValue(value) {
	if (!value) return Number.NEGATIVE_INFINITY;
	const isoDate = value.match(/^(\d{4})-(\d{2})-(\d{2})$/);
	const formattedDate = value.match(/^(\d{2})-(\d{2})-(\d{4})$/);
	const timestamp = (isoDate ? new Date(Number(isoDate[1]), Number(isoDate[2]) - 1, Number(isoDate[3])) : formattedDate ? new Date(Number(formattedDate[3]), Number(formattedDate[1]) - 1, Number(formattedDate[2])) : new Date(value)).getTime();
	return Number.isNaN(timestamp) ? Number.NEGATIVE_INFINITY : timestamp;
}
function toFormData(values, files = []) {
	const formData = new FormData();
	for (const [key, value] of Object.entries(values)) if (value !== void 0 && value !== null) formData.append(key, String(value));
	for (const file of files) {
		formData.append("files", file);
		formData.append("file_names", file.name);
	}
	return formData;
}
function useTasks() {
	return useQuery({
		queryKey: ["tasks"],
		queryFn: () => request("/tasks/")
	});
}
function getTaskDashboard(userId) {
	const query = userId ? `?user_id=${encodeURIComponent(userId)}` : "";
	return request(`/tasks/dashboard/${query}`);
}
function useTask(id) {
	return useQuery({
		queryKey: ["task", id],
		queryFn: () => request(`/tasks/${id}/`),
		enabled: id !== void 0
	});
}
function useTaskReferenceData() {
	return useQuery({
		queryKey: ["task-reference-data"],
		queryFn: async () => {
			const [leads, opportunities, quotations] = await Promise.all([
				getLeads(),
				getOpportunities(),
				getQuotations()
			]);
			const companyByOpportunity = new Map(opportunities.map((opportunity) => [opportunity.id, opportunity.companyId]));
			const newestFirst = (items, dateField) => items.sort((left, right) => {
				const leftDate = dateSortValue(left[dateField]);
				const rightDate = dateSortValue(right[dateField]);
				return leftDate === rightDate ? 0 : rightDate > leftDate ? 1 : -1;
			});
			return {
				leads: newestFirst(leads.map((lead) => ({
					value: lead.id,
					label: `${lead.enquiryDate || "No enquiry date"} · Lead #${lead.srNo}`,
					companyId: lead.companyId,
					enquiryDate: lead.enquiryDate,
					lead
				})), "enquiryDate"),
				opportunities: newestFirst(opportunities.map((opportunity) => ({
					value: opportunity.id,
					label: `${opportunity.enquiryDate || "No enquiry date"} · Opportunity #${opportunity.id}`,
					companyId: opportunity.companyId,
					enquiryDate: opportunity.enquiryDate
				})), "enquiryDate"),
				quotations: newestFirst(quotations.map((quotation) => ({
					value: quotation.quotationNumber,
					label: quotation.quotationNumber,
					companyId: quotation.companyId ?? companyByOpportunity.get(quotation.opportunity) ?? null,
					quotationDate: quotation.quotationDate,
					quotation
				})), "quotationDate")
			};
		}
	});
}
function useTaskOptions() {
	return useQuery({
		queryKey: ["task-options"],
		queryFn: () => request("/task-options/")
	});
}
function useCompanyOptions() {
	const { data, ...query } = useTaskOptions();
	return {
		...query,
		data: data?.companies ?? []
	};
}
function useUserOptions() {
	const { data, ...query } = useTaskOptions();
	return {
		...query,
		data: data?.users ?? []
	};
}
function useSaveTask() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: ({ id, body }) => request(id ? `/tasks/${id}/` : "/tasks/", {
			method: id ? "PATCH" : "POST",
			body
		}),
		onSuccess: () => queryClient.invalidateQueries({ queryKey: ["tasks"] })
	});
}
function useDeleteTask() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: (id) => request(`/tasks/${id}/`, { method: "DELETE" }),
		onSuccess: () => queryClient.invalidateQueries({ queryKey: ["tasks"] })
	});
}
//#endregion
export { useSaveTask as a, useTasks as c, useDeleteTask as i, useUserOptions as l, toFormData as n, useTask as o, useCompanyOptions as r, useTaskReferenceData as s, getTaskDashboard as t };
