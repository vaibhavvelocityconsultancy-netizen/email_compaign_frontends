import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-BPqa0i30.js
var $$splitComponentImporter = () => import("./dashboard-CSR8KIt_.mjs");
var Route = createFileRoute("/tasks/dashboard")({
	validateSearch: (search) => ({ userId: typeof search.userId === "string" && search.userId ? search.userId : void 0 }),
	head: () => ({ meta: [{ title: "Task Dashboard — Vantage CRM" }, {
		name: "description",
		content: "Task workload, deadlines and breakdowns."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
