import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { C as getTemplates, L as updateSequence, S as getSequences, d as deleteSequence, m as getBatches, o as createSequence } from "./api-C6hU-8Yn.mjs";
import { a as TriangleAlert, s as Trash2, v as Plus } from "../_libs/lucide-react.mjs";
import { c as SelectItem, l as SelectTrigger, n as DataTable, o as Select, s as SelectContent, u as SelectValue } from "./DataTable-DmCzJ7wu.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as ConfirmDialog } from "./ConfirmDialog-Rjd0NwWp.mjs";
import { c as objectType, l as stringType, n as arrayType, s as numberType } from "../_libs/zod.mjs";
import { t as StatusBadge } from "./StatusBadge-BMe1mW6r.mjs";
import { i as useFieldArray, o as useFormContext } from "../_libs/@hookform/resolvers+[...].mjs";
import { a as FormLabel, i as FormItem, n as FormControl, o as FormMessage, r as FormField, s as fieldPresets, t as EntityForm } from "./EntityForm-CgVD88J8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/email-campaign.sequences-DXaOAW3d.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var sequenceSchema = objectType({
	name: stringType().trim().min(1, "Sequence name is required"),
	description: stringType(),
	steps: arrayType(objectType({
		templateId: numberType().int().positive("Choose an email template"),
		delayDays: numberType().int().min(0, "Delay cannot be negative"),
		delayMinutes: numberType().int().min(0, "Delay cannot be negative")
	})).min(1, "Add at least one step")
});
function SequenceStepsEditor({ templates, disabled }) {
	const { control, setValue, watch } = useFormContext();
	const { fields, append, remove } = useFieldArray({
		control,
		name: "steps",
		keyName: "fieldKey"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "col-span-full space-y-3 rounded-lg border border-line bg-background/60 p-3 sm:p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-semibold",
					children: "Sequence steps"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-0.5 text-xs text-muted-foreground",
					children: "Each delay is measured from the previous email."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					size: "sm",
					variant: "outline",
					className: "h-8 gap-1.5",
					disabled: disabled || templates.length === 0,
					onClick: () => append({
						templateId: Number(templates[0]?.id ?? 0),
						delayDays: 0,
						delayMinutes: 0
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " Add step"]
				})]
			}),
			templates.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-md border border-warn/30 bg-warn/10 p-3 text-xs text-foreground",
				children: "Create an email template before adding sequence steps."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: fields.map((item, index) => {
					const templateId = watch(`steps.${index}.templateId`);
					const chosenTemplate = templates.find((template) => template.id === String(templateId));
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid min-w-0 grid-cols-1 items-end gap-3 rounded-md border border-line bg-surface p-3 sm:grid-cols-[minmax(0,1fr)_7rem_7rem_auto]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								control,
								name: `steps.${index}.templateId`,
								render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormItem, {
									className: "min-w-0 space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormLabel, { children: [
											"Step ",
											index + 1,
											" template"
										] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
											value: field.value ? String(field.value) : "",
											onValueChange: (value) => field.onChange(Number(value)),
											disabled: disabled || templates.length === 0,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Choose a template" }) }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: templates.map((template) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: template.id,
												children: template.name
											}, template.id)) })]
										}),
										chosenTemplate && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate text-xs text-muted-foreground",
											children: chosenTemplate.subject
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormMessage, {})
									]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								control,
								name: `steps.${index}.delayDays`,
								render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormItem, {
									className: "space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormLabel, { children: "Delay days" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "number",
											min: 0,
											step: 1,
											disabled,
											value: field.value,
											onChange: (event) => field.onChange(Number(event.target.value))
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormMessage, {})
									]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								control,
								name: `steps.${index}.delayMinutes`,
								render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormItem, {
									className: "space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormLabel, { children: "Minutes" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "number",
											min: 0,
											step: 1,
											disabled,
											value: field.value,
											onChange: (event) => field.onChange(Number(event.target.value))
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormMessage, {})
									]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								size: "icon",
								className: "size-9 justify-self-end text-destructive hover:text-destructive",
								disabled: disabled || fields.length === 1,
								title: "Remove step",
								"aria-label": `Remove step ${index + 1}`,
								onClick: () => remove(index),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "hidden",
								...control.register(`steps.${index}.templateId`)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "hidden",
								...control.register(`steps.${index}.delayDays`)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "hidden",
								...control.register(`steps.${index}.delayMinutes`)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "sr-only",
								"aria-live": "polite",
								children: ["Step template: ", chosenTemplate?.name ?? "not selected"]
							})
						]
					}, item.fieldKey);
				})
			})
		]
	});
}
function SequencesPage() {
	const queryClient = useQueryClient();
	const [formOpen, setFormOpen] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [toDelete, setToDelete] = (0, import_react.useState)(null);
	const sequencesQuery = useQuery({
		queryKey: ["sequences"],
		queryFn: getSequences
	});
	const templatesQuery = useQuery({
		queryKey: ["templates"],
		queryFn: getTemplates
	});
	const campaignsQuery = useQuery({
		queryKey: ["campaigns"],
		queryFn: getBatches
	});
	const sequences = sequencesQuery.data ?? [];
	const templates = templatesQuery.data ?? [];
	const campaigns = campaignsQuery.data ?? [];
	const templateById = (0, import_react.useMemo)(() => new Map(templates.map((template) => [template.id, template])), [templates]);
	const campaignSequenceIds = (0, import_react.useMemo)(() => new Set(campaigns.map((campaign) => campaign.sequenceId)), [campaigns]);
	const openCreate = () => {
		setEditing(null);
		setFormOpen(true);
	};
	const openEdit = (0, import_react.useCallback)((sequence) => {
		setEditing(sequence);
		setFormOpen(true);
	}, []);
	const saveMutation = useMutation({
		mutationFn: (values) => {
			const payload = {
				name: values.name,
				description: values.description,
				steps: values.steps.map((step) => ({
					templateId: String(step.templateId),
					delayDays: step.delayDays,
					delayMinutes: step.delayMinutes
				}))
			};
			return editing ? updateSequence(editing.id, payload) : createSequence(payload);
		},
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: ["sequences"] });
			setFormOpen(false);
			toast.success(editing ? "Sequence updated" : "Sequence created");
		},
		onError: (error) => toast.error(error.message || "Could not save sequence")
	});
	const deleteMutation = useMutation({
		mutationFn: (id) => {
			if (campaignSequenceIds.has(id)) throw new Error("This sequence is assigned to a campaign. Remove or reassign those campaigns first.");
			return deleteSequence(id);
		},
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: ["sequences"] });
			setToDelete(null);
			toast.success("Sequence deleted");
		},
		onError: (error) => toast.error(error.message || "Could not delete sequence")
	});
	const columns = (0, import_react.useMemo)(() => [
		{
			key: "name",
			header: "Sequence",
			cell: (sequence) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium",
				children: sequence.name
			})
		},
		{
			key: "description",
			header: "Description",
			cell: (sequence) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "line-clamp-2 max-w-md text-muted-foreground",
				children: sequence.description || "No description"
			})
		},
		{
			key: "steps",
			header: "Steps",
			filterValue: (sequence) => sequence.steps.length,
			cell: (sequence) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-xs",
				children: sequence.steps.length
			})
		},
		{
			key: "templates",
			header: "Templates",
			sortable: false,
			filterable: false,
			cell: (sequence) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block max-w-xs truncate text-xs text-muted-foreground",
				children: sequence.steps.map((step) => templateById.get(step.templateId)?.name ?? "Missing template").join(" · ") || "No steps"
			})
		},
		{
			key: "usage",
			header: "Campaign use",
			filterValue: (sequence) => campaigns.filter((campaign) => campaign.sequenceId === sequence.id).length,
			cell: (sequence) => {
				const count = campaigns.filter((campaign) => campaign.sequenceId === sequence.id).length;
				return count ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: `${count} campaign${count === 1 ? "" : "s"}` }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "Unused"
				});
			}
		},
		{
			key: "actions",
			header: "Actions",
			sortable: false,
			filterable: false,
			className: "text-right",
			headerClassName: "text-right",
			cell: (sequence) => {
				const inUse = campaignSequenceIds.has(sequence.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-end gap-3 text-xs font-medium",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => openEdit(sequence),
						className: "text-brand hover:underline",
						children: "Edit"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setToDelete(sequence),
						disabled: inUse,
						title: inUse ? "Sequence is used by a campaign" : "Delete sequence",
						className: "text-destructive hover:underline disabled:cursor-not-allowed disabled:opacity-40",
						children: "Delete"
					})]
				});
			}
		}
	], [
		templateById,
		campaigns,
		campaignSequenceIds,
		openEdit
	]);
	const fields = (0, import_react.useMemo)(() => [fieldPresets.text("name", "Sequence name", {
		required: true,
		placeholder: "Standard follow-up",
		colSpan: 2
	}), fieldPresets.textarea("description", "Description", {
		rows: 2,
		placeholder: "When should this sequence be used?"
	})], []);
	const defaultValues = (0, import_react.useMemo)(() => editing ? {
		name: editing.name,
		description: editing.description,
		steps: editing.steps.map((step) => ({
			templateId: Number(step.templateId),
			delayDays: step.delayDays,
			delayMinutes: step.delayMinutes
		}))
	} : {
		name: "",
		description: "",
		steps: [{
			templateId: Number(templates[0]?.id ?? 0),
			delayDays: 0,
			delayMinutes: 0
		}]
	}, [editing, templates]);
	const canCreate = templates.length > 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rise flex flex-wrap items-end justify-between gap-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-mono text-[11px] tracking-wide text-muted-foreground",
					children: "AUTOMATION"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-3xl font-bold tracking-tight",
					children: "Sequences"
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rise",
				style: { animationDelay: "80ms" },
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
						data: sequences,
						columns,
						searchKeys: ["name", "description"],
						searchPlaceholder: "Search sequences...",
						storageKey: "email-sequences",
						emptyMessage: sequencesQuery.isLoading ? "Loading sequences…" : "No sequences yet. Create a sequence from your email templates.",
						toolbarActions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							className: "h-9 gap-1.5",
							disabled: !canCreate,
							title: !canCreate ? "Create an email template first" : void 0,
							onClick: openCreate,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " New sequence"]
						})
					}),
					sequencesQuery.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-destructive",
						children: sequencesQuery.error.message
					}),
					!canCreate && !templatesQuery.isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 flex items-center gap-2 text-xs text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4 text-warn" }), " Create an email template before building a sequence."]
					}),
					campaignsQuery.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-destructive",
						children: ["Could not load campaign usage: ", campaignsQuery.error.message]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityForm, {
				open: formOpen,
				onOpenChange: setFormOpen,
				title: editing ? "Edit sequence" : "Create sequence",
				fields,
				schema: sequenceSchema,
				defaultValues,
				isEdit: Boolean(editing),
				isLoading: saveMutation.isPending,
				submitLabel: "Save sequence",
				size: "lg",
				onSubmit: async (values) => {
					await saveMutation.mutateAsync(values);
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SequenceStepsEditor, {
					templates,
					disabled: saveMutation.isPending
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: Boolean(toDelete),
				onClose: () => setToDelete(null),
				onConfirm: () => toDelete && deleteMutation.mutate(toDelete.id),
				title: "Delete sequence",
				message: `Delete “${toDelete?.name ?? "this sequence"}”? Sequences used by campaigns cannot be deleted.`,
				loading: deleteMutation.isPending
			})
		]
	});
}
//#endregion
export { SequencesPage as component };
