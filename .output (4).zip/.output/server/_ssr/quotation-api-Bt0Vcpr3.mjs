import { A as request } from "./api-C6hU-8Yn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quotation-api-Bt0Vcpr3.js
var QUOTATION_STATUSES = [
	["DRAFT", "Draft"],
	["SENT", "Sent"],
	["APPROVED", "Approved"],
	["REJECTED", "Rejected"],
	["REVISION", "Revision"],
	["CONVERTED", "Converted"]
];
var num = (v) => v == null || v === "" ? 0 : Number(v);
function mapQuotation(raw) {
	const opp = raw.opportunity;
	const oppObj = typeof opp === "object" && opp ? opp : null;
	const companyObj = typeof oppObj?.company === "object" && oppObj.company ? oppObj.company : null;
	const cityObj = typeof companyObj?.city === "object" && companyObj.city ? companyObj.city : null;
	const items = Array.isArray(raw.items) ? raw.items : [];
	const companyContacts = Array.isArray(raw.company_contacts) ? raw.company_contacts : [];
	return {
		id: String(raw.id),
		quotationNumber: String(raw.quotation_number ?? ""),
		quotationDate: raw.quotation_date ?? null,
		foDate: raw.fo_date ?? raw.quotation_date ?? null,
		cpoDate: raw.cpo_date ?? null,
		cpoCreated: Boolean(raw.cpo_created),
		cpoDocument: raw.cpo_document ?? null,
		opportunity: String(oppObj ? oppObj.id : opp ?? ""),
		projectName: String(raw.project_name ?? ""),
		companyId: raw.company_id == null ? null : Number(raw.company_id),
		companyName: String(raw.company_name ?? oppObj?.company_name ?? companyObj?.name ?? ""),
		companyAddress: String(raw.company_address ?? ""),
		companyPincode: String(raw.company_pincode ?? ""),
		companyContacts: companyContacts.map((contact) => ({
			name: String(contact.name ?? ""),
			designation: String(contact.designation ?? ""),
			phone: String(contact.phone ?? ""),
			email: String(contact.email ?? ""),
			isPrimary: Boolean(contact.is_primary)
		})),
		city: String(raw.company_city ?? companyObj?.city_name ?? cityObj?.name ?? ""),
		state: String(raw.company_state ?? companyObj?.state_name ?? ""),
		status: String(raw.status ?? "DRAFT"),
		statusDisplay: String(raw.status_display ?? raw.status ?? ""),
		taxTypeDisplay: String(raw.tax_type_display ?? ""),
		subtotal: num(raw.subtotal),
		discount: num(raw.discount),
		taxableAmount: num(raw.taxable_amount),
		taxType: String(raw.tax_type ?? ""),
		taxPercentage: num(raw.tax_percentage),
		taxAmount: num(raw.tax_amount),
		cgstAmount: num(raw.cgst_amount),
		sgstAmount: num(raw.sgst_amount),
		igstAmount: num(raw.igst_amount),
		packingCharges: num(raw.packing_charges),
		totalAmount: num(raw.total_amount),
		termsConditions: String(raw.terms_conditions ?? ""),
		deliveryTimeline: String(raw.delivery_timeline ?? ""),
		quotationPdf: raw.quotation_pdf ?? null,
		finalOfferGenerated: Boolean(raw.final_offer_generated),
		finalOfferPdf: raw.final_offer_pdf ?? null,
		items: items.map((it) => {
			const mod = it.module;
			const modObj = typeof mod === "object" && mod ? mod : null;
			return {
				id: it.id == null ? void 0 : String(it.id),
				module: modObj ? String(modObj.id) : mod == null ? null : String(mod),
				moduleName: String(it.module_name ?? modObj?.module_name ?? ""),
				description: String(it.description ?? ""),
				requirements: String(it.requirements ?? ""),
				estimatedCost: it.estimated_cost == null ? null : Number(it.estimated_cost),
				estimatedDays: it.estimated_days == null ? null : Number(it.estimated_days),
				priority: String(it.priority ?? "MEDIUM"),
				remarks: String(it.remarks ?? ""),
				amount: num(it.amount)
			};
		})
	};
}
async function getQuotations() {
	return (await request("/quotations/")).map(mapQuotation);
}
async function getCpos() {
	return (await request("/quotations/?cpo_created=true")).map(mapQuotation);
}
async function getNextQuotationNumber() {
	return (await request("/quotations/next-number/")).quotation_number;
}
async function createQuotation(data) {
	return mapQuotation(await request("/quotations/", {
		method: "POST",
		body: JSON.stringify(data)
	}));
}
async function updateQuotation(id, data) {
	return mapQuotation(await request(`/quotations/${id}/`, {
		method: "PATCH",
		body: JSON.stringify(data)
	}));
}
async function updateQuotationCpo(id, data) {
	return mapQuotation(await request(`/quotations/${id}/`, {
		method: "PATCH",
		body: JSON.stringify(data)
	}));
}
function mapSalesOrder(raw) {
	const items = Array.isArray(raw.items) ? raw.items : [];
	const contacts = Array.isArray(raw.company_contacts) ? raw.company_contacts : [];
	return {
		id: String(raw.id),
		soNumber: String(raw.so_number ?? ""),
		soDate: String(raw.so_date ?? ""),
		quotationId: String(raw.quotation ?? ""),
		quotationNumber: String(raw.quotation_number ?? ""),
		companyId: Number(raw.company ?? 0),
		companyName: String(raw.company_name ?? ""),
		companyAddress: String(raw.company_address ?? ""),
		companyCityId: raw.company_city == null ? null : Number(raw.company_city),
		companyCityName: String(raw.company_city_name ?? ""),
		companyStateId: raw.company_state == null ? null : Number(raw.company_state),
		companyStateName: String(raw.company_state_name ?? ""),
		companyCountryId: raw.company_country == null ? null : Number(raw.company_country),
		companyCountryName: String(raw.company_country_name ?? ""),
		companyPincode: String(raw.company_pincode ?? ""),
		companyGstNumber: String(raw.company_gst_number ?? ""),
		companyContacts: contacts.map((contact) => ({
			id: Number(contact.id),
			name: String(contact.name ?? ""),
			designation: String(contact.designation ?? ""),
			phone: String(contact.phone ?? ""),
			email: String(contact.email ?? ""),
			is_primary: Boolean(contact.is_primary)
		})),
		quotationPdf: raw.quotation_pdf ?? null,
		finalOfferPdf: raw.final_offer_pdf ?? null,
		cpoDocument: raw.cpo_document ?? null,
		soPdf: raw.so_pdf ?? null,
		createdByName: String(raw.created_by_name ?? ""),
		projectName: String(raw.project_name ?? ""),
		subtotal: num(raw.subtotal),
		discountPercentage: num(raw.discount_percentage),
		discountAmount: num(raw.discount_amount),
		taxableAmount: num(raw.taxable_amount),
		taxPercentage: num(raw.tax_percentage),
		taxAmount: num(raw.tax_amount),
		cgstAmount: num(raw.cgst_amount),
		sgstAmount: num(raw.sgst_amount),
		igstAmount: num(raw.igst_amount),
		packingCharges: num(raw.packing_charges),
		totalAmount: num(raw.total_amount),
		taxType: String(raw.tax_type ?? ""),
		paymentTerms: String(raw.payment_terms ?? ""),
		deliveryTerms: String(raw.delivery_terms ?? ""),
		remarks: String(raw.remarks ?? ""),
		status: String(raw.status ?? "DRAFT"),
		items: items.map((item) => ({
			id: item.id == null ? void 0 : String(item.id),
			module: item.module == null ? null : String(item.module),
			moduleName: String(item.module_name ?? ""),
			description: String(item.description ?? ""),
			requirements: String(item.requirements ?? ""),
			estimatedCost: item.estimated_cost == null ? null : Number(item.estimated_cost),
			estimatedDays: item.estimated_days == null ? null : Number(item.estimated_days),
			priority: String(item.priority ?? "MEDIUM"),
			remarks: String(item.remarks ?? ""),
			amount: num(item.amount)
		}))
	};
}
async function updateSalesOrder(id, data) {
	return mapSalesOrder(await request(`/sales-orders/${id}/`, {
		method: "PATCH",
		body: JSON.stringify(data)
	}));
}
async function createSalesOrder(quotationId) {
	const response = await request(`/create-sales/${quotationId}/`, { method: "POST" });
	return {
		id: String(response.id),
		soNumber: response.so_number
	};
}
async function getSalesOrders() {
	return (await request("/sales-orders/")).map(mapSalesOrder);
}
async function attachCpoDocument(id, document) {
	const formData = new FormData();
	formData.append("cpo_document", document);
	return mapQuotation(await request(`/quotations/${id}/`, {
		method: "PATCH",
		body: formData
	}));
}
async function deleteQuotation(id) {
	await request(`/quotations/${id}/`, { method: "DELETE" });
}
async function generateFinalOffer(id) {
	return mapQuotation(await request(`/quotations/${id}/generate-final-offer/`, { method: "POST" }));
}
async function updateFinalOffer(id, data) {
	return mapQuotation(await request(`/quotations/${id}/final-offer/`, {
		method: "PATCH",
		body: JSON.stringify(data)
	}));
}
async function getQuotationById(id) {
	return mapQuotation(await request(`/quotations/${id}/`));
}
//#endregion
export { deleteQuotation as a, getNextQuotationNumber as c, getSalesOrders as d, updateFinalOffer as f, updateSalesOrder as h, createSalesOrder as i, getQuotationById as l, updateQuotationCpo as m, attachCpoDocument as n, generateFinalOffer as o, updateQuotation as p, createQuotation as r, getCpos as s, QUOTATION_STATUSES as t, getQuotations as u };
