//#region node_modules/.nitro/vite/services/ssr/assets/api-C6hU-8Yn.js
var apiBase = Reflect.get({
	"BASE_URL": "/vc_email_crm/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/vc_email_crm/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "vc_email_crm",
	"TSS_SERVER_FN_BASE": "/vc_email_crm/_serverFn/",
	"VITE_API_BASE_URL": "https://sharpefforts.com/email_backend_crm/api"
}, "VITE_API_BASE_URL")?.replace(/\/+$/, "") || "/api";
var accessTokenKey = "vantage.access";
var refreshTokenKey = "vantage.refresh";
function getStoredToken(key) {
	if (typeof window === "undefined") return null;
	window.localStorage.removeItem(key);
	return window.sessionStorage.getItem(key);
}
function storeTokens(tokens) {
	if (typeof window === "undefined") return;
	window.localStorage.removeItem(accessTokenKey);
	window.localStorage.removeItem(refreshTokenKey);
	window.sessionStorage.setItem(accessTokenKey, tokens.access);
	window.sessionStorage.setItem(refreshTokenKey, tokens.refresh);
}
function hasAuthTokens() {
	return Boolean(getStoredToken(accessTokenKey) || getStoredToken(refreshTokenKey));
}
function clearAuthTokens() {
	if (typeof window === "undefined") return;
	window.localStorage.removeItem(accessTokenKey);
	window.localStorage.removeItem(refreshTokenKey);
	window.sessionStorage.removeItem(accessTokenKey);
	window.sessionStorage.removeItem(refreshTokenKey);
}
function makeApiUrl(path) {
	const baseUrl = typeof window === "undefined" ? "http://127.0.0.1:8000" : window.location.origin;
	return new URL(`${apiBase}${path}`, baseUrl);
}
async function refreshAccessToken() {
	const refresh = getStoredToken(refreshTokenKey);
	if (!refresh) return null;
	try {
		const response = await fetch(makeApiUrl("/auth/refresh/"), {
			method: "POST",
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json"
			},
			body: JSON.stringify({ refresh })
		});
		if (!response.ok) throw new Error("Session expired");
		const tokens = await response.json();
		storeTokens({
			access: tokens.access,
			refresh: tokens.refresh ?? refresh
		});
		return tokens.access;
	} catch {
		clearAuthTokens();
		return null;
	}
}
async function request(path, init = {}) {
	const url = makeApiUrl(path);
	const headers = new Headers(init.headers);
	headers.set("Accept", "application/json");
	if (init.body && !(init.body instanceof FormData) && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
	const isPublicAuthRequest = [
		"/auth/login/",
		"/auth/register/",
		"/auth/refresh/",
		"/auth/logout/"
	].includes(path);
	const accessToken = getStoredToken(accessTokenKey);
	if (accessToken && !isPublicAuthRequest) headers.set("Authorization", `Bearer ${accessToken}`);
	let response = await fetch(url, {
		...init,
		headers
	});
	if (response.status === 401 && !isPublicAuthRequest) {
		const refreshedAccessToken = await refreshAccessToken();
		if (refreshedAccessToken) {
			const retryHeaders = new Headers(headers);
			retryHeaders.set("Authorization", `Bearer ${refreshedAccessToken}`);
			response = await fetch(url, {
				...init,
				headers: retryHeaders
			});
		}
	}
	const responseText = await response.text();
	let payload;
	try {
		payload = responseText ? JSON.parse(responseText) : void 0;
	} catch {
		payload = responseText;
	}
	if (!response.ok) throw new Error(formatApiError(payload, response.statusText));
	return payload;
}
async function loginUser(email, password) {
	const result = await request("/auth/login/", {
		method: "POST",
		body: JSON.stringify({
			email,
			password
		})
	});
	storeTokens(result);
	return result.user;
}
async function registerUser(data) {
	const result = await request("/auth/register/", {
		method: "POST",
		body: JSON.stringify(data)
	});
	storeTokens(result);
	return result.user;
}
function getCurrentUser() {
	return request("/auth/me/");
}
async function logoutUser() {
	const refresh = getStoredToken(refreshTokenKey);
	try {
		if (refresh) await request("/auth/logout/", {
			method: "POST",
			body: JSON.stringify({ refresh })
		});
	} finally {
		clearAuthTokens();
	}
}
function formatApiError(payload, fallback) {
	if (typeof payload === "string") return payload || fallback;
	if (payload && typeof payload === "object") {
		const errors = Object.entries(payload).map(([field, value]) => {
			const message = Array.isArray(value) ? value.join(" ") : String(value);
			return field === "detail" ? message : `${field}: ${message}`;
		});
		if (errors.length) return errors.join("; ");
	}
	return fallback || "The request failed";
}
function fileName(url) {
	const name = url?.split("?")[0]?.split("/").pop();
	return name ? decodeURIComponent(name) : void 0;
}
function mapLead(lead) {
	return {
		id: String(lead.sr_no),
		srNo: lead.sr_no,
		unsubscribed: lead.unsubscribed,
		enquiryFor: lead.enquiry_for,
		enquiryDate: lead.enquiry_date,
		companyId: lead.company,
		companyName: lead.company_name,
		companyAddress: lead.company_address,
		companyCity: lead.company_city,
		companyState: lead.company_state,
		companyPincode: lead.company_pincode,
		companyCountry: lead.company_country,
		companyGstNumber: lead.company_gst_number,
		contactId: lead.contact,
		contactName: lead.contact_name,
		contactDesignation: lead.contact_designation,
		contactMobile: lead.contact_mobile,
		contactEmail: lead.contact_email,
		source: lead.source,
		status: lead.status.toLowerCase(),
		followupDate: lead.followup_date,
		followupRemarks: lead.followup_remarks,
		isOpportunity: lead.is_opportunity,
		createdAt: lead.created_at
	};
}
function mapTemplate(template) {
	const logoName = fileName(template.logo);
	const attachmentName = fileName(template.attachment);
	return {
		id: String(template.id),
		channel: template.channel ?? "email",
		name: template.name,
		subject: template.subject,
		body: template.body,
		signature: template.signature,
		...logoName ? { logoName } : {},
		...attachmentName ? { attachmentName } : {},
		waTemplateName: template.wa_template_name,
		waLanguage: template.wa_language,
		waStatus: template.wa_status,
		createdAt: template.created_at
	};
}
async function getLeads() {
	return (await request("/leads/")).results.map(mapLead);
}
async function getLead(id) {
	return mapLead(await request(`/leads/${id}/`));
}
async function getLeadOptions() {
	return request("/lead-options/");
}
async function createLead(data) {
	return mapLead(await request("/leads/", {
		method: "POST",
		body: JSON.stringify(data)
	}));
}
async function updateLead(id, data) {
	return mapLead(await request(`/leads/${id}/`, {
		method: "PATCH",
		body: JSON.stringify(data)
	}));
}
async function updateLeadStatus(id, status) {
	return mapLead(await request(`/leads/${id}/`, {
		method: "PATCH",
		body: JSON.stringify({ status: status.toUpperCase() })
	}));
}
async function deleteLead(id) {
	await request(`/leads/${id}/`, { method: "DELETE" });
}
function mapOpportunity(opportunity) {
	const modules = Array.isArray(opportunity.modules) ? opportunity.modules.map((module) => {
		const item = module;
		return {
			id: item.id == null ? void 0 : String(item.id),
			moduleNumber: Number(item.module_number ?? 0),
			moduleName: String(item.module_name ?? ""),
			description: String(item.description ?? ""),
			requirements: String(item.requirements ?? ""),
			estimatedCost: item.estimated_cost == null ? null : Number(item.estimated_cost),
			estimatedDays: item.estimated_days == null ? null : Number(item.estimated_days),
			priority: String(item.priority ?? "MEDIUM"),
			remarks: String(item.remarks ?? "")
		};
	}) : [];
	return {
		id: String(opportunity.id),
		companyId: typeof opportunity.company === "object" && opportunity.company ? Number(opportunity.company.id) : opportunity.company == null ? null : Number(opportunity.company),
		companyName: String(opportunity.company_name ?? ""),
		projectName: String(opportunity.project_name ?? ""),
		enquiryFor: String(opportunity.enquiry_for ?? ""),
		enquiryDate: opportunity.enquiry_date ?? null,
		status: String(opportunity.status ?? "PROSPECTING"),
		source: String(opportunity.source ?? ""),
		expectedCloseDate: opportunity.expected_close_date ?? null,
		estimatedValue: opportunity.estimated_value == null ? null : Number(opportunity.estimated_value),
		probability: opportunity.probability == null ? null : Number(opportunity.probability),
		modules,
		createdAt: String(opportunity.created_at ?? "")
	};
}
async function getOpportunities() {
	return (await request("/opportunities/")).map(mapOpportunity);
}
async function createOpportunity(data) {
	return mapOpportunity(await request("/opportunities/", {
		method: "POST",
		body: JSON.stringify(data)
	}));
}
async function updateOpportunity(id, data) {
	return mapOpportunity(await request(`/opportunities/${id}/`, {
		method: "PATCH",
		body: JSON.stringify(data)
	}));
}
async function deleteOpportunity(id) {
	await request(`/opportunities/${id}/`, { method: "DELETE" });
}
async function convertOpportunityToQuotation(opportunityId, companyId, items) {
	return request(`/opportunities/${opportunityId}/convert-to-quotation/`, {
		method: "POST",
		body: JSON.stringify({
			company_id: companyId,
			items
		})
	});
}
async function importLeads(file) {
	const form = new FormData();
	form.append("file", file);
	return request("/leads/import-csv/", {
		method: "POST",
		body: form
	});
}
async function getTemplates() {
	return (await request("/email-templates/")).map(mapTemplate);
}
function templateForm(data) {
	const form = new FormData();
	form.append("channel", data.channel);
	form.append("name", data.name);
	form.append("subject", data.subject);
	form.append("body", data.body);
	form.append("signature", data.signature);
	form.append("wa_template_name", data.waTemplateName ?? "");
	form.append("wa_language", data.waLanguage ?? "");
	if (data.logo) form.append("logo", data.logo);
	if (data.attachment) form.append("attachment", data.attachment);
	return form;
}
async function createTemplate(data) {
	return mapTemplate(await request("/email-templates/", {
		method: "POST",
		body: templateForm(data)
	}));
}
async function updateTemplate(id, data) {
	return mapTemplate(await request(`/email-templates/${id}/`, {
		method: "PATCH",
		body: templateForm(data)
	}));
}
async function deleteTemplate(id) {
	await request(`/email-templates/${id}/`, { method: "DELETE" });
}
async function getSequences() {
	const [sequences, steps] = await Promise.all([request("/email-sequences/"), request("/sequence-steps/")]);
	return sequences.map((sequence) => ({
		id: String(sequence.id),
		name: sequence.name,
		description: sequence.description,
		steps: steps.filter((step) => step.sequence === sequence.id).map((step) => ({
			id: String(step.id),
			templateId: String(step.template),
			delayDays: step.delay_days,
			delayMinutes: step.delay_minutes
		}))
	}));
}
function mapSequence(sequence) {
	return {
		id: String(sequence.id),
		name: sequence.name,
		description: sequence.description,
		steps: (sequence.steps ?? []).map((step) => ({
			id: String(step.id),
			templateId: String(step.template),
			delayDays: step.delay_days,
			delayMinutes: step.delay_minutes
		}))
	};
}
function sequencePayload(data) {
	return {
		name: data.name,
		description: data.description,
		steps: data.steps.map((step, index) => ({
			step_number: index + 1,
			template: Number(step.templateId),
			delay_days: step.delayDays,
			delay_minutes: step.delayMinutes
		}))
	};
}
async function createSequence(data) {
	return mapSequence(await request("/email-sequences/", {
		method: "POST",
		body: JSON.stringify(sequencePayload(data))
	}));
}
async function updateSequence(id, data) {
	return mapSequence(await request(`/email-sequences/${id}/`, {
		method: "PATCH",
		body: JSON.stringify(sequencePayload(data))
	}));
}
async function deleteSequence(id) {
	await request(`/email-sequences/${id}/`, { method: "DELETE" });
}
async function mapBatch(batch) {
	const batchLeads = await request(`/batches/${batch.id}/leads/`);
	return {
		id: String(batch.id),
		name: batch.name,
		sequenceId: batch.sequence === null ? "" : String(batch.sequence),
		replyToEmail: batch.reply_to_email,
		leadIds: batchLeads.map((lead) => String(lead.lead)),
		status: batch.status,
		createdAt: batch.created_at
	};
}
async function getBatches() {
	const batches = await request("/batches/");
	return Promise.all(batches.map(mapBatch));
}
async function createBatch(data) {
	const response = await request("/batches/", {
		method: "POST",
		body: JSON.stringify({
			name: data.name,
			...data.sequenceId ? { sequence: Number(data.sequenceId) } : {},
			reply_to_email: data.replyToEmail || "",
			lead_ids: data.leadIds.map(Number)
		})
	});
	return {
		campaign: await mapBatch(response),
		...response.automatic_email ? { automaticEmail: response.automatic_email } : {}
	};
}
async function updateBatch(id, data) {
	return mapBatch(await request(`/batches/${id}/`, {
		method: "PATCH",
		body: JSON.stringify({
			name: data.name,
			...data.sequenceId !== void 0 ? { sequence: data.sequenceId ? Number(data.sequenceId) : null } : {},
			reply_to_email: data.replyToEmail || "",
			lead_ids: data.leadIds.map(Number)
		})
	}));
}
async function getBatchLeads(id) {
	return (await request(`/batches/${id}/leads/`)).map((lead) => ({
		leadId: String(lead.lead),
		email: lead.email,
		currentStep: lead.current_step,
		lastEmailStatus: lead.completed ? "completed" : "pending",
		replied: lead.replied,
		unsubscribed: lead.unsubscribed,
		unsubscribedAt: lead.unsubscribed_at,
		completed: lead.completed
	}));
}
async function deleteBatch(id) {
	await request(`/batches/${id}/`, { method: "DELETE" });
}
async function getEmailLogs() {
	return (await request("/email-logs/")).map((log) => ({
		id: String(log.id),
		batchId: String(log.batch),
		leadId: String(log.lead),
		step: log.step_number,
		status: log.status,
		sentAt: log.sent_at,
		subject: log.subject,
		templateName: log.template_name ?? "",
		...log.error ? { error: log.error } : {}
	}));
}
async function getRecentEmailLogs() {
	return (await request("/email-logs/?limit=50")).map((log) => ({
		id: String(log.id),
		batchId: String(log.batch),
		leadId: String(log.lead),
		step: log.step_number,
		status: log.status,
		sentAt: log.sent_at,
		subject: log.subject,
		templateName: log.template_name ?? "",
		...log.error ? { error: log.error } : {}
	}));
}
async function pauseBatch(id) {
	await request(`/batches/${id}/pause/`, { method: "PATCH" });
}
async function resumeBatch(id) {
	const response = await request(`/batches/${id}/resume/`, { method: "PATCH" });
	return {
		status: response.status,
		...response.automatic_email ? { automaticEmail: response.automatic_email } : {}
	};
}
async function sendBatchNow(id, data) {
	return request(`/batches/${id}/send-now/`, {
		method: "POST",
		body: JSON.stringify({
			template: Number(data.templateId),
			enquiry_date: data.enquiryDate || ""
		})
	});
}
//#endregion
export { request as A, getTemplates as C, logoutUser as D, loginUser as E, updateLeadStatus as F, updateOpportunity as I, updateSequence as L, sendBatchNow as M, updateBatch as N, pauseBatch as O, updateLead as P, updateTemplate as R, getSequences as S, importLeads as T, getLead as _, createOpportunity as a, getOpportunities as b, deleteBatch as c, deleteSequence as d, deleteTemplate as f, getEmailLogs as g, getCurrentUser as h, createLead as i, resumeBatch as j, registerUser as k, deleteLead as l, getBatches as m, convertOpportunityToQuotation as n, createSequence as o, getBatchLeads as p, createBatch as r, createTemplate as s, clearAuthTokens as t, deleteOpportunity as u, getLeadOptions as v, hasAuthTokens as w, getRecentEmailLogs as x, getLeads as y };
