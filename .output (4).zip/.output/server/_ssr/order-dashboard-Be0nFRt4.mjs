import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { A as request } from "./api-C6hU-8Yn.mjs";
import { _ as RefreshCw } from "../_libs/lucide-react.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as Bar, c as Legend, i as CartesianGrid, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/order-dashboard-Be0nFRt4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function getOrderDashboard(filters) {
	const params = new URLSearchParams({
		period: filters.period,
		year: String(filters.year)
	});
	if (filters.quarter !== void 0) params.set("quarter", String(filters.quarter));
	if (filters.half !== void 0) params.set("half", String(filters.half));
	if (filters.start_date) params.set("start_date", filters.start_date);
	if (filters.end_date) params.set("end_date", filters.end_date);
	return request(`/order-dashboard/?${params.toString()}`);
}
var currentYear = (/* @__PURE__ */ new Date()).getFullYear();
var initialFilters = {
	period: "yearly",
	year: currentYear,
	quarter: 1,
	half: 1,
	start_date: `${currentYear}-01-01`,
	end_date: `${currentYear}-12-31`
};
var currency = new Intl.NumberFormat("en-IN", {
	style: "currency",
	currency: "INR",
	maximumFractionDigits: 0
});
function MetricCard({ title, count, amount, loading }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-md border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-sm text-muted-foreground",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 font-display text-3xl font-bold tabular-nums",
				children: loading ? "—" : count ?? 0
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 text-sm text-muted-foreground",
				children: loading ? " " : currency.format(amount ?? 0)
			})
		]
	});
}
function OrderDashboardPage() {
	const [draftFilters, setDraftFilters] = (0, import_react.useState)(initialFilters);
	const [filters, setFilters] = (0, import_react.useState)(initialFilters);
	const dashboardQuery = useQuery({
		queryKey: ["order-dashboard", filters],
		queryFn: () => getOrderDashboard(filters)
	});
	const data = dashboardQuery.data;
	const summary = data?.summary;
	const updateDraft = (key, value) => {
		setDraftFilters((current) => ({
			...current,
			[key]: value
		}));
	};
	const applyFilters = () => {
		setFilters({
			...draftFilters,
			year: Number(draftFilters.year)
		});
	};
	const resetFilters = () => {
		const reset = {
			...initialFilters,
			year: currentYear
		};
		setDraftFilters(reset);
		setFilters(reset);
	};
	const monthlyData = data?.monthly_history ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-mono text-[11px] tracking-wide text-muted-foreground",
						children: "ORDERS"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-display text-3xl font-bold tracking-tight",
						children: "Order Dashboard"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: data ? `${data.period} · ${data.start_date} to ${data.end_date}` : "Quotation through sales order"
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "space-y-1 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs font-medium text-muted-foreground",
								children: "Period"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: "h-10 rounded-md border border-input bg-background px-3 text-sm",
								value: draftFilters.period,
								onChange: (event) => updateDraft("period", event.target.value),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "yearly",
										children: "Yearly"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "quarterly",
										children: "Quarterly"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "half_yearly",
										children: "Half-yearly"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "custom",
										children: "Custom range"
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "space-y-1 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs font-medium text-muted-foreground",
								children: "Year"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: 1,
								max: 9998,
								className: "w-28",
								value: draftFilters.year,
								onChange: (event) => updateDraft("year", Number(event.target.value))
							})]
						}),
						draftFilters.period === "quarterly" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "space-y-1 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs font-medium text-muted-foreground",
								children: "Quarter"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "h-10 rounded-md border border-input bg-background px-3 text-sm",
								value: draftFilters.quarter,
								onChange: (event) => updateDraft("quarter", Number(event.target.value)),
								children: [
									1,
									2,
									3,
									4
								].map((quarter) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: quarter,
									children: ["Q", quarter]
								}, quarter))
							})]
						}),
						draftFilters.period === "half_yearly" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "space-y-1 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs font-medium text-muted-foreground",
								children: "Half"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: "h-10 rounded-md border border-input bg-background px-3 text-sm",
								value: draftFilters.half,
								onChange: (event) => updateDraft("half", Number(event.target.value)),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: 1,
									children: "First half"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: 2,
									children: "Second half"
								})]
							})]
						}),
						draftFilters.period === "custom" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "space-y-1 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs font-medium text-muted-foreground",
								children: "Start date"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								className: "w-auto",
								value: draftFilters.start_date ?? "",
								onChange: (event) => updateDraft("start_date", event.target.value)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "space-y-1 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs font-medium text-muted-foreground",
								children: "End date"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								className: "w-auto",
								value: draftFilters.end_date ?? "",
								onChange: (event) => updateDraft("end_date", event.target.value)
							})]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							onClick: applyFilters,
							disabled: dashboardQuery.isFetching || !draftFilters.year,
							children: "Apply"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: () => void dashboardQuery.refetch(),
							disabled: dashboardQuery.isFetching,
							"aria-label": "Refresh order dashboard",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `size-4 ${dashboardQuery.isFetching ? "animate-spin" : ""}` })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: resetFilters,
							children: "Reset"
						})
					]
				})]
			}),
			dashboardQuery.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "text-sm text-destructive",
				children: dashboardQuery.error.message || "Could not load the order dashboard."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				"aria-label": "Order stages",
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold",
					children: "Commercial stages"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricCard, {
							title: "Quotations",
							count: summary?.total_quotations,
							amount: summary?.quotations_amount,
							loading: dashboardQuery.isLoading
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricCard, {
							title: "Final offers",
							count: summary?.fo_generated,
							amount: summary?.fo_amount,
							loading: dashboardQuery.isLoading
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricCard, {
							title: "Customer POs",
							count: summary?.cpo_received,
							amount: summary?.cpo_amount,
							loading: dashboardQuery.isLoading
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricCard, {
							title: "Sales orders",
							count: summary?.total_so,
							amount: summary?.so_amount,
							loading: dashboardQuery.isLoading
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				"aria-label": "Conversion rates",
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold",
					children: "Conversion rates"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConversionCard, {
							title: "Quotation → Final Offer",
							value: summary?.conversion_rates.quotation_to_fo,
							loading: dashboardQuery.isLoading
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConversionCard, {
							title: "Quotation → Customer PO",
							value: summary?.conversion_rates.quotation_to_cpo,
							loading: dashboardQuery.isLoading
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConversionCard, {
							title: "Customer PO → Sales Order",
							value: summary?.conversion_rates.cpo_to_sales_order,
							loading: dashboardQuery.isLoading
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-md border border-line bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "Monthly order pipeline"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: "Document counts by month"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-[340px] w-full",
					children: monthlyData.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
							data: monthlyData,
							margin: {
								top: 8,
								right: 8,
								left: 0,
								bottom: 4
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
									strokeDasharray: "3 3",
									vertical: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "month",
									tickLine: false,
									axisLine: false,
									minTickGap: 16
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									allowDecimals: false,
									tickLine: false,
									axisLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "quotations",
									name: "Quotations",
									fill: "#4f46e5",
									radius: [
										3,
										3,
										0,
										0
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "fo",
									name: "Final offers",
									fill: "#0f766e",
									radius: [
										3,
										3,
										0,
										0
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "cpo",
									name: "Customer POs",
									fill: "#d97706",
									radius: [
										3,
										3,
										0,
										0
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "so",
									name: "Sales orders",
									fill: "#2563eb",
									radius: [
										3,
										3,
										0,
										0
									]
								})
							]
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-full place-items-center text-sm text-muted-foreground",
						children: dashboardQuery.isLoading ? "Loading monthly history…" : "No order history for this period."
					})
				})]
			})
		]
	});
}
function ConversionCard({ title, value, loading }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-md border border-line bg-surface p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-sm text-muted-foreground",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 font-display text-3xl font-bold tabular-nums",
			children: loading ? "—" : `${value ?? 0}%`
		})]
	});
}
//#endregion
export { OrderDashboardPage as component };
