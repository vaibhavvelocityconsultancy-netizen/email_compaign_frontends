import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/leads.form-CmvbFVLX.js
var $$splitComponentImporter = () => import("./leads.form-CcKtBx_8.mjs");
var Route = createFileRoute("/marketing/leads/form")({
	validateSearch: (search) => ({ leadId: typeof search.leadId === "string" ? search.leadId : void 0 }),
	head: () => ({ meta: [{ title: "Lead Form — Vantage CRM" }, {
		name: "description",
		content: "Create or update an enquiry."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
