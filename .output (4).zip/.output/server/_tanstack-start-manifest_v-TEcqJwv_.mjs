//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-TEcqJwv_.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/crm/email_compaign_frontends/src/routes/__root.tsx",
		children: [
			"/",
			"/access-control",
			"/company",
			"/country",
			"/customer-po",
			"/final-offer",
			"/location",
			"/login",
			"/marketing",
			"/order-dashboard",
			"/register",
			"/roles",
			"/tasks",
			"/user",
			"/sales/opportunities",
			"/sales/orders",
			"/sales/quotations",
			"/sales/"
		],
		preloads: [
			"/assets/index-Cx2PLw8p.js",
			"/assets/jsx-runtime-OQpaS_Dv.js",
			"/assets/react-dom-Ch54GZ4s.js",
			"/assets/Match-5cQgR4sj.js",
			"/assets/preload-helper-ChS5vP1f.js",
			"/assets/utils-DCvbpOtd.js",
			"/assets/link-CAl-Sa9v.js",
			"/assets/useMatch-BaG-rLLV.js",
			"/assets/matchContext-BLd14XSO.js",
			"/assets/useSelector-yWwUHw1M.js",
			"/assets/useRouter-FQeUpUVO.js",
			"/assets/useNavigate-bMnaDzZT.js",
			"/assets/useQuery-CRu0Hu6y.js",
			"/assets/useMutation-BT3iAFGa.js",
			"/assets/createLucideIcon-5JRSLlvH.js",
			"/assets/DataTable-DGJqtzCb.js",
			"/assets/x-DFhNn4Ci.js",
			"/assets/button-D0UaAm5H.js",
			"/assets/input-DoHRrl0J.js",
			"/assets/dist-DYAUkNtW.js",
			"/assets/api-DiNx14Dp.js",
			"/assets/Modal-BZsGyKA9.js",
			"/assets/types-CTeloYrU.js",
			"/assets/quotation-api-BzTvprZm.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Cx2PLw8p.js"
		} }]
	},
	"/": {
		filePath: "D:/crm/email_compaign_frontends/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-ecovh3Ym.js",
			"/assets/arrow-up-right-Dv0z1hcs.js",
			"/assets/StatCard-Ef07sW3W.js"
		]
	},
	"/company": {
		filePath: "D:/crm/email_compaign_frontends/src/routes/company.tsx",
		children: void 0,
		preloads: ["/assets/company-BZB7QiCT.js", "/assets/company-api-DUECAcEi.js"]
	},
	"/country": {
		filePath: "D:/crm/email_compaign_frontends/src/routes/country.tsx",
		children: void 0,
		preloads: ["/assets/country-C4DJTpz-.js"]
	},
	"/customer-po": {
		filePath: "D:/crm/email_compaign_frontends/src/routes/customer-po.tsx",
		children: void 0,
		preloads: [
			"/assets/customer-po-Dm8_DBXm.js",
			"/assets/file-text-CLhUqrtI.js",
			"/assets/shopping-cart-DWwt8raz.js",
			"/assets/upload-CDjpU4YU.js"
		]
	},
	"/final-offer": {
		filePath: "D:/crm/email_compaign_frontends/src/routes/final-offer.tsx",
		children: void 0,
		preloads: [
			"/assets/final-offer-0Q0UBFEN.js",
			"/assets/file-text-CLhUqrtI.js",
			"/assets/drawer-DhfOT8D-.js"
		]
	},
	"/location": {
		filePath: "D:/crm/email_compaign_frontends/src/routes/location.tsx",
		children: void 0,
		preloads: [
			"/assets/location-FSVxxy91.js",
			"/assets/EntityForm-bK7xVafJ.js",
			"/assets/tabs-lUnYi1fc.js"
		]
	},
	"/login": {
		filePath: "D:/crm/email_compaign_frontends/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-DDn0c4JO.js", "/assets/AuthLayout-C7fLr7ki.js"]
	},
	"/marketing": {
		filePath: "D:/crm/email_compaign_frontends/src/routes/marketing.tsx",
		children: ["/marketing/email-campaign", "/marketing/leads"],
		preloads: [
			"/assets/marketing-Dir4KQHG.js",
			"/assets/EmptyState-DDcb9rny.js",
			"/assets/StatCard-Ef07sW3W.js",
			"/assets/StatusBadge-CxXEaw6p.js"
		]
	},
	"/order-dashboard": {
		filePath: "D:/crm/email_compaign_frontends/src/routes/order-dashboard.tsx",
		children: void 0,
		preloads: ["/assets/order-dashboard-BpUTFLdY.js"]
	},
	"/register": {
		filePath: "D:/crm/email_compaign_frontends/src/routes/register.tsx",
		children: void 0,
		preloads: ["/assets/register-JHeGc40T.js", "/assets/AuthLayout-C7fLr7ki.js"]
	},
	"/tasks": {
		filePath: "D:/crm/email_compaign_frontends/src/routes/tasks.tsx",
		children: [
			"/tasks/dashboard",
			"/tasks/form",
			"/tasks/"
		],
		preloads: ["/assets/tasks-OfWf9uOh.js"]
	},
	"/marketing/email-campaign": {
		filePath: "D:/crm/email_compaign_frontends/src/routes/marketing/email-campaign.tsx",
		children: [
			"/marketing/email-campaign/campaigns",
			"/marketing/email-campaign/logs",
			"/marketing/email-campaign/sequences",
			"/marketing/email-campaign/templates",
			"/marketing/email-campaign/"
		],
		preloads: ["/assets/email-campaign-Y2LS2j8f.js"]
	},
	"/marketing/leads": {
		filePath: "D:/crm/email_compaign_frontends/src/routes/marketing/leads.tsx",
		children: ["/marketing/leads/form"],
		preloads: ["/assets/leads-b_vHyq7d.js", "/assets/upload-CDjpU4YU.js"]
	},
	"/sales/opportunities": {
		filePath: "D:/crm/email_compaign_frontends/src/routes/sales/opportunities.tsx",
		children: void 0,
		preloads: [
			"/assets/opportunities-Dhce4-d3.js",
			"/assets/EntityForm-bK7xVafJ.js",
			"/assets/file-text-CLhUqrtI.js",
			"/assets/company-api-DUECAcEi.js",
			"/assets/drawer-DhfOT8D-.js",
			"/assets/StatusBadge-CxXEaw6p.js"
		]
	},
	"/sales/orders": {
		filePath: "D:/crm/email_compaign_frontends/src/routes/sales/orders.tsx",
		children: void 0,
		preloads: ["/assets/orders-BDLz9lUh.js", "/assets/company-api-DUECAcEi.js"]
	},
	"/sales/quotations": {
		filePath: "D:/crm/email_compaign_frontends/src/routes/sales/quotations.tsx",
		children: void 0,
		preloads: [
			"/assets/quotations-B5YaAGbc.js",
			"/assets/EntityForm-bK7xVafJ.js",
			"/assets/company-api-DUECAcEi.js",
			"/assets/drawer-DhfOT8D-.js",
			"/assets/StatusBadge-CxXEaw6p.js"
		]
	},
	"/tasks/dashboard": {
		filePath: "D:/crm/email_compaign_frontends/src/routes/tasks/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-Bs6etAPD.js",
			"/assets/calendar-days-5GeYs19G.js",
			"/assets/target-BOizoJuW.js",
			"/assets/triangle-alert-DsgdhYG4.js"
		]
	},
	"/tasks/form": {
		filePath: "D:/crm/email_compaign_frontends/src/routes/tasks/form.tsx",
		children: void 0,
		preloads: [
			"/assets/form-D41_cX0T.js",
			"/assets/save-CK_SGmB_.js",
			"/assets/eye-4pwqTTee.js",
			"/assets/textarea-CY-dYm-r.js"
		]
	},
	"/sales/": {
		filePath: "D:/crm/email_compaign_frontends/src/routes/sales/index.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-DLPnmiQo.js",
			"/assets/arrow-up-right-Dv0z1hcs.js",
			"/assets/file-text-CLhUqrtI.js",
			"/assets/shopping-cart-DWwt8raz.js",
			"/assets/target-BOizoJuW.js"
		]
	},
	"/marketing/email-campaign/campaigns": {
		filePath: "D:/crm/email_compaign_frontends/src/routes/marketing/email-campaign.campaigns.tsx",
		children: void 0,
		preloads: ["/assets/email-campaign.campaigns-BjBrQIYE.js", "/assets/eye-4pwqTTee.js"]
	},
	"/marketing/email-campaign/logs": {
		filePath: "D:/crm/email_compaign_frontends/src/routes/marketing/email-campaign.logs.tsx",
		children: void 0,
		preloads: ["/assets/email-campaign.logs-y2giOEv8.js"]
	},
	"/marketing/email-campaign/sequences": {
		filePath: "D:/crm/email_compaign_frontends/src/routes/marketing/email-campaign.sequences.tsx",
		children: void 0,
		preloads: [
			"/assets/email-campaign.sequences-PAMqYybu.js",
			"/assets/EntityForm-bK7xVafJ.js",
			"/assets/triangle-alert-DsgdhYG4.js"
		]
	},
	"/marketing/email-campaign/templates": {
		filePath: "D:/crm/email_compaign_frontends/src/routes/marketing/email-campaign.templates.tsx",
		children: void 0,
		preloads: [
			"/assets/email-campaign.templates-DsTl6vLq.js",
			"/assets/EntityForm-bK7xVafJ.js",
			"/assets/tabs-lUnYi1fc.js"
		]
	},
	"/marketing/leads/form": {
		filePath: "D:/crm/email_compaign_frontends/src/routes/marketing/leads.form.tsx",
		children: void 0,
		preloads: [
			"/assets/leads.form-DDzMQCHI.js",
			"/assets/save-CK_SGmB_.js",
			"/assets/target-BOizoJuW.js",
			"/assets/company-api-DUECAcEi.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
