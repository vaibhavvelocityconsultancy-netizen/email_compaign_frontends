//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-HDNay-Sq.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/__root.tsx",
		children: [
			"/",
			"/access-control",
			"/company",
			"/country",
			"/customer-po",
			"/final-offer",
			"/location",
			"/login",
			"/marketing",
			"/order-dashboard",
			"/register",
			"/roles",
			"/tasks",
			"/user",
			"/sales/opportunities",
			"/sales/orders",
			"/sales/quotations",
			"/sales/"
		],
		preloads: [
			"/vc_email_crm/assets/index-D6ozGieH.js",
			"/vc_email_crm/assets/jsx-runtime-OQpaS_Dv.js",
			"/vc_email_crm/assets/react-dom-Ch54GZ4s.js",
			"/vc_email_crm/assets/Match-5cQgR4sj.js",
			"/vc_email_crm/assets/preload-helper-C-BKGnPd.js",
			"/vc_email_crm/assets/utils-DCvbpOtd.js",
			"/vc_email_crm/assets/link-CAl-Sa9v.js",
			"/vc_email_crm/assets/useMatch-BaG-rLLV.js",
			"/vc_email_crm/assets/matchContext-BLd14XSO.js",
			"/vc_email_crm/assets/useSelector-yWwUHw1M.js",
			"/vc_email_crm/assets/useRouter-FQeUpUVO.js",
			"/vc_email_crm/assets/useNavigate-bMnaDzZT.js",
			"/vc_email_crm/assets/useQuery-CRu0Hu6y.js",
			"/vc_email_crm/assets/useMutation-BT3iAFGa.js",
			"/vc_email_crm/assets/createLucideIcon-5JRSLlvH.js",
			"/vc_email_crm/assets/DataTable-DGJqtzCb.js",
			"/vc_email_crm/assets/x-DFhNn4Ci.js",
			"/vc_email_crm/assets/button-D0UaAm5H.js",
			"/vc_email_crm/assets/input-DoHRrl0J.js",
			"/vc_email_crm/assets/dist-DYAUkNtW.js",
			"/vc_email_crm/assets/api-BH3BFEe5.js",
			"/vc_email_crm/assets/Modal-BZsGyKA9.js",
			"/vc_email_crm/assets/types-CTeloYrU.js",
			"/vc_email_crm/assets/quotation-api-DlxA7ewX.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/vc_email_crm/assets/index-D6ozGieH.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/routes-CsQud-HG.js",
			"/vc_email_crm/assets/arrow-up-right-Dv0z1hcs.js",
			"/vc_email_crm/assets/StatCard-Ef07sW3W.js"
		]
	},
	"/company": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/company.tsx",
		children: void 0,
		preloads: ["/vc_email_crm/assets/company-C94i7daA.js", "/vc_email_crm/assets/company-api-1JZz-WHr.js"]
	},
	"/country": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/country.tsx",
		children: void 0,
		preloads: ["/vc_email_crm/assets/country-C4DJTpz-.js"]
	},
	"/customer-po": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/customer-po.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/customer-po-CAZKCOmt.js",
			"/vc_email_crm/assets/file-text-CLhUqrtI.js",
			"/vc_email_crm/assets/shopping-cart-DWwt8raz.js",
			"/vc_email_crm/assets/upload-CDjpU4YU.js"
		]
	},
	"/final-offer": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/final-offer.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/final-offer-BQBNz44k.js",
			"/vc_email_crm/assets/file-text-CLhUqrtI.js",
			"/vc_email_crm/assets/drawer-DhfOT8D-.js"
		]
	},
	"/location": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/location.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/location-Cm-lKwlU.js",
			"/vc_email_crm/assets/EntityForm-Bh8cbCZY.js",
			"/vc_email_crm/assets/tabs-lPFJKgxb.js"
		]
	},
	"/login": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/login.tsx",
		children: void 0,
		preloads: ["/vc_email_crm/assets/login-D5uPk7jV.js", "/vc_email_crm/assets/AuthLayout-D50ecPjc.js"]
	},
	"/marketing": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/marketing.tsx",
		children: ["/marketing/email-campaign", "/marketing/leads"],
		preloads: [
			"/vc_email_crm/assets/marketing-BUE8f0zw.js",
			"/vc_email_crm/assets/EmptyState-DDcb9rny.js",
			"/vc_email_crm/assets/StatCard-Ef07sW3W.js",
			"/vc_email_crm/assets/StatusBadge-CxXEaw6p.js"
		]
	},
	"/order-dashboard": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/order-dashboard.tsx",
		children: void 0,
		preloads: ["/vc_email_crm/assets/order-dashboard-B5mBlMVf.js"]
	},
	"/register": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/register.tsx",
		children: void 0,
		preloads: ["/vc_email_crm/assets/register-DCi-_yIl.js", "/vc_email_crm/assets/AuthLayout-D50ecPjc.js"]
	},
	"/tasks": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/tasks.tsx",
		children: [
			"/tasks/dashboard",
			"/tasks/form",
			"/tasks/"
		],
		preloads: ["/vc_email_crm/assets/tasks-OfWf9uOh.js"]
	},
	"/marketing/email-campaign": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/marketing/email-campaign.tsx",
		children: [
			"/marketing/email-campaign/campaigns",
			"/marketing/email-campaign/logs",
			"/marketing/email-campaign/sequences",
			"/marketing/email-campaign/templates",
			"/marketing/email-campaign/"
		],
		preloads: ["/vc_email_crm/assets/email-campaign-Y2LS2j8f.js"]
	},
	"/marketing/leads": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/marketing/leads.tsx",
		children: ["/marketing/leads/form"],
		preloads: ["/vc_email_crm/assets/leads-CdrmDUJY.js", "/vc_email_crm/assets/upload-CDjpU4YU.js"]
	},
	"/sales/opportunities": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/sales/opportunities.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/opportunities-B1TDWN5e.js",
			"/vc_email_crm/assets/EntityForm-Bh8cbCZY.js",
			"/vc_email_crm/assets/file-text-CLhUqrtI.js",
			"/vc_email_crm/assets/company-api-1JZz-WHr.js",
			"/vc_email_crm/assets/drawer-DhfOT8D-.js",
			"/vc_email_crm/assets/StatusBadge-CxXEaw6p.js"
		]
	},
	"/sales/orders": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/sales/orders.tsx",
		children: void 0,
		preloads: ["/vc_email_crm/assets/orders-PJZUugCn.js", "/vc_email_crm/assets/company-api-1JZz-WHr.js"]
	},
	"/sales/quotations": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/sales/quotations.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/quotations-C2lLP7F5.js",
			"/vc_email_crm/assets/EntityForm-Bh8cbCZY.js",
			"/vc_email_crm/assets/company-api-1JZz-WHr.js",
			"/vc_email_crm/assets/drawer-DhfOT8D-.js",
			"/vc_email_crm/assets/StatusBadge-CxXEaw6p.js"
		]
	},
	"/tasks/dashboard": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/tasks/dashboard.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/dashboard-G0Ynk01G.js",
			"/vc_email_crm/assets/calendar-days-5GeYs19G.js",
			"/vc_email_crm/assets/target-BOizoJuW.js",
			"/vc_email_crm/assets/triangle-alert-DsgdhYG4.js"
		]
	},
	"/tasks/form": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/tasks/form.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/form-Cq9Vx7AJ.js",
			"/vc_email_crm/assets/save-CK_SGmB_.js",
			"/vc_email_crm/assets/eye-4pwqTTee.js",
			"/vc_email_crm/assets/textarea-CY-dYm-r.js"
		]
	},
	"/sales/": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/sales/index.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/sales-DLPnmiQo.js",
			"/vc_email_crm/assets/arrow-up-right-Dv0z1hcs.js",
			"/vc_email_crm/assets/file-text-CLhUqrtI.js",
			"/vc_email_crm/assets/shopping-cart-DWwt8raz.js",
			"/vc_email_crm/assets/target-BOizoJuW.js"
		]
	},
	"/marketing/email-campaign/campaigns": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/marketing/email-campaign.campaigns.tsx",
		children: void 0,
		preloads: ["/vc_email_crm/assets/email-campaign.campaigns-Dkbx1jjd.js", "/vc_email_crm/assets/eye-4pwqTTee.js"]
	},
	"/marketing/email-campaign/logs": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/marketing/email-campaign.logs.tsx",
		children: void 0,
		preloads: ["/vc_email_crm/assets/email-campaign.logs-BE-QMoUz.js"]
	},
	"/marketing/email-campaign/sequences": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/marketing/email-campaign.sequences.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/email-campaign.sequences-CiJQsn6P.js",
			"/vc_email_crm/assets/EntityForm-Bh8cbCZY.js",
			"/vc_email_crm/assets/triangle-alert-DsgdhYG4.js"
		]
	},
	"/marketing/email-campaign/templates": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/marketing/email-campaign.templates.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/email-campaign.templates-CsgmzjYO.js",
			"/vc_email_crm/assets/EntityForm-Bh8cbCZY.js",
			"/vc_email_crm/assets/tabs-lPFJKgxb.js"
		]
	},
	"/marketing/leads/form": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/marketing/leads.form.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/leads.form-BHAkdvHq.js",
			"/vc_email_crm/assets/save-CK_SGmB_.js",
			"/vc_email_crm/assets/target-BOizoJuW.js",
			"/vc_email_crm/assets/company-api-1JZz-WHr.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
