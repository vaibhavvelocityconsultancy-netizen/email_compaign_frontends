import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as enumType, c as objectType, l as stringType, r as booleanType, s as numberType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/form-xWOu5Kga.js
var $$splitComponentImporter = () => import("./form-ykRfte1g.mjs");
var Route = createFileRoute("/tasks/form")({
	validateSearch: (search) => ({
		taskId: typeof search.taskId === "string" ? search.taskId : void 0,
		module: search.module === "LEAD" || search.module === "OPPORTUNITY" || search.module === "QUOTATION" ? search.module : void 0,
		companyId: typeof search.companyId === "string" ? search.companyId : void 0,
		referenceId: typeof search.referenceId === "string" ? search.referenceId : void 0
	}),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
objectType({
	description: stringType(),
	module: enumType([
		"",
		"LEAD",
		"OPPORTUNITY",
		"QUOTATION"
	]),
	task_regarding: stringType().min(1, "Select what the task is regarding"),
	reference_id: stringType().min(1, "Select an enquiry date or quotation number"),
	company: stringType().min(1, "Select a company"),
	followup_date: stringType().min(1, "Follow-up date is required"),
	priority: enumType([
		"LOW",
		"MEDIUM",
		"HIGH",
		"URGENT"
	]),
	status: enumType([
		"PENDING",
		"IN_PROGRESS",
		"COMPLETED",
		"CANCELLED"
	]),
	assigned_to: stringType(),
	remarks: stringType(),
	is_recurring: booleanType(),
	repeat_frequency: stringType(),
	repeat_interval: numberType().int().min(1, "Repeat interval must be at least 1"),
	repeat_end_date: stringType()
}).superRefine((values, context) => {
	if (!values.module) context.addIssue({
		code: "custom",
		path: ["module"],
		message: "Select a module"
	});
	if (values.is_recurring && !values.repeat_frequency) context.addIssue({
		code: "custom",
		path: ["repeat_frequency"],
		message: "Select a repeat frequency"
	});
});
//#endregion
export { Route as t };
