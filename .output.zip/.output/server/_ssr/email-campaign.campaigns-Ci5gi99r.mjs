import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { A as resumeBatch, D as pauseBatch, c as deleteBatch, g as getEmailLogs, j as updateBatch, m as getBatches, p as getBatchLeads, r as createBatch, x as getSequences, y as getLeads } from "./api-CrPtMj0Q.mjs";
import { F as Eye, S as Megaphone, _ as Plus, b as Pause, s as Trash2, v as Play, y as Pencil } from "../_libs/lucide-react.mjs";
import { d as Table, f as TableBody, g as TableRow, h as TableHeader, m as TableHead, n as DataTable, p as TableCell } from "./DataTable-DmCzJ7wu.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Modal } from "./Modal-vFtVKTX9.mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as ConfirmDialog } from "./ConfirmDialog-Rjd0NwWp.mjs";
import { c as objectType, l as stringType, n as arrayType, s as numberType } from "../_libs/zod.mjs";
import { t as Route } from "./email-campaign.campaigns-DupQbCLo.mjs";
import { t as StatusBadge } from "./StatusBadge-BMe1mW6r.mjs";
import { t as EmptyState } from "./EmptyState-C9iZmoiO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/email-campaign.campaigns-Ci5gi99r.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
objectType({
	name: stringType().trim().min(1, "Campaign name is required"),
	sequenceId: numberType().int().positive("Choose a sequence"),
	leadIds: arrayType(numberType().int().positive()).min(1, "Choose at least one lead")
});
function CampaignsPage() {
	const queryClient = useQueryClient();
	const navigate = useNavigate();
	const search = Route.useSearch();
	const [formOpen, setFormOpen] = (0, import_react.useState)(false);
	const [editingCampaign, setEditingCampaign] = (0, import_react.useState)(null);
	const [selectedCampaign, setSelectedCampaign] = (0, import_react.useState)(null);
	const [recipientFilter, setRecipientFilter] = (0, import_react.useState)("all");
	const [toDelete, setToDelete] = (0, import_react.useState)(null);
	const [draftReplyToEmail, setDraftReplyToEmail] = (0, import_react.useState)("");
	const campaignsQuery = useQuery({
		queryKey: ["campaigns"],
		queryFn: getBatches
	});
	const leadsQuery = useQuery({
		queryKey: ["leads"],
		queryFn: getLeads
	});
	const sequencesQuery = useQuery({
		queryKey: ["sequences"],
		queryFn: getSequences
	});
	const selectedLeadsQuery = useQuery({
		queryKey: ["campaign-leads", selectedCampaign?.id],
		queryFn: () => getBatchLeads(selectedCampaign.id),
		enabled: Boolean(selectedCampaign)
	});
	const emailLogsQuery = useQuery({
		queryKey: ["logs"],
		queryFn: getEmailLogs
	});
	const selectedCampaignLogs = (0, import_react.useMemo)(() => emailLogsQuery.data?.filter((log) => log.batchId === selectedCampaign?.id) ?? [], [emailLogsQuery.data, selectedCampaign?.id]);
	const visibleCampaignLeads = (0, import_react.useMemo)(() => (selectedLeadsQuery.data ?? []).filter((lead) => recipientFilter === "all" || (recipientFilter === "unsubscribed" ? lead.unsubscribed : !lead.unsubscribed)), [selectedLeadsQuery.data, recipientFilter]);
	(0, import_react.useEffect)(() => {
		if (!search.create) return;
		setFormOpen(true);
		navigate({
			to: "/marketing/email-campaign/campaigns",
			search: { create: false },
			replace: true
		});
	}, [search.create, navigate]);
	const createMutation = useMutation({
		mutationFn: (values) => createBatch({
			name: values.name,
			sequenceId: String(values.sequenceId),
			leadIds: values.leadIds.map(String),
			replyToEmail: draftReplyToEmail.trim(),
			enquiryDateFrom: dateFrom || void 0,
			enquiryDateTo: dateTo || void 0
		}),
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: ["campaigns"] });
			setFormOpen(false);
			toast.success("Campaign created");
		},
		onError: (error) => toast.error(error.message || "Could not create campaign")
	});
	const editMutation = useMutation({
		mutationFn: ({ campaign, values }) => updateBatch(campaign.id, {
			name: values.name,
			sequenceId: String(values.sequenceId),
			leadIds: values.leadIds.map(String),
			replyToEmail: draftReplyToEmail.trim(),
			enquiryDateFrom: dateFrom || void 0,
			enquiryDateTo: dateTo || void 0
		}),
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: ["campaigns"] });
			setFormOpen(false);
			setEditingCampaign(null);
			toast.success("Campaign updated");
		},
		onError: (error) => toast.error(error.message || "Could not update campaign")
	});
	const statusMutation = useMutation({
		mutationFn: ({ campaign, action }) => action === "pause" ? pauseBatch(campaign.id) : resumeBatch(campaign.id),
		onSuccess: async (_, variables) => {
			await queryClient.invalidateQueries({ queryKey: ["campaigns"] });
			toast.success(variables.action === "pause" ? "Campaign paused" : "Campaign resumed");
		},
		onError: (error) => toast.error(error.message || "Could not update campaign")
	});
	const deleteMutation = useMutation({
		mutationFn: deleteBatch,
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: ["campaigns"] });
			setToDelete(null);
			toast.success("Campaign deleted");
		},
		onError: (error) => toast.error(error.message || "Could not delete campaign")
	});
	const leads = leadsQuery.data ?? [];
	const sequences = sequencesQuery.data ?? [];
	const leadById = (0, import_react.useMemo)(() => new Map(leads.map((lead) => [lead.id, lead])), [leads]);
	const sequenceById = (0, import_react.useMemo)(() => new Map(sequences.map((sequence) => [sequence.id, sequence])), [sequences]);
	const columns = (0, import_react.useMemo)(() => [
		{
			key: "name",
			header: "Campaign",
			cell: (campaign) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium",
				children: campaign.name
			})
		},
		{
			key: "sequenceId",
			header: "Sequence",
			filterValue: (campaign) => sequenceById.get(campaign.sequenceId)?.name ?? "Unknown",
			cell: (campaign) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground",
				children: sequenceById.get(campaign.sequenceId)?.name ?? "Unknown sequence"
			})
		},
		{
			key: "leadIds",
			header: "Leads",
			filterable: false,
			sortable: false,
			cell: (campaign) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-xs",
				children: campaign.leadIds.length.toLocaleString()
			})
		},
		{
			key: "status",
			header: "Status",
			cell: (campaign) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: campaign.status })
		},
		{
			key: "enquiryDateFrom",
			header: "Created",
			filterType: "date",
			filterValue: (campaign) => campaign.enquiryDateFrom,
			cell: (campaign) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-[11px] text-muted-foreground",
				children: campaign.enquiryDateFrom ? new Date(campaign.enquiryDateFrom).toLocaleDateString() : "—"
			})
		},
		{
			key: "actions",
			header: "Actions",
			filterable: false,
			sortable: false,
			className: "text-right",
			headerClassName: "text-right",
			cell: (campaign) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-end gap-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						className: "size-8",
						title: "View campaign leads",
						"aria-label": "View campaign leads",
						onClick: () => setSelectedCampaign(campaign),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						className: "size-8",
						title: "Edit campaign",
						"aria-label": "Edit campaign",
						onClick: () => {
							setEditingCampaign(campaign);
							setFormOpen(true);
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {})
					}),
					campaign.status !== "completed" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						className: "size-8",
						title: campaign.status === "paused" ? "Resume campaign" : "Pause campaign",
						"aria-label": campaign.status === "paused" ? "Resume campaign" : "Pause campaign",
						disabled: statusMutation.isPending,
						onClick: () => statusMutation.mutate({
							campaign,
							action: campaign.status === "paused" ? "resume" : "pause"
						}),
						children: campaign.status === "paused" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						className: "size-8 text-destructive hover:text-destructive",
						title: "Delete campaign",
						"aria-label": "Delete campaign",
						onClick: () => setToDelete(campaign),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
					})
				]
			})
		}
	], [sequenceById, statusMutation]);
	const [draftName, setDraftName] = (0, import_react.useState)("");
	const [draftSequenceId, setDraftSequenceId] = (0, import_react.useState)("");
	const [draftLeadIds, setDraftLeadIds] = (0, import_react.useState)([]);
	const [leadSearch, setLeadSearch] = (0, import_react.useState)("");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("all");
	const [sourceFilter, setSourceFilter] = (0, import_react.useState)("all");
	const [dateFrom, setDateFrom] = (0, import_react.useState)("");
	const [dateTo, setDateTo] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!formOpen) return;
		if (editingCampaign) {
			setDraftName(editingCampaign.name);
			setDraftSequenceId(String(editingCampaign.sequenceId));
			setDraftReplyToEmail(editingCampaign.replyToEmail);
			setDraftLeadIds(editingCampaign.leadIds.map((leadId) => Number(leadId)));
			setDateFrom(editingCampaign.enquiryDateFrom ?? "");
			setDateTo(editingCampaign.enquiryDateTo ?? "");
		} else {
			setDraftName("");
			setDraftSequenceId("");
			setDraftReplyToEmail("");
			setDraftLeadIds([]);
			setDateFrom("");
			setDateTo("");
		}
		setLeadSearch("");
		setStatusFilter("all");
		setSourceFilter("all");
	}, [formOpen, editingCampaign]);
	const filteredLeads = (0, import_react.useMemo)(() => {
		return leads.filter((lead) => {
			const searchText = leadSearch.trim().toLowerCase();
			const matchesSearch = !searchText || String(lead.srNo).includes(searchText) || lead.enquiryFor.toLowerCase().includes(searchText) || lead.companyName.toLowerCase().includes(searchText) || lead.contactName.toLowerCase().includes(searchText);
			const matchesStatus = statusFilter === "all" || lead.status === statusFilter;
			const matchesSource = sourceFilter === "all" || lead.source === sourceFilter;
			const leadCreated = /* @__PURE__ */ new Date(`${lead.enquiryDate}T00:00:00`);
			const matchesFrom = !dateFrom || leadCreated >= new Date(dateFrom);
			const matchesTo = !dateTo || leadCreated <= /* @__PURE__ */ new Date(`${dateTo}T23:59:59`);
			return matchesSearch && matchesStatus && matchesSource && matchesFrom && matchesTo;
		});
	}, [
		leads,
		leadSearch,
		statusFilter,
		sourceFilter,
		dateFrom,
		dateTo
	]);
	const toggleLead = (leadId) => {
		setDraftLeadIds((current) => current.includes(leadId) ? current.filter((id) => id !== leadId) : [...current, leadId]);
	};
	const toggleSelectAll = () => {
		const visibleIds = filteredLeads.map((lead) => Number(lead.id));
		if (visibleIds.every((id) => draftLeadIds.includes(id))) {
			setDraftLeadIds((current) => current.filter((id) => !visibleIds.includes(id)));
			return;
		}
		setDraftLeadIds((current) => Array.from(/* @__PURE__ */ new Set([...current, ...visibleIds])));
	};
	const canCreate = sequences.length > 0 && leads.length > 0;
	const handleCreateCampaign = (event) => {
		event.preventDefault();
		if (!draftName.trim()) {
			toast.error("Campaign name is required");
			return;
		}
		if (!draftSequenceId) {
			toast.error("Please choose a sequence");
			return;
		}
		if (draftLeadIds.length === 0) {
			toast.error("Select at least one lead");
			return;
		}
		const values = {
			name: draftName.trim(),
			sequenceId: Number(draftSequenceId),
			leadIds: draftLeadIds
		};
		if (editingCampaign) {
			editMutation.mutate({
				campaign: editingCampaign,
				values
			});
			return;
		}
		createMutation.mutate({
			name: values.name,
			sequenceId: Number(values.sequenceId),
			leadIds: values.leadIds.map(Number)
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rise flex flex-wrap items-end justify-between gap-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-mono text-[11px] tracking-wide text-muted-foreground",
					children: "OUTREACH"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-3xl font-bold tracking-tight",
					children: "Campaigns"
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rise",
				style: { animationDelay: "80ms" },
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
						data: campaignsQuery.data ?? [],
						columns,
						searchKeys: ["name"],
						searchPlaceholder: "Search campaigns...",
						storageKey: "campaigns",
						emptyMessage: campaignsQuery.isLoading ? "Loading campaigns…" : "No campaigns yet. Create one to enroll leads in a sequence.",
						toolbarActions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							className: "h-9 gap-1.5",
							disabled: !canCreate,
							title: !canCreate ? "Create a lead and sequence first" : void 0,
							onClick: () => setFormOpen(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " New campaign"]
						})
					}),
					campaignsQuery.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-destructive",
						children: campaignsQuery.error.message
					}),
					!canCreate && !leadsQuery.isLoading && !sequencesQuery.isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 flex items-center gap-2 text-xs text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Megaphone, { className: "size-4" }), " Add at least one lead and one sequence before launching a campaign."]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
				open: formOpen,
				onClose: () => {
					setFormOpen(false);
					setEditingCampaign(null);
				},
				title: editingCampaign ? "Edit Campaign Batch" : "Create Campaign Batch",
				wide: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleCreateCampaign,
					className: "bg-surface px-5 pb-5 pt-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 md:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "md:col-span-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "mb-2 block text-sm font-medium text-foreground",
									children: "Campaign Name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: draftName,
									onChange: (event) => setDraftName(event.target.value),
									className: "h-12 w-full rounded-xl border border-[#2f80ed] bg-background px-3 text-sm text-foreground outline-none ring-0 focus:border-[#2f80ed]",
									placeholder: "e.g. Jan 2025 Outreach"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "md:col-span-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "mb-2 block text-sm font-medium text-foreground",
									children: "Sequence"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: draftSequenceId,
									onChange: (event) => setDraftSequenceId(event.target.value),
									className: "h-12 w-full appearance-none rounded-xl border border-input bg-background px-3 text-sm text-foreground outline-none focus:border-[#2f80ed]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Select sequence"
									}), sequences.map((sequence) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: sequence.id,
										children: sequence.name
									}, sequence.id))]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "mb-2 block text-sm font-medium text-foreground",
								children: "Reply-to email"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "email",
								value: draftReplyToEmail,
								onChange: (event) => setDraftReplyToEmail(event.target.value),
								className: "h-12 w-full rounded-xl border border-input bg-background px-3 text-sm text-foreground outline-none focus:border-[#2f80ed]",
								placeholder: "Replies go to the default sender if blank"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center justify-between gap-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "text-sm font-medium text-foreground",
										children: "Filter Leads"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-4 md:grid-cols-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: leadSearch,
										onChange: (event) => setLeadSearch(event.target.value),
										className: "h-12 w-full rounded-xl border border-input bg-background px-3 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-[#2f80ed]",
										placeholder: "Search company..."
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: statusFilter,
										onChange: (event) => setStatusFilter(event.target.value),
										className: "h-12 w-full appearance-none rounded-xl border border-input bg-background px-3 text-sm text-foreground outline-none focus:border-[#2f80ed]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "all",
												children: "All Status"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "new",
												children: "New"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "active",
												children: "Active"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "hot",
												children: "Hot"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "cold",
												children: "Cold"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "junk",
												children: "Junk"
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-4 md:grid-cols-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: sourceFilter,
										onChange: (event) => setSourceFilter(event.target.value),
										className: "h-12 w-full appearance-none rounded-xl border border-input bg-background px-3 text-sm text-foreground outline-none focus:border-[#2f80ed]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "all",
											children: "All Source"
										}), Array.from(new Set(leads.map((lead) => lead.source))).map((source) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: source,
											children: source
										}, source))]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "mb-2 block text-xs font-medium uppercase tracking-wide text-muted-foreground",
											children: "Enquiry Date From"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "date",
											value: dateFrom,
											onChange: (event) => setDateFrom(event.target.value),
											className: "h-12 w-full rounded-xl border border-input bg-background px-3 text-sm text-foreground outline-none focus:border-[#2f80ed]"
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "mb-2 block text-xs font-medium uppercase tracking-wide text-muted-foreground",
											children: "Enquiry Date To"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "date",
											value: dateTo,
											onChange: (event) => setDateTo(event.target.value),
											className: "h-12 w-full rounded-xl border border-input bg-background px-3 text-sm text-foreground outline-none focus:border-[#2f80ed]"
										})] })]
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-sm font-medium text-foreground",
								children: [
									"Select Leads ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted-foreground",
										children: [filteredLeads.length, " shown"]
									}),
									" · ",
									draftLeadIds.length,
									" selected"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-sm font-medium text-foreground/80 hover:text-foreground",
								onClick: toggleSelectAll,
								children: filteredLeads.length > 0 && filteredLeads.every((lead) => draftLeadIds.includes(Number(lead.id))) ? "Deselect All" : "Select All"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 space-y-2 rounded-xl border border-line bg-background/40 p-1",
							children: filteredLeads.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex min-h-[120px] items-center justify-center text-sm text-muted-foreground",
								children: "No leads match the current filters."
							}) : filteredLeads.map((lead) => {
								const checked = draftLeadIds.includes(Number(lead.id));
								const leadDate = (/* @__PURE__ */ new Date(`${lead.enquiryDate}T00:00:00`)).toLocaleDateString("en-GB");
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: `flex cursor-pointer items-center justify-between gap-4 rounded-xl border px-4 py-3 transition-colors ${checked ? "border-line bg-muted/30" : "border-transparent hover:bg-muted/20"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "checkbox",
											checked,
											onChange: () => toggleLead(Number(lead.id)),
											className: "h-4 w-4 rounded border-input text-[#2f80ed] focus:ring-[#2f80ed]"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-sm font-semibold uppercase text-foreground",
											children: [
												lead.companyName || `Enquiry #${lead.srNo}`,
												" · ",
												lead.enquiryFor
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-sm text-muted-foreground",
											children: [leadDate, lead.contactName ? ` · ${lead.contactName}` : ""]
										})] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-md border border-input bg-background px-2 py-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground",
										children: lead.status
									})]
								}, lead.id);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 flex justify-end gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								onClick: () => setFormOpen(false),
								className: "h-11 px-6",
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								disabled: createMutation.isPending || editMutation.isPending || !draftLeadIds.length,
								className: "h-11 px-6",
								children: editMutation.isPending ? "Saving..." : createMutation.isPending ? "Creating..." : editingCampaign ? `Save Campaign (${draftLeadIds.length} leads)` : `Start Campaign (${draftLeadIds.length} leads)`
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
				open: Boolean(selectedCampaign),
				onClose: () => {
					setSelectedCampaign(null);
					setRecipientFilter("all");
				},
				title: selectedCampaign?.name ?? "Campaign leads",
				eyebrow: "ENROLLED LEADS",
				wide: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-h-[65vh] overflow-auto p-4 sm:p-5",
					children: [selectedLeadsQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-8 text-center text-sm text-muted-foreground",
						children: "Loading enrolled leads…"
					}) : selectedLeadsQuery.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-8 text-center text-sm text-destructive",
						children: selectedLeadsQuery.error.message
					}) : !selectedLeadsQuery.data?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, { title: "No leads assigned" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-sm text-muted-foreground",
							children: [visibleCampaignLeads.length, " recipients"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							"aria-label": "Filter campaign recipients by subscription status",
							value: recipientFilter,
							onChange: (event) => setRecipientFilter(event.target.value),
							className: "h-9 rounded-md border border-input bg-background px-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "all",
									children: "All subscription statuses"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "subscribed",
									children: "Subscribed"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "unsubscribed",
									children: "Unsubscribed"
								})
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto rounded-md border border-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Lead" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Email" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Step" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Status" })
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: visibleCampaignLeads.map((campaignLead) => {
							const lead = leadById.get(campaignLead.leadId);
							const status = campaignLead.completed ? "completed" : campaignLead.replied ? "replied" : campaignLead.unsubscribed ? "unsubscribed" : "active";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "font-medium",
									children: lead ? `Enquiry #${lead.srNo} · ${lead.enquiryFor}` : "Unknown enquiry"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "font-mono text-xs text-muted-foreground",
									children: campaignLead.email || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "font-mono text-xs",
									children: campaignLead.currentStep
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col items-start gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-muted-foreground",
										children: campaignLead.unsubscribed ? "Unsubscribed" : "Subscribed"
									})]
								}) })
							] }, campaignLead.leadId);
						}) })] })
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 border-t border-line pt-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-[10px] tracking-wide text-muted-foreground",
								children: "EMAIL ACTIVITY"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-base font-semibold",
								children: "Campaign logs"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-[11px] text-muted-foreground",
								children: [selectedCampaignLogs.length, " total"]
							})]
						}), emailLogsQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "py-6 text-center text-sm text-muted-foreground",
							children: "Loading email activity…"
						}) : emailLogsQuery.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "py-6 text-center text-sm text-destructive",
							children: emailLogsQuery.error.message
						}) : !selectedCampaignLogs.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rounded-md border border-dashed border-line px-4 py-6 text-center text-sm text-muted-foreground",
							children: "No email activity yet."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-x-auto rounded-md border border-line",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Enquiry" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Subject" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Step" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Status" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Sent At" })
							] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: selectedCampaignLogs.map((log) => {
								const lead = leadById.get(log.leadId);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-medium",
										children: lead ? `Enquiry #${lead.srNo}` : "Unknown enquiry"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-mono text-[11px] text-muted-foreground",
										children: lead?.enquiryFor ?? log.leadId
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										className: "max-w-[220px] truncate text-muted-foreground",
										children: log.subject
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
										className: "font-mono text-xs",
										children: ["#", log.step]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: log.status }) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										className: "whitespace-nowrap font-mono text-[11px] text-muted-foreground",
										children: new Date(log.sentAt).toLocaleString()
									})
								] }, log.id);
							}) })] })
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: Boolean(toDelete),
				onClose: () => setToDelete(null),
				onConfirm: () => toDelete && deleteMutation.mutate(toDelete.id),
				title: "Delete campaign",
				message: `Delete “${toDelete?.name ?? "this campaign"}” and its lead assignments?`,
				loading: deleteMutation.isPending
			})
		]
	});
}
//#endregion
export { CampaignsPage as component };
