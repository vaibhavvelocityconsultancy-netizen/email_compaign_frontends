import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { N as updateOpportunity, a as createOpportunity, b as getOpportunities, n as convertOpportunityToQuotation, u as deleteOpportunity } from "./api-CrPtMj0Q.mjs";
import { N as FileText, _ as Plus, at as ArrowUp, lt as ArrowDown, s as Trash2, y as Pencil } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, t as Dialog } from "./dialog-BA-nrckz.mjs";
import { n as DataTable } from "./DataTable-DmCzJ7wu.mjs";
import { i as listCompanies } from "./company-api-DT3AmoBr.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as ConfirmDialog } from "./ConfirmDialog-Rjd0NwWp.mjs";
import { a as enumType, c as objectType, l as stringType, n as arrayType, s as numberType } from "../_libs/zod.mjs";
import { t as StatusBadge } from "./StatusBadge-BMe1mW6r.mjs";
import { i as useFieldArray, o as useFormContext } from "../_libs/@hookform/resolvers+[...].mjs";
import { s as fieldPresets, t as EntityForm } from "./EntityForm-CgVD88J8.mjs";
import { a as DrawerTitle, i as DrawerHeader, n as DrawerContent, r as DrawerDescription, t as Drawer$1 } from "./drawer-DTNx6Hns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/opportunities-DAWqxpIH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var OPPORTUNITY_STATUSES = [
	["PROSPECTING", "Prospecting"],
	["QUALIFICATION", "Qualification"],
	["NEEDS_ANALYSIS", "Needs analysis"],
	["VALUE_PROPOSITION", "Value proposition"],
	["IDENTIFY_DECISION_MAKERS", "Identify decision makers"],
	["PERCEPTION_ANALYSIS", "Perception analysis"],
	["PROPOSAL_PRICE_QUOTE", "Proposal / price quote"],
	["NEGOTIATION_REVIEW", "Negotiation / review"],
	["CLOSED_WON", "Closed won"],
	["CLOSED_LOST", "Closed lost"]
];
var opportunitySchema = objectType({
	company_name: stringType().trim().min(1, "Company name is required"),
	enquiry_for: stringType().min(1, "Enquiry type is required"),
	status: stringType().min(1),
	enquiry_date: stringType().regex(/^\d{2}-\d{2}-\d{4}$/, "Use MM-DD-YYYY"),
	modules: arrayType(objectType({
		module_number: numberType().int().positive(),
		module_name: stringType().trim().min(1, "Module name is required"),
		description: stringType(),
		requirements: stringType(),
		estimated_cost: numberType().min(0),
		estimated_days: numberType().int().min(0),
		priority: enumType([
			"LOW",
			"MEDIUM",
			"HIGH"
		]),
		remarks: stringType()
	}))
});
function toDisplayDate(value) {
	if (!value) return "";
	const match = value.match(/^(\d{4})-(\d{2})-(\d{2})$/);
	return match ? `${match[2]}-${match[3]}-${match[1]}` : value;
}
function toApiDate(value) {
	if (!value) return null;
	const match = value.match(/^(\d{2})-(\d{2})-(\d{4})$/);
	return match ? `${match[3]}-${match[1]}-${match[2]}` : value;
}
function OpportunityModulesEditor({ disabled }) {
	const { control, register, watch, formState: { errors } } = useFormContext();
	const { fields, append, remove, move } = useFieldArray({
		control,
		name: "modules",
		keyName: "fieldKey"
	});
	const [moduleDialogIndex, setModuleDialogIndex] = (0, import_react.useState)(null);
	const modules = watch("modules");
	const addModule = () => append({
		module_number: fields.length + 1,
		module_name: "",
		description: "",
		requirements: "",
		estimated_cost: 0,
		estimated_days: 0,
		priority: "MEDIUM",
		remarks: ""
	});
	const addAndEditModule = () => {
		const nextIndex = fields.length;
		addModule();
		setModuleDialogIndex(nextIndex);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "col-span-full space-y-3 rounded-lg border border-line bg-background/60 p-3 sm:p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-semibold",
					children: "Opportunity modules"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-0.5 text-xs text-muted-foreground",
					children: "Customize the scope for this client requirement."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					size: "sm",
					variant: "outline",
					className: "h-8 gap-1.5",
					disabled,
					onClick: addAndEditModule,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " Add module"]
				})]
			}),
			fields.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-md border border-dashed border-line p-3 text-xs text-muted-foreground",
				children: "No modules added yet."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: fields.map((field, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3 rounded-md border border-line bg-surface p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "min-w-0 flex-1 text-left",
						onClick: () => setModuleDialogIndex(index),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-sm font-medium",
							children: modules[index]?.module_name || `Module ${index + 1}`
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-0.5 block text-xs text-muted-foreground",
							children: [modules[index]?.priority ?? "MEDIUM", " priority"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								size: "icon",
								disabled: disabled || index === 0,
								onClick: () => move(index, index - 1),
								"aria-label": "Move module up",
								title: "Move module up",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								size: "icon",
								disabled: disabled || index === fields.length - 1,
								onClick: () => move(index, index + 1),
								"aria-label": "Move module down",
								title: "Move module down",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								size: "icon",
								disabled,
								onClick: () => setModuleDialogIndex(index),
								"aria-label": `Edit module ${index + 1}`,
								title: "Edit module",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								size: "icon",
								className: "text-destructive",
								disabled,
								onClick: () => {
									remove(index);
									setModuleDialogIndex(null);
								},
								"aria-label": `Remove module ${index + 1}`,
								title: "Remove module",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
							})
						]
					})]
				}, field.fieldKey))
			}),
			moduleDialogIndex !== null && modules[moduleDialogIndex] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer$1, {
				open: true,
				onOpenChange: (open) => !open && setModuleDialogIndex(null),
				direction: "right",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DrawerContent, {
					className: "inset-y-0 right-0 bottom-auto left-auto mt-0 h-full w-full max-w-xl rounded-none border-l",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DrawerHeader, {
						className: "border-b border-line text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DrawerTitle, { children: modules[moduleDialogIndex].module_name || "New module" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DrawerDescription, { children: "Configure this module for the opportunity." })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid flex-1 gap-3 overflow-y-auto p-5 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm sm:col-span-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium",
										children: "Module name"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										disabled,
										placeholder: "Inventory Management",
										...register(`modules.${moduleDialogIndex}.module_name`)
									}),
									errors.modules?.[moduleDialogIndex]?.module_name && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-destructive",
										children: errors.modules[moduleDialogIndex]?.module_name?.message
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Description"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									className: "min-h-24 w-full rounded-md border border-input bg-background px-3 py-2 text-sm",
									disabled,
									...register(`modules.${moduleDialogIndex}.description`)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Requirements"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									className: "min-h-24 w-full rounded-md border border-input bg-background px-3 py-2 text-sm",
									disabled,
									...register(`modules.${moduleDialogIndex}.requirements`)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Estimated cost"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: 0,
									step: "0.01",
									disabled,
									...register(`modules.${moduleDialogIndex}.estimated_cost`, { valueAsNumber: true })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Estimated days"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: 0,
									step: 1,
									disabled,
									...register(`modules.${moduleDialogIndex}.estimated_days`, { valueAsNumber: true })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Priority"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "h-10 w-full rounded-md border border-input bg-background px-3 text-sm",
									disabled,
									...register(`modules.${moduleDialogIndex}.priority`),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "LOW",
											children: "Low"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "MEDIUM",
											children: "Medium"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "HIGH",
											children: "High"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Remarks"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									disabled,
									...register(`modules.${moduleDialogIndex}.remarks`)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex justify-end sm:col-span-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									onClick: () => setModuleDialogIndex(null),
									children: "Done"
								})
							})
						]
					})]
				})
			})
		]
	});
}
function displayStatus(status) {
	return OPPORTUNITY_STATUSES.find(([value]) => value === status)?.[1] ?? status;
}
var formatCurrency = (value) => new Intl.NumberFormat("en-IN", {
	style: "currency",
	currency: "INR",
	maximumFractionDigits: 0
}).format(Number.isFinite(value) ? value : 0);
function OpportunitiesPage() {
	const queryClient = useQueryClient();
	const navigate = useNavigate();
	const [formOpen, setFormOpen] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [deleteTarget, setDeleteTarget] = (0, import_react.useState)(null);
	const [convertTarget, setConvertTarget] = (0, import_react.useState)(null);
	const [convertCompanyId, setConvertCompanyId] = (0, import_react.useState)("");
	const [convertRows, setConvertRows] = (0, import_react.useState)([]);
	const [convertError, setConvertError] = (0, import_react.useState)("");
	const opportunitiesQuery = useQuery({
		queryKey: ["opportunities"],
		queryFn: getOpportunities
	});
	const companiesQuery = useQuery({
		queryKey: ["companies"],
		queryFn: listCompanies
	});
	const opportunities = opportunitiesQuery.data ?? [];
	const companies = companiesQuery.data ?? [];
	const saveMutation = useMutation({
		mutationFn: (values) => {
			const payload = {
				...values,
				status: values.status,
				enquiry_date: toApiDate(values.enquiry_date),
				source: "",
				expected_close_date: null,
				estimated_value: null,
				probability: null,
				modules: values.modules.map((module, index) => ({
					...module,
					module_number: index + 1,
					priority: module.priority,
					estimated_cost: module.estimated_cost || null,
					estimated_days: module.estimated_days || null
				}))
			};
			return editing ? updateOpportunity(editing.id, payload) : createOpportunity(payload);
		},
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: ["opportunities"] });
			setFormOpen(false);
			toast.success(editing ? "Opportunity updated" : "Opportunity created");
		},
		onError: (error) => toast.error(error.message || "Could not save opportunity")
	});
	const deleteMutation = useMutation({
		mutationFn: (opportunity) => deleteOpportunity(opportunity.id),
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: ["opportunities"] });
			setDeleteTarget(null);
			toast.success("Opportunity deleted");
		},
		onError: (error) => toast.error(error.message || "Could not delete opportunity")
	});
	const convertMutation = useMutation({
		mutationFn: ({ opportunityId, companyId, items }) => convertOpportunityToQuotation(opportunityId, companyId, items),
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: ["opportunities"] });
			await queryClient.invalidateQueries({ queryKey: ["quotations"] });
			setConvertTarget(null);
			setConvertRows([]);
			setConvertError("");
			toast.success("Quotation created");
			navigate({ to: "/sales/quotations" });
		},
		onError: (error) => toast.error(error.message || "Could not convert opportunity to quotation")
	});
	const openConvertDialog = (opportunity) => {
		const rows = opportunity.modules.map((module) => ({
			moduleId: Number(module.id ?? 0),
			moduleName: module.moduleName || "Module",
			description: module.description || "",
			estimatedCost: module.estimatedCost ?? 0,
			amount: String(module.estimatedCost ?? 0)
		}));
		setConvertTarget(opportunity);
		setConvertCompanyId(opportunity.companyId == null ? "" : String(opportunity.companyId));
		setConvertRows(rows);
		setConvertError("");
	};
	const subtotal = convertRows.reduce((sum, row) => sum + (Number(row.amount) || 0), 0);
	const submitConversion = () => {
		if (!convertTarget) return;
		if (!convertCompanyId) {
			setConvertError("Select a company before converting.");
			return;
		}
		if (convertRows.length === 0) {
			setConvertError("This opportunity has no modules. Add at least one module before converting.");
			return;
		}
		for (const row of convertRows) if (row.amount.trim() === "" || Number.isNaN(Number(row.amount)) || Number(row.amount) < 0) {
			setConvertError("Every module must have a numeric amount greater than or equal to zero.");
			return;
		}
		const items = convertRows.map((row) => ({
			module: row.moduleId,
			amount: String(Number(row.amount))
		}));
		convertMutation.mutate({
			opportunityId: convertTarget.id,
			companyId: Number(convertCompanyId),
			items
		});
	};
	const columns = (0, import_react.useMemo)(() => [
		{
			key: "companyName",
			header: "Company",
			cell: (opportunity) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium",
				children: opportunity.companyName
			})
		},
		{
			key: "enquiryFor",
			header: "Enquiry for",
			filterValue: (opportunity) => opportunity.enquiryFor,
			cell: (opportunity) => opportunity.enquiryFor || /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground",
				children: "—"
			})
		},
		{
			key: "enquiryDate",
			header: "Enquiry date",
			filterType: "date",
			filterValue: (opportunity) => opportunity.enquiryDate,
			cell: (opportunity) => opportunity.enquiryDate ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-xs text-muted-foreground",
				children: toDisplayDate(opportunity.enquiryDate)
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground",
				children: "—"
			})
		},
		{
			key: "status",
			header: "Stage",
			filterValue: (opportunity) => opportunity.status,
			cell: (opportunity) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: displayStatus(opportunity.status) })
		},
		{
			key: "actions",
			header: "Actions",
			sortable: false,
			filterable: false,
			className: "text-right",
			headerClassName: "text-right",
			cell: (opportunity) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-end gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "grid size-8 place-items-center rounded-md text-muted-foreground hover:bg-background hover:text-foreground",
					"aria-label": `Edit ${opportunity.companyName}`,
					title: "Edit opportunity",
					onClick: () => {
						setEditing(opportunity);
						setFormOpen(true);
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "grid size-8 place-items-center rounded-md text-muted-foreground hover:bg-destructive/10 hover:text-destructive",
					"aria-label": `Delete ${opportunity.companyName}`,
					title: "Delete opportunity",
					onClick: () => setDeleteTarget(opportunity),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
				})]
			})
		}
	], []);
	const fields = (0, import_react.useMemo)(() => [
		fieldPresets.searchableSelect("company_name", "Company name", companies.map((company) => ({
			value: company.name,
			label: company.name
		})), {
			required: true,
			colSpan: 2,
			placeholder: companiesQuery.isLoading ? "Loading companies..." : "Select company"
		}),
		fieldPresets.select("enquiry_for", "Enquiry for", [{
			value: "LEAD",
			label: "Lead"
		}, {
			value: "CLIENT",
			label: "Client"
		}], { required: true }),
		fieldPresets.select("status", "Stage", OPPORTUNITY_STATUSES.map(([value, label]) => ({
			value,
			label
		})), { required: true }),
		fieldPresets.text("enquiry_date", "Enquiry date", {
			required: true,
			placeholder: "MM-DD-YYYY"
		})
	], [companies, companiesQuery.isLoading]);
	const defaultValues = editing ? {
		company_name: editing.companyName,
		enquiry_for: editing.enquiryFor || "LEAD",
		status: editing.status,
		enquiry_date: toDisplayDate(editing.enquiryDate),
		modules: editing.modules.map((module) => ({
			module_number: module.moduleNumber,
			module_name: module.moduleName,
			description: module.description,
			requirements: module.requirements,
			estimated_cost: module.estimatedCost ?? 0,
			estimated_days: module.estimatedDays ?? 0,
			priority: module.priority,
			remarks: module.remarks
		}))
	} : {
		company_name: "",
		enquiry_for: "LEAD",
		status: "PROSPECTING",
		enquiry_date: "",
		modules: []
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rise flex flex-wrap items-end justify-between gap-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-mono text-[11px] tracking-wide text-muted-foreground",
					children: "SALES PIPELINE"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-3xl font-bold tracking-tight",
					children: "Opportunities"
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rise",
				style: { animationDelay: "80ms" },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
					data: opportunities,
					columns,
					searchKeys: [
						"companyName",
						"enquiryFor",
						"status"
					],
					searchPlaceholder: "Search opportunities...",
					storageKey: "opportunities",
					emptyMessage: opportunitiesQuery.isLoading ? "Loading opportunities…" : "No opportunities yet.",
					toolbarActions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "outline",
							className: "h-9 gap-1.5",
							onClick: () => navigate({
								to: "/tasks/form",
								search: {
									taskId: void 0,
									module: "OPPORTUNITY",
									companyId: void 0,
									referenceId: void 0
								}
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " New Task"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex h-9 items-center gap-1.5 rounded-lg bg-brand px-4 text-sm font-medium text-white hover:bg-brand/90",
							onClick: () => {
								setEditing(null);
								setFormOpen(true);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " New opportunity"]
						})]
					})
				}), opportunitiesQuery.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-destructive",
					children: opportunitiesQuery.error.message
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityForm, {
				open: formOpen,
				onOpenChange: setFormOpen,
				title: editing ? "Edit opportunity" : "Create opportunity",
				fields,
				schema: opportunitySchema,
				defaultValues,
				isEdit: Boolean(editing),
				isLoading: saveMutation.isPending,
				submitLabel: "Save opportunity",
				size: "lg",
				footerActions: editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					size: "sm",
					variant: "outline",
					className: "h-8 gap-1.5",
					onClick: () => openConvertDialog(editing),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-4" }), "Convert to quotation"]
				}) : void 0,
				onSubmit: async (values) => {
					await saveMutation.mutateAsync(values);
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OpportunityModulesEditor, { disabled: saveMutation.isPending })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: Boolean(convertTarget),
				onOpenChange: (open) => {
					if (!open && !convertMutation.isPending) {
						setConvertTarget(null);
						setConvertRows([]);
						setConvertError("");
					}
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-h-[90dvh] w-[calc(100vw-2rem)] max-w-3xl gap-0 overflow-y-auto p-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, {
						className: "border-b border-line px-5 py-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Convert to Quotation" })
					}), convertTarget && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-5 p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-3 sm:grid-cols-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs uppercase tracking-wide text-muted-foreground",
										children: "Project Name"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 font-medium",
										children: convertTarget.projectName || convertTarget.companyName || "—"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "space-y-1.5 text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs uppercase tracking-wide text-muted-foreground",
											children: "Company"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											className: "h-10 w-full rounded-md border border-input bg-background px-3 text-sm",
											value: convertCompanyId,
											onChange: (event) => setConvertCompanyId(event.target.value),
											disabled: convertMutation.isPending || companiesQuery.isLoading,
											required: true,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "",
												children: "Select company"
											}), companies.map((company) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: company.id,
												children: company.name
											}, company.id))]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs uppercase tracking-wide text-muted-foreground",
										children: "Enquiry For"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 font-medium",
										children: convertTarget.enquiryFor || "—"
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-x-auto rounded-lg border border-line",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "w-full min-w-[560px] text-left text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
										className: "bg-background text-muted-foreground",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-2 font-medium",
												children: "Module Name"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-2 font-medium",
												children: "Description"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-2 text-right font-medium",
												children: "Estimated Cost"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-2 text-right font-medium",
												children: "Quotation Amount"
											})
										] })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: convertRows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-t border-line align-top",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-3 font-medium",
												children: row.moduleName
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-3 text-muted-foreground",
												children: row.description || "—"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-3 text-right font-mono text-xs",
												children: formatCurrency(row.estimatedCost)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-3 text-right",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "relative ml-auto w-40",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "pointer-events-none absolute inset-y-0 left-3 flex items-center text-sm text-muted-foreground",
														children: "₹"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														type: "number",
														min: 0,
														step: "0.01",
														value: row.amount,
														className: "pl-8 text-right",
														disabled: convertMutation.isPending,
														onChange: (event) => {
															const nextValue = event.target.value;
															setConvertRows((currentRows) => currentRows.map((currentRow) => currentRow.moduleId === row.moduleId ? {
																...currentRow,
																amount: nextValue
															} : currentRow));
														}
													})]
												})
											})
										]
									}, row.moduleId)) })]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between rounded-md border border-line bg-background px-3 py-2 text-sm font-medium",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Subtotal" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono",
									children: formatCurrency(subtotal)
								})]
							}),
							convertError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "rounded-md border border-destructive/30 bg-destructive/5 px-3 py-2 text-sm text-destructive",
								children: convertError
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-end gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "outline",
									disabled: convertMutation.isPending,
									onClick: () => {
										setConvertTarget(null);
										setConvertRows([]);
										setConvertError("");
									},
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									onClick: submitConversion,
									disabled: convertMutation.isPending,
									children: convertMutation.isPending ? "Converting..." : "Convert to Quotation"
								})]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: Boolean(deleteTarget),
				onClose: () => setDeleteTarget(null),
				onConfirm: () => deleteTarget && deleteMutation.mutate(deleteTarget),
				title: "Delete opportunity",
				message: `Delete “${deleteTarget?.companyName ?? "this opportunity"}”?`,
				loading: deleteMutation.isPending
			})
		]
	});
}
//#endregion
export { OpportunitiesPage as component };
