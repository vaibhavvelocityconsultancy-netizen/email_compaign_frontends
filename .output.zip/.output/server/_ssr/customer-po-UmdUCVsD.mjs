import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { L as ExternalLink, N as FileText, i as Upload, u as ShoppingCart } from "../_libs/lucide-react.mjs";
import { n as DataTable } from "./DataTable-DmCzJ7wu.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Modal } from "./Modal-vFtVKTX9.mjs";
import { i as createSalesOrder, m as updateQuotationCpo, n as attachCpoDocument, s as getCpos } from "./quotation-api-BzDmjcXh.mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/customer-po-UmdUCVsD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var money = (value) => new Intl.NumberFormat("en-IN", {
	style: "currency",
	currency: "INR",
	maximumFractionDigits: 2
}).format(value || 0);
function displayDate(value) {
	if (!value) return "—";
	const match = value.match(/^(\d{2})-(\d{2})-(\d{4})$/);
	if (match) return `${match[2]}/${match[1]}/${match[3]}`;
	const date = /* @__PURE__ */ new Date(`${value.slice(0, 10)}T00:00:00`);
	return Number.isNaN(date.getTime()) ? value : new Intl.DateTimeFormat("en-GB").format(date);
}
function inputDate(value) {
	if (!value) return "";
	if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return value;
	const match = value.match(/^(\d{2})-(\d{2})-(\d{4})$/);
	return match ? `${match[3]}-${match[2]}-${match[1]}` : "";
}
function CustomerPurchaseOrdersPage() {
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const cposQuery = useQuery({
		queryKey: ["cpos"],
		queryFn: getCpos
	});
	const [selectedQuotation, setSelectedQuotation] = (0, import_react.useState)(null);
	const [cpoDate, setCpoDate] = (0, import_react.useState)("");
	const cpoFileInput = (0, import_react.useRef)(null);
	const updateDateMutation = useMutation({
		mutationFn: () => {
			if (!selectedQuotation) throw new Error("Choose a quotation first.");
			return updateQuotationCpo(selectedQuotation.id, { cpo_date: cpoDate || null });
		},
		onSuccess: async (quotation) => {
			setSelectedQuotation(quotation);
			setCpoDate(inputDate(quotation.cpoDate));
			await Promise.all([queryClient.invalidateQueries({ queryKey: ["cpos"] }), queryClient.invalidateQueries({ queryKey: ["quotations"] })]);
			toast.success("CPO date updated");
		},
		onError: (error) => toast.error(error.message || "Could not update CPO date")
	});
	const attachCpoMutation = useMutation({
		mutationFn: (document) => {
			if (!selectedQuotation) throw new Error("Choose a quotation first.");
			return attachCpoDocument(selectedQuotation.id, document);
		},
		onSuccess: async (quotation) => {
			setSelectedQuotation(quotation);
			await Promise.all([queryClient.invalidateQueries({ queryKey: ["cpos"] }), queryClient.invalidateQueries({ queryKey: ["quotations"] })]);
			toast.success("CPO document attached");
		},
		onError: (error) => toast.error(error.message || "Could not attach CPO document")
	});
	const createSalesOrderMutation = useMutation({
		mutationFn: () => {
			if (!selectedQuotation) throw new Error("Choose a quotation first.");
			return createSalesOrder(selectedQuotation.id);
		},
		onSuccess: async (salesOrder) => {
			await Promise.all([
				queryClient.invalidateQueries({ queryKey: ["quotations"] }),
				queryClient.invalidateQueries({ queryKey: ["cpos"] }),
				queryClient.invalidateQueries({ queryKey: ["sales-orders"] })
			]);
			setSelectedQuotation(null);
			toast.success(`Sales order ${salesOrder.soNumber} created`);
			await navigate({
				to: "/sales/orders",
				search: { soId: salesOrder.id }
			});
		},
		onError: (error) => toast.error(error.message || "Could not create sales order")
	});
	const openDetails = (quotation) => {
		setSelectedQuotation(quotation);
		setCpoDate(inputDate(quotation.cpoDate));
	};
	const columns = (0, import_react.useMemo)(() => [
		{
			key: "companyName",
			header: "Customer / Company",
			cell: (quotation) => quotation.companyName || "—",
			filterValue: (quotation) => quotation.companyName
		},
		{
			key: "quotationNumber",
			header: "Quotation",
			cell: (quotation) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-xs",
				children: quotation.quotationNumber
			})
		},
		{
			key: "quotationDate",
			header: "Quotation date",
			filterType: "date",
			cell: (quotation) => displayDate(quotation.quotationDate),
			filterValue: (quotation) => quotation.quotationDate
		},
		{
			key: "totalAmount",
			header: "Quotation total",
			cell: (quotation) => money(quotation.totalAmount),
			filterable: false
		},
		{
			key: "cpoDate",
			header: "CPO date",
			cell: (quotation) => displayDate(quotation.cpoDate),
			filterType: "date",
			filterValue: (quotation) => quotation.cpoDate
		},
		{
			key: "actions",
			header: "Details",
			sortable: false,
			filterable: false,
			cell: (quotation) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				size: "sm",
				variant: "outline",
				onClick: () => openDetails(quotation),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "mr-1 size-3.5" }), "Update CPO date"]
			})
		}
	], []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-mono text-[11px] tracking-wide text-muted-foreground",
					children: "ORDER FLOW"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-3xl font-bold tracking-tight",
					children: "Customer Purchase Orders"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Quotations marked for CPO processing appear here. Only the CPO date can be updated here."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [cposQuery.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mb-3 text-sm text-destructive",
				children: cposQuery.error.message || "Could not load customer purchase orders."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				data: cposQuery.data ?? [],
				columns,
				searchKeys: ["quotationNumber", "companyName"],
				searchPlaceholder: "Search quotations or companies",
				storageKey: "customer-purchase-orders",
				emptyMessage: cposQuery.isLoading ? "Loading CPO quotations…" : "No quotations have been marked for CPO processing."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
				open: Boolean(selectedQuotation),
				onClose: () => !updateDateMutation.isPending && !attachCpoMutation.isPending && !createSalesOrderMutation.isPending && setSelectedQuotation(null),
				title: selectedQuotation ? `CPO details · ${selectedQuotation.quotationNumber}` : "CPO details",
				eyebrow: "CUSTOMER PURCHASE ORDER",
				wide: true,
				children: selectedQuotation && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "max-h-[75vh] space-y-5 overflow-y-auto p-5",
					onSubmit: (event) => {
						event.preventDefault();
						updateDateMutation.mutate();
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "grid gap-4 rounded-md border border-line bg-muted/20 p-4 md:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-semibold uppercase",
									children: selectedQuotation.companyName || "Company"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 whitespace-pre-line text-sm text-muted-foreground",
									children: selectedQuotation.companyAddress || "No address on file"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted-foreground",
									children: [
										selectedQuotation.city,
										selectedQuotation.state,
										selectedQuotation.companyPincode
									].filter(Boolean).join(", ") || "Location not set"
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm font-semibold",
								children: "Contacts"
							}), selectedQuotation.companyContacts.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-2 space-y-2",
								children: selectedQuotation.companyContacts.map((contact, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "text-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-medium",
											children: [
												index + 1,
												". ",
												contact.name,
												contact.isPrimary ? " · Primary" : ""
											]
										}),
										contact.designation && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-muted-foreground",
											children: [" · ", contact.designation]
										}),
										(contact.phone || contact.email) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-muted-foreground",
											children: [contact.phone, contact.email].filter(Boolean).join(" · ")
										})
									]
								}, `${contact.name}-${contact.phone}-${index}`))
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: "No contacts on file."
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "grid gap-x-6 gap-y-3 rounded-md bg-muted/20 p-4 text-sm sm:grid-cols-2 lg:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted-foreground",
									children: "Project"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-0.5 font-medium",
									children: selectedQuotation.projectName || "—"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted-foreground",
									children: "Quotation date"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-0.5 font-medium",
									children: displayDate(selectedQuotation.quotationDate)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted-foreground",
									children: "CPO date"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										value: cpoDate,
										onChange: (event) => setCpoDate(event.target.value)
									})
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted-foreground",
									children: "Quotation status"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-0.5 font-medium",
									children: selectedQuotation.statusDisplay
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted-foreground",
									children: "Delivery timeline"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-0.5 font-medium",
									children: selectedQuotation.deliveryTimeline || "—"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted-foreground",
									children: "Quotation total"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-0.5 font-semibold",
									children: money(selectedQuotation.totalAmount)
								})] })
							]
						}),
						(selectedQuotation.quotationPdf || selectedQuotation.finalOfferPdf) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-4 text-sm",
							children: [selectedQuotation.quotationPdf && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: selectedQuotation.quotationPdf,
								target: "_blank",
								rel: "noreferrer",
								className: "inline-flex items-center gap-1 text-primary underline-offset-4 hover:underline",
								children: ["Quotation PDF ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3.5" })]
							}), selectedQuotation.finalOfferPdf && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: selectedQuotation.finalOfferPdf,
								target: "_blank",
								rel: "noreferrer",
								className: "inline-flex items-center gap-1 text-primary underline-offset-4 hover:underline",
								children: ["Final offer PDF ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3.5" })]
							})]
						}),
						selectedQuotation.cpoDocument && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: selectedQuotation.cpoDocument,
							target: "_blank",
							rel: "noreferrer",
							className: "inline-flex items-center gap-1 text-sm text-primary underline-offset-4 hover:underline",
							children: ["View attached CPO ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3.5" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "overflow-hidden rounded-md border border-line",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "px-4 py-3 text-sm font-semibold",
									children: "Quotation items"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "overflow-x-auto",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
										className: "w-full min-w-[1000px] border-collapse text-left text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
											className: "border-y border-line bg-muted/30 text-xs text-muted-foreground",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-3 py-2",
													children: "#"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-3 py-2",
													children: "Type / Module"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-3 py-2",
													children: "Description"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-3 py-2",
													children: "Requirements"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-3 py-2",
													children: "Est. days"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-3 py-2",
													children: "Priority"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-3 py-2 text-right",
													children: "Est. cost"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-3 py-2 text-right",
													children: "Amount"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-3 py-2",
													children: "Remarks"
												})
											] })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
											className: "divide-y divide-line",
											children: [selectedQuotation.items.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-3 py-3",
													children: index + 1
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-3 py-3 font-medium",
													children: item.moduleName || "—"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "max-w-48 whitespace-pre-wrap px-3 py-3",
													children: item.description || "—"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "max-w-56 whitespace-pre-wrap px-3 py-3",
													children: item.requirements || "—"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-3 py-3",
													children: item.estimatedDays ?? "—"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-3 py-3",
													children: item.priority
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-3 py-3 text-right",
													children: item.estimatedCost == null ? "—" : money(item.estimatedCost)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-3 py-3 text-right font-medium",
													children: money(item.amount)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "max-w-48 whitespace-pre-wrap px-3 py-3",
													children: item.remarks || "—"
												})
											] }, item.id ?? `${item.moduleName}-${index}`)), !selectedQuotation.items.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												colSpan: 9,
												className: "px-3 py-8 text-center text-muted-foreground",
												children: "No quotation items."
											}) })]
										})]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
									className: "grid gap-x-6 gap-y-2 border-t border-line bg-muted/20 p-4 text-sm sm:grid-cols-2 lg:grid-cols-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
												className: "text-muted-foreground",
												children: "Subtotal"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: money(selectedQuotation.subtotal) })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
												className: "text-muted-foreground",
												children: "Discount"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: money(selectedQuotation.discount) })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
												className: "text-muted-foreground",
												children: selectedQuotation.taxTypeDisplay || "Tax"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: money(selectedQuotation.taxAmount) })]
										}),
										selectedQuotation.cgstAmount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
												className: "text-muted-foreground",
												children: "CGST"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: money(selectedQuotation.cgstAmount) })]
										}),
										selectedQuotation.sgstAmount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
												className: "text-muted-foreground",
												children: "SGST"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: money(selectedQuotation.sgstAmount) })]
										}),
										selectedQuotation.igstAmount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
												className: "text-muted-foreground",
												children: "IGST"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: money(selectedQuotation.igstAmount) })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
												className: "text-muted-foreground",
												children: "Taxable amount"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: money(selectedQuotation.taxableAmount) })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
												className: "text-muted-foreground",
												children: "Packing charges"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: money(selectedQuotation.packingCharges) })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between gap-3 font-semibold",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: money(selectedQuotation.totalAmount) })]
										})
									]
								})
							]
						}),
						selectedQuotation.termsConditions && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-md border border-line p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-semibold",
								children: "Terms and conditions"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 whitespace-pre-wrap text-sm text-muted-foreground",
								children: selectedQuotation.termsConditions
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: cpoFileInput,
							type: "file",
							accept: ".pdf,application/pdf",
							className: "hidden",
							onChange: (event) => {
								const file = event.currentTarget.files?.[0];
								if (file) attachCpoMutation.mutate(file);
								event.currentTarget.value = "";
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap justify-end gap-2 border-t border-line pt-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									disabled: createSalesOrderMutation.isPending,
									onClick: () => createSalesOrderMutation.mutate(),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingCart, { className: "mr-2 size-4" }), createSalesOrderMutation.isPending ? "Creating SO…" : "Create SO"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									variant: "outline",
									disabled: attachCpoMutation.isPending,
									onClick: () => cpoFileInput.current?.click(),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "mr-2 size-4" }), attachCpoMutation.isPending ? "Attaching…" : selectedQuotation.cpoDocument ? "Replace CPO" : "Attach CPO"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									disabled: updateDateMutation.isPending,
									children: updateDateMutation.isPending ? "Updating…" : "Update CPO date"
								})
							]
						})
					]
				})
			})
		]
	});
}
//#endregion
export { CustomerPurchaseOrdersPage as component };
