import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { F as updateTemplate, S as getTemplates, f as deleteTemplate, s as createTemplate } from "./api-CrPtMj0Q.mjs";
import { _ as Plus } from "../_libs/lucide-react.mjs";
import { n as DataTable } from "./DataTable-DmCzJ7wu.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Modal } from "./Modal-vFtVKTX9.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as ConfirmDialog } from "./ConfirmDialog-Rjd0NwWp.mjs";
import { a as enumType, c as objectType, l as stringType, t as anyType } from "../_libs/zod.mjs";
import { s as fieldPresets, t as EntityForm } from "./EntityForm-CgVD88J8.mjs";
import { i as TabsTrigger, r as TabsList, t as Tabs } from "./tabs-CA_Ke5Cp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/email-campaign.templates-DWYco2vr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CHANNEL_OPTIONS = [{
	value: "email",
	label: "Email"
}, {
	value: "whatsapp",
	label: "WhatsApp"
}];
var templateSchema = objectType({
	channel: enumType(["email", "whatsapp"]),
	name: stringType().trim().min(1, "Name is required"),
	subject: stringType().optional(),
	body: stringType().trim().min(1, "Body is required"),
	signature: stringType().optional(),
	logo: anyType().optional(),
	attachment: anyType().optional(),
	waTemplateName: stringType().optional(),
	waLanguage: stringType().optional()
}).superRefine((v, ctx) => {
	if (v.channel === "email" && !v.subject?.trim()) ctx.addIssue({
		code: "custom",
		path: ["subject"],
		message: "Subject is required"
	});
	if (v.channel === "whatsapp" && !v.waTemplateName?.trim()) ctx.addIssue({
		code: "custom",
		path: ["waTemplateName"],
		message: "Meta template name is required"
	});
});
var pickNewFile = (value) => Array.isArray(value) ? value.find((v) => v instanceof File) : void 0;
var waStatusClass = (s) => s === "approved" ? "text-emerald-600" : s === "rejected" ? "text-bad" : "text-muted-foreground";
var hideForWhatsApp = (form) => form.watch("channel") === "whatsapp";
var hideForEmail = (form) => form.watch("channel") !== "whatsapp";
function TemplatesPage() {
	const qc = useQueryClient();
	const { data, isLoading } = useQuery({
		queryKey: ["templates"],
		queryFn: getTemplates
	});
	const [tab, setTab] = (0, import_react.useState)("email");
	const [formOpen, setFormOpen] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [preview, setPreview] = (0, import_react.useState)(null);
	const [toDelete, setToDelete] = (0, import_react.useState)(null);
	const all = data ?? [];
	const filtered = (0, import_react.useMemo)(() => all.filter((t) => (t.channel ?? "email") === tab), [all, tab]);
	const counts = (0, import_react.useMemo)(() => ({
		email: all.filter((t) => (t.channel ?? "email") === "email").length,
		whatsapp: all.filter((t) => t.channel === "whatsapp").length
	}), [all]);
	const openCreate = () => {
		setEditing(null);
		setFormOpen(true);
	};
	const openEdit = (0, import_react.useCallback)((t) => {
		setEditing(t);
		setFormOpen(true);
	}, []);
	const save = useMutation({
		mutationFn: async (values) => {
			const isEmail = values.channel === "email";
			const logo = isEmail ? pickNewFile(values.logo) : void 0;
			const attachment = pickNewFile(values.attachment);
			const payload = {
				channel: values.channel,
				name: values.name,
				body: values.body,
				subject: isEmail ? values.subject ?? "" : "",
				signature: isEmail ? values.signature ?? "" : "",
				waTemplateName: isEmail ? "" : values.waTemplateName ?? "",
				waLanguage: isEmail ? "" : values.waLanguage || "en",
				...logo ? { logo } : {},
				...attachment ? { attachment } : {}
			};
			return editing ? updateTemplate(editing.id, payload) : createTemplate(payload);
		},
		onSuccess: (_res, values) => {
			qc.invalidateQueries({ queryKey: ["templates"] });
			setFormOpen(false);
			setTab(values.channel);
			toast.success(editing ? "Template updated" : "Template created");
		},
		onError: (e) => toast.error(e.message || "Could not save template")
	});
	const remove = useMutation({
		mutationFn: (id) => deleteTemplate(id),
		onSuccess: () => {
			qc.invalidateQueries({ queryKey: ["templates"] });
			setToDelete(null);
			toast.success("Template deleted");
		},
		onError: (e) => toast.error(e.message || "Could not delete template")
	});
	const columns = (0, import_react.useMemo)(() => {
		const nameCol = {
			key: "name",
			header: "Name",
			cell: (t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium",
				children: t.name
			})
		};
		const createdCol = {
			key: "createdAt",
			header: "Created",
			filterType: "date",
			filterValue: (t) => t.createdAt,
			cell: (t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-[11px] text-muted-foreground",
				children: new Date(t.createdAt).toLocaleDateString()
			})
		};
		const actionsCol = {
			key: "actions",
			header: "Actions",
			className: "text-right",
			headerClassName: "text-right",
			cell: (t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-end gap-3 text-xs font-medium",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setPreview(t),
						className: "text-muted-foreground hover:underline",
						children: "Preview"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => openEdit(t),
						className: "text-brand hover:underline",
						children: "Edit"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setToDelete(t),
						className: "text-bad hover:underline",
						children: "Delete"
					})
				]
			})
		};
		if (tab === "email") return [
			nameCol,
			{
				key: "subject",
				header: "Subject",
				cell: (t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted-foreground",
					children: t.subject
				})
			},
			createdCol,
			actionsCol
		];
		return [
			nameCol,
			{
				key: "waTemplateName",
				header: "Meta Template",
				cell: (t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-xs text-muted-foreground",
					children: t.waTemplateName
				})
			},
			{
				key: "waLanguage",
				header: "Language",
				cell: (t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted-foreground",
					children: t.waLanguage
				})
			},
			{
				key: "waStatus",
				header: "Status",
				cell: (t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `text-xs font-medium capitalize ${waStatusClass(t.waStatus)}`,
					children: t.waStatus || "pending"
				})
			},
			createdCol,
			actionsCol
		];
	}, [tab, openEdit]);
	const fields = (0, import_react.useMemo)(() => [
		fieldPresets.select("channel", "Channel", CHANNEL_OPTIONS, {
			required: true,
			colSpan: 2,
			defaultValue: tab,
			disabled: !!editing,
			description: editing ? "Channel can't be changed after creation." : void 0
		}),
		fieldPresets.text("name", "Name", {
			required: true,
			placeholder: "Follow Up Day 0",
			colSpan: 2
		}),
		{
			...fieldPresets.text("subject", "Subject", {
				required: true,
				placeholder: "Thank you for your interest",
				colSpan: 2
			}),
			hidden: hideForWhatsApp
		},
		{
			...fieldPresets.text("waTemplateName", "Meta Template Name", {
				required: true,
				placeholder: "follow_up_day_0"
			}),
			hidden: hideForEmail
		},
		{
			...fieldPresets.text("waLanguage", "Language Code", { placeholder: "en" }),
			hidden: hideForEmail
		},
		fieldPresets.textarea("body", "Body", {
			required: true,
			rows: 7,
			placeholder: "Hi {{name}}, …"
		}),
		{
			...fieldPresets.textarea("signature", "Signature", {
				rows: 3,
				placeholder: "Best regards,\nThe Sales Team"
			}),
			hidden: hideForWhatsApp
		},
		{
			...fieldPresets.file("logo", "Logo", { description: editing?.logoName ? `Current: ${editing.logoName}` : void 0 }),
			hidden: hideForWhatsApp
		},
		fieldPresets.file("attachment", "Attachment", { description: editing?.attachmentName ? `Current: ${editing.attachmentName}` : void 0 })
	], [editing, tab]);
	const defaultValues = (0, import_react.useMemo)(() => editing ? {
		channel: editing.channel ?? "email",
		name: editing.name,
		subject: editing.subject,
		body: editing.body,
		signature: editing.signature,
		waTemplateName: editing.waTemplateName,
		waLanguage: editing.waLanguage || "en"
	} : {
		channel: tab,
		waLanguage: "en"
	}, [editing, tab]);
	const tabLabel = tab === "email" ? "email" : "WhatsApp";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rise flex flex-wrap items-end justify-between gap-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-mono text-[11px] tracking-wide text-muted-foreground",
					children: "CONTENT"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-3xl font-bold tracking-tight",
					children: "Message Templates"
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
				value: tab,
				onValueChange: (v) => setTab(v),
				className: "rise",
				style: { animationDelay: "40ms" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
					value: "email",
					children: [
						"Email (",
						counts.email,
						")"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
					value: "whatsapp",
					children: [
						"WhatsApp (",
						counts.whatsapp,
						")"
					]
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rise",
				style: { animationDelay: "80ms" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
					data: filtered,
					columns,
					searchKeys: tab === "email" ? ["name", "subject"] : ["name", "waTemplateName"],
					searchPlaceholder: "Search templates...",
					storageKey: `templates-${tab}`,
					emptyMessage: isLoading ? "Loading templates…" : `No ${tabLabel} templates yet. Create your first one to build a sequence.`,
					toolbarActions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						className: "h-9 gap-1.5",
						onClick: openCreate,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " Create Template"]
					})
				}, tab)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityForm, {
				open: formOpen,
				onOpenChange: setFormOpen,
				title: editing ? "Edit Template" : "Create Template",
				fields,
				schema: templateSchema,
				defaultValues,
				isEdit: !!editing,
				isLoading: save.isPending,
				submitLabel: "Save Template",
				size: "lg",
				onSubmit: (values) => save.mutate(values)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
				open: !!preview,
				onClose: () => setPreview(null),
				title: "Template preview",
				eyebrow: preview?.channel === "whatsapp" ? "AS ON WHATSAPP" : "AS RECIPIENT SEES IT",
				wide: true,
				children: preview && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "p-5",
					children: preview.channel === "whatsapp" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-line bg-background p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "ml-auto max-w-sm rounded-lg rounded-tr-none bg-emerald-100 p-3 text-sm whitespace-pre-wrap text-emerald-950 shadow-sm dark:bg-emerald-900 dark:text-emerald-50",
							children: preview.body
						}), preview.waTemplateName && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 text-right font-mono text-[11px] text-muted-foreground",
							children: [
								preview.waTemplateName,
								" · ",
								preview.waLanguage
							]
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-line bg-background p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-display text-base font-semibold",
								children: preview.subject
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "my-4 h-px bg-line" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm whitespace-pre-wrap",
								children: preview.body
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-6 text-sm whitespace-pre-wrap text-muted-foreground",
								children: preview.signature
							})
						]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!toDelete,
				onClose: () => setToDelete(null),
				onConfirm: () => toDelete && remove.mutate(toDelete.id),
				title: "Delete template",
				message: `"${toDelete?.name}" will be removed permanently. Sequences using it will need a new template.`,
				loading: remove.isPending
			})
		]
	});
}
//#endregion
export { TemplatesPage as component };
