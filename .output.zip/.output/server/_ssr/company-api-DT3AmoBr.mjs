import { k as request } from "./api-CrPtMj0Q.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/company-api-DT3AmoBr.js
async function listCompanies() {
	return (await request("/companies/")).results;
}
function createCompany(data) {
	return request("/companies/", {
		method: "POST",
		body: JSON.stringify(data)
	});
}
function updateCompany(id, data) {
	return request(`/companies/${id}/`, {
		method: "PATCH",
		body: JSON.stringify(data)
	});
}
function listCountries() {
	return request("/countries/").then((response) => Array.isArray(response) ? response : response.results);
}
function listStates() {
	return request("/states/").then((response) => Array.isArray(response) ? response : response.results);
}
function listCities() {
	return request("/cities/").then((response) => Array.isArray(response) ? response : response.results);
}
function listCompanyContacts(companyId) {
	return request(`/companies/${companyId}/contacts/`);
}
function createCompanyContact(companyId, data) {
	return request(`/companies/${companyId}/contacts/`, {
		method: "POST",
		body: JSON.stringify(data)
	});
}
function updateCompanyContact(companyId, contactId, data) {
	return request(`/companies/${companyId}/contacts/${contactId}/`, {
		method: "PATCH",
		body: JSON.stringify(data)
	});
}
//#endregion
export { listCompanyContacts as a, updateCompany as c, listCompanies as i, updateCompanyContact as l, createCompanyContact as n, listCountries as o, listCities as r, listStates as s, createCompany as t };
