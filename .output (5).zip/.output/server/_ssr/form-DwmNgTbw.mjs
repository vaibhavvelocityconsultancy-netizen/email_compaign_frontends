import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { I as Eye, N as History, h as Save, lt as ArrowLeft } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Modal } from "./Modal-vFtVKTX9.mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useSaveTask, l as useUserOptions, n as toFormData, o as useTask, r as useCompanyOptions, s as useTaskReferenceData } from "./task-api-BV9JuRXc.mjs";
import { a as enumType, c as objectType, l as stringType, r as booleanType, s as numberType } from "../_libs/zod.mjs";
import { t as Textarea } from "./textarea-DjqHhWkA.mjs";
import { t as Route } from "./form-CzlaoCY7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/form-DwmNgTbw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var MODULE_OPTIONS = [
	["LEAD", "Lead"],
	["OPPORTUNITY", "Opportunity"],
	["QUOTATION", "Quotation"]
];
var REGARDING_OPTIONS = [
	"Follow Up",
	"Payment",
	"MISCELLANEOUS"
];
var PRIORITY_OPTIONS = [
	"LOW",
	"MEDIUM",
	"HIGH",
	"URGENT"
];
var STATUS_OPTIONS = [
	"PENDING",
	"IN_PROGRESS",
	"COMPLETED",
	"CANCELLED"
];
var FREQUENCY_OPTIONS = [
	"DAILY",
	"WEEKLY",
	"MONTHLY",
	"YEARLY"
];
var taskSchema = objectType({
	description: stringType(),
	module: enumType([
		"",
		"LEAD",
		"OPPORTUNITY",
		"QUOTATION"
	]),
	task_regarding: stringType().min(1, "Select what the task is regarding"),
	reference_id: stringType().min(1, "Select an enquiry date or quotation number"),
	company: stringType().min(1, "Select a company"),
	followup_date: stringType().min(1, "Follow-up date is required"),
	priority: enumType([
		"LOW",
		"MEDIUM",
		"HIGH",
		"URGENT"
	]),
	status: enumType([
		"PENDING",
		"IN_PROGRESS",
		"COMPLETED",
		"CANCELLED"
	]),
	assigned_to: stringType(),
	remarks: stringType(),
	is_recurring: booleanType(),
	repeat_frequency: stringType(),
	repeat_interval: numberType().int().min(1, "Repeat interval must be at least 1"),
	repeat_end_date: stringType()
}).superRefine((values, context) => {
	if (!values.module) context.addIssue({
		code: "custom",
		path: ["module"],
		message: "Select a module"
	});
	if (values.is_recurring && !values.repeat_frequency) context.addIssue({
		code: "custom",
		path: ["repeat_frequency"],
		message: "Select a repeat frequency"
	});
});
function localDateValue() {
	const date = /* @__PURE__ */ new Date();
	const month = String(date.getMonth() + 1).padStart(2, "0");
	const day = String(date.getDate()).padStart(2, "0");
	return `${date.getFullYear()}-${month}-${day}`;
}
function emptyTask() {
	return {
		description: "",
		module: "",
		task_regarding: "Follow Up",
		reference_id: "",
		company: "",
		followup_date: localDateValue(),
		priority: "MEDIUM",
		status: "PENDING",
		assigned_to: "",
		remarks: "",
		is_recurring: false,
		repeat_frequency: "",
		repeat_interval: 1,
		repeat_end_date: ""
	};
}
function taskToForm(task) {
	return {
		description: task.description ?? "",
		module: task.module,
		task_regarding: task.task_regarding ?? "Follow Up",
		reference_id: task.reference_id ?? "",
		company: task.company == null ? "" : String(task.company),
		followup_date: task.followup_date ?? "",
		priority: task.priority,
		status: task.status,
		assigned_to: task.assigned_to == null ? "" : String(task.assigned_to),
		remarks: task.remarks ?? "",
		is_recurring: task.is_recurring,
		repeat_frequency: task.repeat_frequency ?? "",
		repeat_interval: task.repeat_interval ?? 1,
		repeat_end_date: task.repeat_end_date ?? ""
	};
}
var fieldClassName = "h-10 w-full rounded-md border border-input bg-background px-3 text-sm shadow-sm outline-none focus-visible:ring-2 focus-visible:ring-ring";
var labelClassName = "mb-1.5 block text-sm font-medium";
function formatLeadDate(value) {
	if (!value) return "—";
	const match = value.match(/^(\d{4})-(\d{2})-(\d{2})$/);
	return match ? `${match[3]}-${match[2]}-${match[1]}` : value;
}
function formatFollowupHistoryDate(value) {
	if (!value) return "—";
	const match = value.match(/^(\d{4})-(\d{2})-(\d{2})$/);
	if (match) return `${match[3]}-${match[2]}-${match[1]}`;
	return value;
}
function formatLeadLabel(value) {
	if (!value) return "—";
	return value.replaceAll("_", " ").toLowerCase().replace(/\b\w/g, (character) => character.toUpperCase());
}
function formatMoney(value) {
	return `₹${value.toLocaleString("en-IN", {
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	})}`;
}
function LeadDetail({ label, value, wide = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: wide ? "sm:col-span-2" : "",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs font-medium uppercase text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-1 break-words text-sm",
			children: value || "—"
		})]
	});
}
function TaskFormPage() {
	const { taskId, module: modulePrefill, companyId: companyPrefill, referenceId: referencePrefill } = Route.useSearch();
	const navigate = useNavigate();
	const numericTaskId = taskId && /^\d+$/.test(taskId) ? Number(taskId) : void 0;
	const isEdit = numericTaskId !== void 0;
	const taskQuery = useTask(numericTaskId);
	const referenceQuery = useTaskReferenceData();
	const companyQuery = useCompanyOptions();
	const companies = companyQuery.data ?? [];
	const { data: users = [] } = useUserOptions();
	const save = useSaveTask();
	const [values, setValues] = import_react.useState(emptyTask);
	const [files, setFiles] = import_react.useState([]);
	const [savedAttachments, setSavedAttachments] = import_react.useState([]);
	const [removedAttachmentIds, setRemovedAttachmentIds] = import_react.useState([]);
	const [leadDetailsOpen, setLeadDetailsOpen] = import_react.useState(false);
	const [quotationDetailsOpen, setQuotationDetailsOpen] = import_react.useState(false);
	const [historyOpen, setHistoryOpen] = import_react.useState(false);
	import_react.useEffect(() => {
		if (isEdit || !modulePrefill) return;
		setValues((current) => ({
			...current,
			module: modulePrefill,
			company: companyPrefill ?? "",
			reference_id: referencePrefill ?? ""
		}));
	}, [
		isEdit,
		modulePrefill,
		companyPrefill,
		referencePrefill
	]);
	import_react.useEffect(() => {
		if (taskQuery.data) {
			setValues(taskToForm(taskQuery.data));
			setSavedAttachments(taskQuery.data.attachments ?? []);
			setRemovedAttachmentIds([]);
		}
	}, [taskQuery.data]);
	const selectedCompanyId = values.company ? Number(values.company) : null;
	const quotationCompanyIds = new Set((referenceQuery.data?.quotations ?? []).map((quotation) => quotation.companyId).filter((companyId) => companyId !== null));
	const selectableCompanies = values.module === "QUOTATION" ? companies.filter((company) => quotationCompanyIds.has(company.value)) : companies;
	const referenceOptions = !selectedCompanyId || !referenceQuery.data ? [] : values.module === "LEAD" ? referenceQuery.data.leads.filter((option) => option.companyId === selectedCompanyId) : values.module === "OPPORTUNITY" ? referenceQuery.data.opportunities.filter((option) => option.companyId === selectedCompanyId) : values.module === "QUOTATION" ? referenceQuery.data.quotations.filter((option) => option.companyId === selectedCompanyId) : [];
	const selectedCompany = companies.find((company) => company.value === selectedCompanyId);
	const selectedReference = referenceOptions.find((option) => option.value === values.reference_id);
	const selectedLead = values.module === "LEAD" ? selectedReference?.lead : void 0;
	const selectedQuotation = values.module === "QUOTATION" ? selectedReference?.quotation : void 0;
	const followupHistory = [...taskQuery.data?.followup_history ?? []].reverse();
	import_react.useEffect(() => {
		if (selectedCompanyId === null || referenceQuery.isLoading) return;
		if (!referenceOptions.some((option) => option.value === values.reference_id)) setValues((current) => ({
			...current,
			reference_id: referenceOptions[0]?.value ?? ""
		}));
	}, [
		selectedCompanyId,
		values.module,
		values.reference_id,
		referenceOptions,
		referenceQuery.isLoading
	]);
	const generatedTitle = [
		values.task_regarding,
		selectedCompany?.label,
		selectedReference?.label
	].filter(Boolean).join(" - ").slice(0, 255);
	const updateValue = (key, value) => {
		setValues((current) => ({
			...current,
			[key]: value
		}));
	};
	const handleSubmit = async (event) => {
		event.preventDefault();
		const result = taskSchema.safeParse(values);
		if (!result.success) {
			toast.error(result.error.issues[0]?.message ?? "Check the task details");
			return;
		}
		const payload = {
			...result.data,
			title: generatedTitle || `${result.data.task_regarding} task`,
			company: Number(result.data.company),
			assigned_to: result.data.assigned_to ? Number(result.data.assigned_to) : null,
			repeat_frequency: result.data.is_recurring ? result.data.repeat_frequency : null,
			repeat_end_date: result.data.is_recurring ? result.data.repeat_end_date || null : null
		};
		try {
			const body = toFormData(payload, files);
			removedAttachmentIds.forEach((id) => body.append("remove_attachment_ids", String(id)));
			await save.mutateAsync({
				id: numericTaskId,
				body
			});
			toast.success(isEdit ? "Task updated" : "Task created");
			await navigate({ to: "/tasks" });
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Could not save task");
		}
	};
	if (isEdit && taskQuery.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-6 text-sm text-muted-foreground",
		children: "Loading task..."
	});
	if (isEdit && (!numericTaskId || taskQuery.isError || !taskQuery.data)) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-destructive",
			children: "Task not found."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "outline",
			onClick: () => navigate({ to: "/tasks" }),
			children: "Back to tasks"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto w-full max-w-4xl space-y-6 p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "outline",
					size: "icon",
					"aria-label": "Back to tasks",
					onClick: () => navigate({ to: "/tasks" }),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-semibold",
					children: isEdit ? "Edit Task" : "New Task"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: isEdit ? "Update task details and reminders." : "Add a follow-up or reminder."
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: handleSubmit,
				className: "space-y-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 gap-5 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: labelClassName,
								children: "Module *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: fieldClassName,
								value: values.module,
								onChange: (event) => {
									const module = event.target.value;
									setValues((current) => ({
										...current,
										module,
										company: "",
										reference_id: ""
									}));
								},
								required: true,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Select module"
								}), MODULE_OPTIONS.map(([value, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value,
									children: label
								}, value))]
							})] }),
							values.module && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: labelClassName,
								children: "Company *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: fieldClassName,
								value: values.company,
								onChange: (event) => setValues((current) => ({
									...current,
									company: event.target.value,
									reference_id: ""
								})),
								disabled: companyQuery.isLoading || values.module === "QUOTATION" && referenceQuery.isLoading,
								required: true,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: values.module === "QUOTATION" && selectableCompanies.length === 0 ? "No companies with quotations" : "Select company"
								}), selectableCompanies.map((company) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: company.value,
									children: company.label
								}, company.value))]
							})] }),
							values.module && values.company && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: labelClassName,
								children: values.module === "QUOTATION" ? "Quotation Number" : "Enquiry Date"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: referenceQuery.isLoading ? values.module === "QUOTATION" ? "Loading quotation number..." : "Loading enquiry date..." : values.module === "QUOTATION" ? selectedReference?.label ?? "No quotation found" : selectedReference?.enquiryDate ?? "No enquiry date found",
								readOnly: true,
								"aria-readonly": "true"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: labelClassName,
								children: "Regarding"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: fieldClassName,
								value: values.task_regarding,
								onChange: (event) => updateValue("task_regarding", event.target.value),
								children: REGARDING_OPTIONS.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: option,
									children: option === "MISCELLANEOUS" ? "Miscellaneous" : option
								}, option))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: labelClassName,
								children: "Follow-up date"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								required: true,
								type: "date",
								value: values.followup_date,
								onChange: (event) => updateValue("followup_date", event.target.value)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: labelClassName,
								children: "Priority"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: fieldClassName,
								value: values.priority,
								onChange: (event) => updateValue("priority", event.target.value),
								children: PRIORITY_OPTIONS.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: option,
									children: option
								}, option))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: labelClassName,
								children: "Status"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: fieldClassName,
								value: values.status,
								onChange: (event) => updateValue("status", event.target.value),
								children: STATUS_OPTIONS.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: option,
									children: option.replaceAll("_", " ")
								}, option))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: labelClassName,
								children: "Assigned to"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: fieldClassName,
								value: values.assigned_to,
								onChange: (event) => updateValue("assigned_to", event.target.value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Unassigned"
								}), users.map((user) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: user.value,
									children: user.label
								}, user.value))]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-3 sm:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: values.is_recurring,
									onChange: (event) => updateValue("is_recurring", event.target.checked),
									className: "size-4 accent-primary"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium",
									children: "Recurring task"
								})]
							}),
							values.is_recurring && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: labelClassName,
									children: "Repeat frequency"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									required: true,
									className: fieldClassName,
									value: values.repeat_frequency,
									onChange: (event) => updateValue("repeat_frequency", event.target.value),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Select frequency"
									}), FREQUENCY_OPTIONS.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: option,
										children: option
									}, option))]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: labelClassName,
									children: "Repeat every"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									min: 1,
									required: true,
									type: "number",
									value: values.repeat_interval,
									onChange: (event) => updateValue("repeat_interval", Number(event.target.value))
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: labelClassName,
									children: "Repeat until"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: values.repeat_end_date,
									onChange: (event) => updateValue("repeat_end_date", event.target.value)
								})] })
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "sm:col-span-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: labelClassName,
										children: "Attachments"
									}),
									savedAttachments.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mb-2 space-y-1 rounded-md border bg-muted/40 p-2",
										children: savedAttachments.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex items-center justify-between gap-2 text-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "truncate",
												children: file.file_name
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex shrink-0 items-center gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													href: file.file_url,
													target: "_blank",
													rel: "noreferrer",
													className: "text-xs font-medium text-primary hover:underline",
													children: "View"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													"aria-label": `Remove ${file.file_name}`,
													className: "text-xs text-destructive hover:underline",
													onClick: () => {
														setSavedAttachments((list) => list.filter((a) => a.id !== file.id));
														setRemovedAttachmentIds((ids) => [...ids, file.id]);
													},
													children: "Remove"
												})]
											})]
										}, file.id))
									}),
									files.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mb-2 space-y-1 rounded-md border p-2",
										children: files.map((file, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex items-center justify-between gap-2 text-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "truncate",
												children: [
													file.name,
													" ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-xs text-muted-foreground",
														children: "(new)"
													})
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												"aria-label": `Remove ${file.name}`,
												className: "text-xs text-destructive hover:underline",
												onClick: () => setFiles((list) => list.filter((_, i) => i !== index)),
												children: "Remove"
											})]
										}, `${file.name}-${file.lastModified}`))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "file",
										multiple: true,
										onChange: (event) => {
											const chosen = Array.from(event.target.files ?? []);
											setFiles((current) => [...current, ...chosen.filter((c) => !current.some((f) => f.name === c.name && f.size === c.size))]);
											event.target.value = "";
										}
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "sm:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: labelClassName,
									children: "Remarks"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									value: values.remarks,
									onChange: (event) => updateValue("remarks", event.target.value)
								})]
							})
						]
					}),
					referenceQuery.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "alert",
						className: "text-sm text-destructive",
						children: "Could not load the related enquiries and quotations. Please try again."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-2 border-t pt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								isEdit && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									variant: "outline",
									onClick: () => setHistoryOpen(true),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "mr-2 size-4" }),
										"Follow-up History",
										followupHistory.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "ml-2 rounded-full bg-muted px-1.5 text-xs tabular-nums",
											children: followupHistory.length
										})
									]
								}),
								selectedLead && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									variant: "outline",
									onClick: () => setLeadDetailsOpen(true),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "mr-2 size-4" }), "View Lead Details"]
								}),
								selectedQuotation && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									variant: "outline",
									onClick: () => setQuotationDetailsOpen(true),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "mr-2 size-4" }), "View Quotation Details"]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "ml-auto flex justify-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								onClick: () => navigate({ to: "/tasks" }),
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "submit",
								disabled: save.isPending || taskQuery.isLoading || companyQuery.isLoading || referenceQuery.isLoading || referenceQuery.isError,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "mr-2 size-4" }), save.isPending ? "Saving..." : isEdit ? "Update Task" : "Create Task"]
							})]
						})]
					})
				]
			}),
			isEdit && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
				open: historyOpen,
				onClose: () => setHistoryOpen(false),
				title: "Follow-up History",
				eyebrow: "TASK",
				wide: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-h-[70vh] overflow-y-auto p-5",
					children: followupHistory.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "space-y-3",
						children: followupHistory.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-md border border-line bg-surface p-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-start justify-between gap-x-4 gap-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: formatFollowupHistoryDate(entry.followup_date)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted-foreground",
									children: [entry.updated_by && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: entry.updated_by }), entry.timestamp && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-2",
										children: entry.timestamp
									})]
								})]
							}), entry.remark && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1.5 whitespace-pre-wrap text-muted-foreground",
								children: entry.remark
							})]
						}, entry.id))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-8 text-center text-sm text-muted-foreground",
						children: "No follow-up history yet."
					})
				})
			}),
			selectedLead && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
				open: leadDetailsOpen,
				onClose: () => setLeadDetailsOpen(false),
				title: `Lead - #${selectedLead.srNo}`,
				eyebrow: "LEAD DETAILS",
				wide: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "grid gap-x-6 gap-y-5 p-5 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeadDetail, {
							label: "Company",
							value: selectedLead.companyName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeadDetail, {
							label: "City",
							value: selectedLead.companyCity
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeadDetail, {
							label: "State",
							value: selectedLead.companyState
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeadDetail, {
							label: "Enquiry Date",
							value: formatLeadDate(selectedLead.enquiryDate)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeadDetail, {
							label: "Enquiry For",
							value: formatLeadLabel(selectedLead.enquiryFor)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeadDetail, {
							label: "Status",
							value: formatLeadLabel(selectedLead.status)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeadDetail, {
							label: "Source",
							value: formatLeadLabel(selectedLead.source)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeadDetail, {
							label: "Received By",
							value: "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeadDetail, {
							label: "Assigned To",
							value: "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "sm:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs font-medium uppercase text-muted-foreground",
								children: "Contacts"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 text-sm",
								children: [
									selectedLead.contactName,
									selectedLead.contactMobile,
									selectedLead.contactEmail
								].filter(Boolean).join(" · ") || "—"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeadDetail, {
							label: "Address",
							value: selectedLead.companyAddress,
							wide: true
						})
					]
				})
			}),
			selectedQuotation && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
				open: quotationDetailsOpen,
				onClose: () => setQuotationDetailsOpen(false),
				title: `Quotation - ${selectedQuotation.quotationNumber}`,
				eyebrow: "QUOTATION DETAILS",
				wide: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-5 p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "grid gap-x-6 gap-y-4 sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeadDetail, {
									label: "Company",
									value: selectedQuotation.companyName
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeadDetail, {
									label: "Date",
									value: formatLeadDate(selectedQuotation.quotationDate)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeadDetail, {
									label: "Status",
									value: selectedQuotation.status
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeadDetail, {
									label: "Total",
									value: formatMoney(selectedQuotation.totalAmount)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeadDetail, {
									label: "City",
									value: selectedQuotation.city
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeadDetail, {
									label: "State",
									value: selectedQuotation.state
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeadDetail, {
									label: "Delivery",
									value: selectedQuotation.deliveryTimeline
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeadDetail, {
									label: "Tax Type",
									value: formatLeadLabel(selectedQuotation.taxType)
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-x-auto rounded-md border border-border",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full min-w-[900px] text-left text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
									className: "bg-muted/50 text-xs text-muted-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2 font-medium",
											children: "Type"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2 font-medium",
											children: "Description"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2 font-medium",
											children: "Requirements"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2 font-medium",
											children: "Remark"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2 text-right font-medium",
											children: "Est. Days"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2 text-right font-medium",
											children: "Unit Price"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2 text-right font-medium",
											children: "Total"
										})
									] })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [selectedQuotation.items.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t border-border",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-2 font-medium",
											children: item.moduleName || "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-2",
											children: item.description || "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-2",
											children: item.requirements || "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-2",
											children: item.remarks || "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-2 text-right",
											children: item.estimatedDays ?? "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-2 text-right",
											children: item.estimatedCost == null ? "—" : formatMoney(item.estimatedCost)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-2 text-right",
											children: formatMoney(item.amount)
										})
									]
								}, item.id ?? `${item.moduleName}-${index}`)), selectedQuotation.items.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									colSpan: 7,
									className: "px-3 py-5 text-center text-muted-foreground",
									children: "No quotation items."
								}) })] })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "ml-auto grid max-w-xs gap-2 border-t border-border pt-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Subtotal" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: formatMoney(selectedQuotation.subtotal) })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between gap-4 font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: formatMoney(selectedQuotation.totalAmount) })]
							})]
						})
					]
				})
			})
		]
	});
}
//#endregion
export { TaskFormPage as component };
