import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { A as Layers, G as CircleCheck, H as Clock, K as CircleAlert, O as ListChecks, W as Circle, _ as RefreshCw, a as TriangleAlert, c as Target, dt as Activity, g as Repeat, l as Star, nt as ChartColumn, o as TrendingUp, rt as CalendarDays, tt as ChartPie } from "../_libs/lucide-react.mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as getTaskDashboard } from "./task-api-BV9JuRXc.mjs";
import { t as Route } from "./dashboard-DenKwV6r.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-BzIIzLty.js
var import_jsx_runtime = require_jsx_runtime();
var label = (value) => value ? value.replaceAll("_", " ").toLowerCase().replace(/^\w/, (c) => c.toUpperCase()) : "None";
var KPI_TONES = {
	blue: {
		card: "border-blue-100 bg-blue-50 dark:border-blue-500/20 dark:bg-blue-500/10",
		icon: "bg-blue-500"
	},
	amber: {
		card: "border-amber-100 bg-amber-50 dark:border-amber-500/20 dark:bg-amber-500/10",
		icon: "bg-amber-500"
	},
	sky: {
		card: "border-sky-100 bg-sky-50 dark:border-sky-500/20 dark:bg-sky-500/10",
		icon: "bg-sky-500"
	},
	emerald: {
		card: "border-emerald-100 bg-emerald-50 dark:border-emerald-500/20 dark:bg-emerald-500/10",
		icon: "bg-emerald-500"
	},
	red: {
		card: "border-red-100 bg-red-50 dark:border-red-500/20 dark:bg-red-500/10",
		icon: "bg-red-500"
	},
	orange: {
		card: "border-orange-100 bg-orange-50 dark:border-orange-500/20 dark:bg-orange-500/10",
		icon: "bg-orange-500"
	},
	teal: {
		card: "border-teal-100 bg-teal-50 dark:border-teal-500/20 dark:bg-teal-500/10",
		icon: "bg-teal-500"
	},
	violet: {
		card: "border-violet-100 bg-violet-50 dark:border-violet-500/20 dark:bg-violet-500/10",
		icon: "bg-violet-500"
	},
	pink: {
		card: "border-pink-100 bg-pink-50 dark:border-pink-500/20 dark:bg-pink-500/10",
		icon: "bg-pink-500"
	}
};
function KpiCard({ title, value, icon: Icon, tone, loading }) {
	const styles = KPI_TONES[tone];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex items-center justify-between rounded-xl border p-4 ${styles.card}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs text-muted-foreground",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 text-2xl font-bold tabular-nums",
			children: loading ? "—" : value
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `flex size-10 shrink-0 items-center justify-center rounded-full text-white ${styles.icon}`,
			"aria-hidden": "true",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
		})]
	});
}
var STATUS_META = {
	COMPLETED: {
		icon: CircleCheck,
		chip: "text-emerald-600 bg-emerald-50 dark:bg-emerald-500/10",
		bar: "bg-emerald-500"
	},
	PENDING: {
		icon: Clock,
		chip: "text-amber-600 bg-amber-50 dark:bg-amber-500/10",
		bar: "bg-amber-500"
	},
	IN_PROGRESS: {
		icon: Activity,
		chip: "text-blue-600 bg-blue-50 dark:bg-blue-500/10",
		bar: "bg-blue-500"
	}
};
var STATUS_FALLBACK = {
	icon: Circle,
	chip: "text-slate-600 bg-slate-100 dark:bg-slate-500/10",
	bar: "bg-slate-400"
};
var PRIORITY_META = {
	HIGH: {
		icon: TriangleAlert,
		chip: "text-orange-700 bg-orange-100 dark:bg-orange-500/15",
		bar: "bg-orange-500",
		badge: true
	},
	MEDIUM: {
		icon: Target,
		chip: "text-blue-700 bg-blue-100 dark:bg-blue-500/15",
		bar: "bg-blue-500",
		badge: true
	},
	LOW: {
		icon: Circle,
		chip: "text-slate-700 bg-slate-100 dark:bg-slate-500/15",
		bar: "bg-slate-400",
		badge: true
	}
};
var PRIORITY_FALLBACK = {
	...STATUS_FALLBACK,
	badge: true
};
var MODULE_META = {
	LEAD: {
		icon: ListChecks,
		chip: "text-teal-600 bg-teal-50 dark:bg-teal-500/10",
		bar: "bg-teal-500"
	},
	QUOTATION: {
		icon: ChartColumn,
		chip: "text-teal-600 bg-teal-50 dark:bg-teal-500/10",
		bar: "bg-teal-500"
	}
};
var MODULE_FALLBACK = {
	icon: Layers,
	chip: "text-teal-600 bg-teal-50 dark:bg-teal-500/10",
	bar: "bg-teal-500"
};
function BreakdownCard({ title, icon: Icon, headerTone, rows, total, loading }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl border border-line bg-surface",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-center gap-3 border-b border-line px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `flex size-8 items-center justify-center rounded-md ${headerTone}`,
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-semibold",
				children: title
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4 p-4",
			children: [rows.map((row) => {
				const percent = total ? Math.round(row.count / total * 100) : 0;
				const RowIcon = row.meta.icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex items-center gap-2",
						children: row.meta.badge ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: `inline-flex items-center gap-1.5 rounded-md px-2 py-0.5 text-xs font-semibold uppercase ${row.meta.chip}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowIcon, {
								className: "size-3",
								"aria-hidden": "true"
							}), row.name]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `flex size-6 items-center justify-center rounded-md ${row.meta.chip}`,
							"aria-hidden": "true",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowIcon, { className: "size-3.5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: row.name
						})] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold tabular-nums",
						children: row.count
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 h-1.5 overflow-hidden rounded-full bg-muted",
					role: "progressbar",
					"aria-label": `${row.name}: ${percent}% of tasks`,
					"aria-valuenow": percent,
					"aria-valuemin": 0,
					"aria-valuemax": 100,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `h-full rounded-full ${row.meta.bar}`,
						style: { width: `${percent}%` }
					})
				})] }, row.key);
			}), !rows.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-6 text-center text-sm text-muted-foreground",
				children: loading ? "Loading…" : "No tasks to show."
			})]
		})]
	});
}
function TaskDashboardPage() {
	const navigate = useNavigate();
	const { userId } = Route.useSearch();
	const dashboardQuery = useQuery({
		queryKey: ["task-dashboard", userId ?? "all"],
		queryFn: () => getTaskDashboard(userId)
	});
	const data = dashboardQuery.data;
	const loading = dashboardQuery.isLoading;
	const total = data?.total ?? 0;
	const completionRate = total ? Math.round((data?.completed ?? 0) / total * 100) : 0;
	const statusRows = (data?.by_status ?? []).map((r) => ({
		key: r.status,
		name: label(r.status),
		count: r.count,
		meta: STATUS_META[r.status?.toUpperCase()] ?? STATUS_FALLBACK
	}));
	const priorityRows = (data?.by_priority ?? []).map((r) => ({
		key: r.priority,
		name: (r.priority ?? "None").toString(),
		count: r.count,
		meta: PRIORITY_META[r.priority?.toUpperCase()] ?? PRIORITY_FALLBACK
	}));
	const moduleRows = (data?.by_module ?? []).map((r) => ({
		key: r.module ?? "none",
		name: (r.module ?? "None").toString(),
		count: r.count,
		meta: MODULE_META[r.module?.toUpperCase() ?? ""] ?? MODULE_FALLBACK
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-mono text-[11px] tracking-wide text-muted-foreground",
						children: "TASKS"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-display text-3xl font-bold tracking-tight",
						children: "Task Dashboard"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: "Workload, deadlines and completion across your tasks."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							"aria-label": "Filter by assignee user ID",
							placeholder: "Assignee user ID",
							className: "w-44",
							defaultValue: userId ?? "",
							onKeyDown: (event) => {
								if (event.key !== "Enter") return;
								const value = event.currentTarget.value.trim();
								navigate({
									to: "/tasks/dashboard",
									search: { userId: value || void 0 }
								});
							}
						}),
						userId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: () => navigate({
								to: "/tasks/dashboard",
								search: {}
							}),
							children: "Clear"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "outline",
							onClick: () => dashboardQuery.refetch(),
							disabled: dashboardQuery.isFetching,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `mr-2 size-4 ${dashboardQuery.isFetching ? "animate-spin" : ""}` }), "Refresh"]
						})
					]
				})]
			}),
			dashboardQuery.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "text-sm text-destructive",
				children: dashboardQuery.error.message || "Could not load the task dashboard."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Total Tasks",
						value: data?.total ?? 0,
						icon: ListChecks,
						tone: "blue",
						loading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Pending",
						value: data?.pending ?? 0,
						icon: Clock,
						tone: "amber",
						loading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "In Progress",
						value: data?.in_progress ?? 0,
						icon: Activity,
						tone: "sky",
						loading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Completed",
						value: data?.completed ?? 0,
						icon: CircleCheck,
						tone: "emerald",
						loading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Overdue",
						value: data?.overdue ?? 0,
						icon: TriangleAlert,
						tone: "red",
						loading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Due Today",
						value: data?.due_today ?? 0,
						icon: CalendarDays,
						tone: "orange",
						loading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Upcoming",
						value: data?.upcoming ?? 0,
						icon: TrendingUp,
						tone: "teal",
						loading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Recurring",
						value: data?.recurring ?? 0,
						icon: Repeat,
						tone: "violet",
						loading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Miscellaneous",
						value: data?.miscellaneous ?? 0,
						icon: Star,
						tone: "pink",
						loading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Completion Rate",
						value: `${completionRate}%`,
						icon: ChartPie,
						tone: "emerald",
						loading
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BreakdownCard, {
						title: "By Status",
						icon: Clock,
						headerTone: "bg-blue-50 text-blue-600 dark:bg-blue-500/10",
						rows: statusRows,
						total,
						loading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BreakdownCard, {
						title: "By Priority",
						icon: CircleAlert,
						headerTone: "bg-orange-50 text-orange-600 dark:bg-orange-500/10",
						rows: priorityRows,
						total,
						loading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BreakdownCard, {
						title: "By Module",
						icon: Layers,
						headerTone: "bg-teal-50 text-teal-600 dark:bg-teal-500/10",
						rows: moduleRows,
						total,
						loading
					})
				]
			})
		]
	});
}
//#endregion
export { TaskDashboardPage as component };
