import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { P as updateLead, _ as getLead, i as createLead, v as getLeadOptions } from "./api-W8TaUl4r.mjs";
import { c as Target, h as Save, lt as ArrowLeft, z as Download } from "../_libs/lucide-react.mjs";
import { a as listCompanyContacts, c as updateCompany, i as listCompanies, l as updateCompanyContact, n as createCompanyContact, o as listCountries, r as listCities, s as listStates, t as createCompany } from "./company-api-BQqpN8GR.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as downloadLeadCsvTemplate } from "./lead-csv-template-DukjP975.mjs";
import { t as Route } from "./leads.form-ZqCPhvc7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/leads.form-CKN-yg3l.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FALLBACK_LEAD_OPTIONS = {
	enquiry_for: [{
		value: "LEAD",
		label: "Lead"
	}, {
		value: "CLIENT",
		label: "Client"
	}],
	source: [
		{
			value: "WEBSITE",
			label: "Website"
		},
		{
			value: "SOCIAL_MEDIA",
			label: "Social Media"
		},
		{
			value: "GOOGLE",
			label: "Google Search"
		},
		{
			value: "ADVERTISEMENT",
			label: "Advertisement"
		},
		{
			value: "REFERENCE",
			label: "Reference"
		},
		{
			value: "EXISTING_CLIENT",
			label: "Existing Client"
		},
		{
			value: "COLD_CALL",
			label: "Cold Call"
		},
		{
			value: "EMAIL_MARKETING",
			label: "Email Marketing"
		},
		{
			value: "OTHER",
			label: "Other"
		}
	],
	status: [
		{
			value: "NEW",
			label: "New",
			dot: "bg-blue-500"
		},
		{
			value: "ACTIVE",
			label: "Active",
			dot: "bg-emerald-500"
		},
		{
			value: "HOT",
			label: "Hot",
			dot: "bg-red-500"
		},
		{
			value: "COLD",
			label: "Cold",
			dot: "bg-sky-300"
		},
		{
			value: "JUNK",
			label: "Junk",
			dot: "bg-zinc-400"
		},
		{
			value: "OTHER",
			label: "Other",
			dot: "bg-zinc-400"
		}
	]
};
var FOLLOWUP_SHORTCUTS = [
	{
		label: "Tomorrow",
		days: 1
	},
	{
		label: "In 3 days",
		days: 3
	},
	{
		label: "Next week",
		days: 7
	}
];
function toInputDate(date) {
	const month = String(date.getMonth() + 1).padStart(2, "0");
	const day = String(date.getDate()).padStart(2, "0");
	return `${date.getFullYear()}-${month}-${day}`;
}
function daysFromToday(days) {
	const date = /* @__PURE__ */ new Date();
	date.setDate(date.getDate() + days);
	return toInputDate(date);
}
function emptyLead() {
	return {
		company_name: "",
		company_address: "",
		company_city: "",
		company_state: "",
		company_pincode: "",
		company_country: "India",
		company_gst_number: "",
		contact_name: "",
		contact_designation: "",
		contact_mobile: "",
		contact_email: "",
		enquiry_for: "LEAD",
		enquiry_date: toInputDate(/* @__PURE__ */ new Date()),
		source: "OTHER",
		status: "NEW",
		followup_date: null,
		followup_remarks: "",
		is_opportunity: false
	};
}
var controlClass = "h-10 w-full rounded-md border border-input bg-background px-3 text-sm transition-colors hover:border-foreground/30 focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/20 disabled:cursor-not-allowed disabled:opacity-60 aria-[invalid=true]:border-destructive aria-[invalid=true]:ring-destructive/20";
function Field({ label, required, hint, error, className, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "grid gap-1.5 text-sm font-medium text-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [label, required && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				"aria-hidden": true,
				className: "ml-0.5 text-destructive",
				children: "*"
			})] }), children]
		}), error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			role: "alert",
			className: "mt-1.5 text-xs text-destructive",
			children: error
		}) : hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1.5 text-xs text-muted-foreground",
			children: hint
		}) : null]
	});
}
function Section({ id, title, description, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		"aria-labelledby": id,
		className: "space-y-6 border-b border-line py-8 first:pt-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			id,
			className: "font-display text-xl font-semibold tracking-tight",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted-foreground",
			children: description
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-8",
			children
		})]
	});
}
/**
* A titled block of related fields inside a Section.
* cols = 2 (default) or 3 columns on desktop; use "full" on a child to span the whole row.
*/
function Group({ title, cols = 2, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
		className: `grid gap-x-5 gap-y-5 ${cols === 3 ? "sm:grid-cols-3" : "sm:grid-cols-2"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
				className: "sr-only",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
				"aria-hidden": true,
				className: `flex items-center gap-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground ${cols === 3 ? "sm:col-span-3" : "sm:col-span-2"}`,
				children: [title, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-line" })]
			}),
			children
		]
	});
}
function LeadFormSkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-4xl animate-pulse space-y-8",
		"aria-busy": "true",
		"aria-label": "Loading enquiry",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-9 w-56 rounded bg-muted" }), [0, 1].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-6 border-b border-line pb-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-5 w-36 rounded bg-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 w-56 rounded bg-muted" })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 rounded bg-muted" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 rounded bg-muted" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 rounded bg-muted" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 rounded bg-muted" })
				]
			})]
		}, i))]
	});
}
function LeadFormPage() {
	const { leadId } = Route.useSearch();
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const [form, setForm] = (0, import_react.useState)(emptyLead);
	const [companySearch, setCompanySearch] = (0, import_react.useState)("");
	const [companySuggestionsOpen, setCompanySuggestionsOpen] = (0, import_react.useState)(false);
	const [selectedCompanyId, setSelectedCompanyId] = (0, import_react.useState)(null);
	const [companyCreating, setCompanyCreating] = (0, import_react.useState)(false);
	const [countryOptions, setCountryOptions] = (0, import_react.useState)([]);
	const [stateOptions, setStateOptions] = (0, import_react.useState)([]);
	const [cityOptions, setCityOptions] = (0, import_react.useState)([]);
	const [baseline, setBaseline] = (0, import_react.useState)(() => JSON.stringify(emptyLead()));
	const companyQuery = useQuery({
		queryKey: ["companies"],
		queryFn: listCompanies
	});
	const leadOptions = useQuery({
		queryKey: ["lead-options"],
		queryFn: getLeadOptions
	}).data ?? FALLBACK_LEAD_OPTIONS;
	const sourceOptions = leadOptions.source;
	const statusOptions = leadOptions.status;
	(0, import_react.useEffect)(() => {
		let mounted = true;
		async function loadMasterOptions() {
			try {
				const [countries, states, cities] = await Promise.all([
					listCountries(),
					listStates(),
					listCities()
				]);
				if (!mounted) return;
				setCountryOptions(countries);
				setStateOptions(states);
				setCityOptions(cities);
			} catch (error) {
				toast.error(error instanceof Error ? error.message : "Could not load master data");
			}
		}
		loadMasterOptions();
		return () => {
			mounted = false;
		};
	}, []);
	const leadQuery = useQuery({
		queryKey: ["lead", leadId],
		queryFn: () => getLead(leadId),
		enabled: Boolean(leadId)
	});
	const companySuggestions = (0, import_react.useMemo)(() => {
		const query = companySearch.trim().toLowerCase();
		const items = companyQuery.data ?? [];
		if (!query) return items.slice(0, 8);
		return items.filter((company) => company.name.toLowerCase().includes(query)).slice(0, 8);
	}, [companyQuery.data, companySearch]);
	(0, import_react.useEffect)(() => {
		if (leadQuery.data) {
			const lead = leadQuery.data;
			const loaded = {
				company_name: lead.companyName ?? "",
				company_address: lead.companyAddress ?? "",
				company_city: lead.companyCity ?? "",
				company_state: lead.companyState ?? "",
				company_pincode: lead.companyPincode ?? "",
				company_country: lead.companyCountry ?? "India",
				company_gst_number: lead.companyGstNumber ?? "",
				contact_name: lead.contactName ?? "",
				contact_designation: lead.contactDesignation ?? "",
				contact_mobile: lead.contactMobile ?? "",
				contact_email: lead.contactEmail ?? "",
				enquiry_for: lead.enquiryFor,
				enquiry_date: lead.enquiryDate,
				source: lead.source,
				status: lead.status.toUpperCase(),
				followup_date: lead.followupDate,
				followup_remarks: lead.followupRemarks,
				is_opportunity: lead.isOpportunity
			};
			setForm(loaded);
			setCompanySearch(lead.companyName ?? "");
			setSelectedCompanyId(null);
			setBaseline(JSON.stringify(loaded));
		}
	}, [leadQuery.data]);
	(0, import_react.useEffect)(() => {
		if (!companyQuery.data) return;
		if (!form.company_name.trim()) {
			setCompanySearch("");
			return;
		}
		setCompanySearch(form.company_name);
	}, [companyQuery.data, form.company_name]);
	const fillCompanyFields = async (company) => {
		const nextCompanyName = company.name ?? "";
		const nextCompanyAddress = company.address ?? "";
		const nextCompanyCity = company.city_name ?? "";
		const nextCompanyState = company.state_name ?? "";
		const nextCompanyPincode = company.pincode ?? "";
		const nextCompanyCountry = company.country_name || "India";
		const nextCompanyGst = company.gst_number ?? "";
		setSelectedCompanyId(company.id);
		setForm((current) => ({
			...current,
			company_name: nextCompanyName,
			company_address: nextCompanyAddress,
			company_city: nextCompanyCity,
			company_state: nextCompanyState,
			company_pincode: nextCompanyPincode,
			company_country: nextCompanyCountry,
			company_gst_number: nextCompanyGst
		}));
		setCompanySearch(nextCompanyName);
		setCompanySuggestionsOpen(false);
		try {
			const contacts = await listCompanyContacts(company.id);
			const preferred = contacts.find((contact) => contact.is_primary) ?? contacts[0];
			if (!preferred) return;
			setForm((current) => ({
				...current,
				contact_name: preferred.name ?? current.contact_name,
				contact_designation: preferred.designation ?? "",
				contact_mobile: preferred.phone ?? current.contact_mobile,
				contact_email: preferred.email ?? current.contact_email
			}));
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Could not load company contacts");
		}
	};
	const persistCompanyAndContact = async () => {
		const trimmedCompanyName = form.company_name.trim();
		const trimmedContactName = form.contact_name.trim();
		if (!trimmedCompanyName) return null;
		const matchedCompany = companyQuery.data?.find((company) => company.name.trim().toLowerCase() === trimmedCompanyName.toLowerCase()) ?? null;
		const selectedCountryId = countryOptions.find((country) => country.name.trim().toLowerCase() === form.company_country.trim().toLowerCase())?.id ?? null;
		const selectedStateId = stateOptions.find((state) => state.name.trim().toLowerCase() === form.company_state.trim().toLowerCase() && (selectedCountryId === null || state.country === selectedCountryId))?.id ?? null;
		const selectedCityId = cityOptions.find((city) => city.name.trim().toLowerCase() === form.company_city.trim().toLowerCase() && (selectedStateId === null || city.state === selectedStateId))?.id ?? null;
		const companyPayload = {
			name: trimmedCompanyName,
			address: form.company_address,
			city: selectedCityId,
			state: selectedStateId,
			country: selectedCountryId,
			pincode: form.company_pincode,
			gst_number: form.company_gst_number
		};
		const companyToSaveId = selectedCompanyId ?? matchedCompany?.id ?? null;
		const savedCompany = companyToSaveId ? await updateCompany(companyToSaveId, companyPayload) : await createCompany(companyPayload);
		setSelectedCompanyId(savedCompany.id);
		setCompanySearch(savedCompany.name);
		setCompanySuggestionsOpen(false);
		await companyQuery.refetch();
		if (trimmedContactName) {
			const contacts = await listCompanyContacts(savedCompany.id);
			const preferredContact = contacts.find((contact) => contact.name.trim().toLowerCase() === trimmedContactName.toLowerCase()) ?? contacts.find((contact) => contact.is_primary) ?? contacts[0];
			const contactPayload = {
				name: trimmedContactName,
				designation: form.contact_designation,
				phone: form.contact_mobile,
				email: form.contact_email,
				is_primary: true
			};
			if (preferredContact) await updateCompanyContact(savedCompany.id, preferredContact.id, contactPayload);
			else await createCompanyContact(savedCompany.id, contactPayload);
		}
		setForm((current) => ({
			...current,
			company_name: savedCompany.name,
			company_address: savedCompany.address ?? current.company_address,
			company_city: current.company_city || form.company_city,
			company_state: current.company_state || form.company_state,
			company_pincode: savedCompany.pincode ?? current.company_pincode,
			company_country: current.company_country || form.company_country || "India",
			company_gst_number: savedCompany.gst_number ?? current.company_gst_number
		}));
		return savedCompany;
	};
	const saveCompanyToMaster = async () => {
		if (!form.company_name.trim()) {
			toast.error("Enter a company name before saving it.");
			return;
		}
		setCompanyCreating(true);
		try {
			const savedCompany = await persistCompanyAndContact();
			if (savedCompany) toast.success(selectedCompanyId ? `Company "${savedCompany.name}" updated.` : `Company "${savedCompany.name}" added.`);
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Could not save company");
		} finally {
			setCompanyCreating(false);
		}
	};
	const saveMutation = useMutation({
		mutationFn: async (values) => {
			await persistCompanyAndContact();
			return leadId ? updateLead(leadId, values) : createLead(values);
		},
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: ["leads"] });
			if (leadId) await queryClient.invalidateQueries({ queryKey: ["lead", leadId] });
			toast.success(leadId ? "Lead updated" : "Lead created");
			await navigate({ to: "/marketing/leads" });
		},
		onError: (error) => toast.error(error.message || "Unable to save lead")
	});
	const update = (key, value) => setForm((current) => ({
		...current,
		[key]: value
	}));
	const isDirty = JSON.stringify(form) !== baseline;
	const followupError = form.followup_date && form.followup_date < form.enquiry_date ? "Follow-up can't be before the enquiry date." : null;
	const canSubmit = !saveMutation.isPending && !followupError;
	const goBack = () => navigate({ to: "/marketing/leads" });
	if (leadId && leadQuery.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeadFormSkeleton, {});
	if (leadId && leadQuery.isError) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-3xl space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-destructive",
			children: leadQuery.error.message || "Couldn't load this enquiry. Try again, or go back to the list."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: () => leadQuery.refetch(),
				children: "Try again"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "ghost",
				onClick: goBack,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {}), " Back to leads"]
			})]
		})]
	});
	const selectedCountry = countryOptions.find((country) => country.name === form.company_country);
	const selectedState = stateOptions.find((state) => state.name === form.company_state);
	const filteredStates = stateOptions.filter((state) => !selectedCountry || state.country === selectedCountry.id);
	const filteredCities = cityOptions.filter((city) => !selectedState || city.state === selectedState.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-4xl space-y-8 rounded-lg bg-white p-11 shadow-md",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-8 flex flex-wrap items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "ghost",
				size: "sm",
				onClick: goBack,
				className: "-ml-3 mb-3 text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {}), " Leads"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-bold tracking-tight",
				children: leadId ? `Edit enquiry${leadQuery.data?.srNo ? ` #${leadQuery.data.srNo}` : ""}` : "New enquiry"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "outline",
				onClick: downloadLeadCsvTemplate,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), " Download template"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: (event) => {
				event.preventDefault();
				if (canSubmit) saveMutation.mutate(form);
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
					id: "contact-details-heading",
					title: "Contact details",
					description: "The company first, then the person we'll be speaking to.",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Group, {
							title: "Company",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Company name",
									required: true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											required: true,
											autoComplete: "organization",
											value: form.company_name,
											onFocus: () => setCompanySuggestionsOpen(true),
											onBlur: () => setTimeout(() => setCompanySuggestionsOpen(false), 150),
											onChange: (event) => {
												update("company_name", event.target.value);
												setCompanySearch(event.target.value);
												setCompanySuggestionsOpen(true);
												setSelectedCompanyId(null);
											},
											className: controlClass
										}), companySuggestionsOpen && companySuggestions.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "absolute z-20 mt-1.5 w-full rounded-lg border border-line bg-popover p-1 shadow-lg",
											children: companySuggestions.map((company) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => void fillCompanyFields(company),
												className: "flex w-full items-center justify-between rounded-md px-3 py-2 text-left text-sm transition-colors hover:bg-muted",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-medium",
													children: company.name
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs text-muted-foreground",
													children: company.city_name || company.state_name || "Company"
												})]
											}, company.id))
										})]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "GST number",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										value: form.company_gst_number,
										onChange: (event) => update("company_gst_number", event.target.value),
										className: controlClass
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex justify-end sm:col-span-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => void saveCompanyToMaster(),
										className: "inline-flex items-center rounded-md border border-brand/50 bg-brand/10 px-3 py-1.5 text-xs font-medium text-brand transition-colors hover:bg-brand/15 disabled:opacity-60",
										disabled: companyCreating || !form.company_name.trim(),
										children: companyCreating ? "Saving…" : selectedCompanyId ? "Update company" : "Add company"
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Group, {
							title: "Address",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Address",
									className: "sm:col-span-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										rows: 3,
										autoComplete: "street-address",
										value: form.company_address,
										onChange: (event) => update("company_address", event.target.value),
										className: `${controlClass} h-auto py-2`
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Country",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: form.company_country || "",
										onChange: (event) => {
											update("company_country", event.target.value);
											update("company_state", "");
											update("company_city", "");
										},
										className: controlClass,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											children: "Select country"
										}), countryOptions.map((country) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: country.name,
											children: country.name
										}, country.id))]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "State",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: form.company_state || "",
										onChange: (event) => {
											update("company_state", event.target.value);
											update("company_city", "");
										},
										className: controlClass,
										disabled: !selectedCountry,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											children: "Select state"
										}), filteredStates.map((state) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: state.name,
											children: state.name
										}, state.id))]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "City",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: form.company_city || "",
										onChange: (event) => update("company_city", event.target.value),
										className: controlClass,
										disabled: !selectedState,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											children: "Select city"
										}), filteredCities.map((city) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: city.name,
											children: city.name
										}, city.id))]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Pincode",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										inputMode: "numeric",
										autoComplete: "postal-code",
										value: form.company_pincode,
										onChange: (event) => update("company_pincode", event.target.value),
										className: controlClass
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Group, {
							title: "Contact person",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Name",
									required: true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										required: true,
										autoComplete: "name",
										value: form.contact_name,
										onChange: (event) => update("contact_name", event.target.value),
										className: controlClass
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Designation",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										autoComplete: "organization-title",
										value: form.contact_designation,
										onChange: (event) => update("contact_designation", event.target.value),
										className: controlClass
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Mobile",
									required: true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "tel",
										required: true,
										autoComplete: "tel",
										inputMode: "tel",
										value: form.contact_mobile,
										onChange: (event) => update("contact_mobile", event.target.value),
										className: controlClass
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Email",
									required: true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "email",
										required: true,
										autoComplete: "email",
										value: form.contact_email,
										onChange: (event) => update("contact_email", event.target.value),
										className: controlClass
									})
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
					id: "enquiry-heading",
					title: "Enquiry",
					description: "What came in, where from, and when to follow up.",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Group, {
						title: "Enquiry details",
						cols: 3,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Enquiry date",
								required: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "date",
									required: true,
									value: form.enquiry_date,
									onChange: (event) => update("enquiry_date", event.target.value),
									className: controlClass
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Source",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: form.source,
									onChange: (event) => update("source", event.target.value),
									className: controlClass,
									children: sourceOptions.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: option.value,
										children: option.label
									}, option.value))
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Status",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: form.status,
									onChange: (event) => update("status", event.target.value),
									className: controlClass,
									children: statusOptions.map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: status.value,
										children: status.label
									}, status.value))
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								"aria-pressed": form.is_opportunity,
								onClick: () => update("is_opportunity", !form.is_opportunity),
								className: `flex w-full items-start gap-3 rounded-md border p-3.5 text-left transition-colors sm:col-span-3 ${form.is_opportunity ? "border-brand bg-brand/10 text-foreground" : "border-line hover:bg-muted/40"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: `mt-0.5 size-5 shrink-0 ${form.is_opportunity ? "text-brand" : "text-muted-foreground"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "grid gap-0.5 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium",
										children: "Mark as opportunity"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-muted-foreground",
										children: "Use this once the enquiry looks like a real deal."
									})]
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Group, {
						title: "Follow-up",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "sm:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Follow-up date",
								error: followupError,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "date",
									min: form.enquiry_date,
									value: form.followup_date ?? "",
									"aria-invalid": Boolean(followupError),
									onChange: (event) => update("followup_date", event.target.value || null),
									className: `${controlClass} sm:max-w-56`
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 flex flex-wrap gap-2",
								children: FOLLOWUP_SHORTCUTS.map(({ label, days }) => {
									const value = daysFromToday(days);
									const active = form.followup_date === value;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-pressed": active,
										onClick: () => update("followup_date", active ? null : value),
										className: "h-7 rounded-full border px-3 text-xs transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand/40 " + (active ? "border-brand bg-brand/10 font-medium" : "border-input text-muted-foreground hover:border-foreground/30 hover:text-foreground"),
										children: label
									}, label);
								})
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Remarks",
							className: "sm:col-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								rows: 4,
								value: form.followup_remarks,
								placeholder: "What was discussed? What should the next call cover?",
								onChange: (event) => update("followup_remarks", event.target.value),
								className: `${controlClass} h-auto resize-y py-2 leading-relaxed`
							})
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sticky bottom-0 z-10 -mx-1 flex items-center justify-between gap-3 border-t border-line bg-background/95 px-1 py-4 backdrop-blur",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						"aria-live": "polite",
						children: isDirty ? "You have unsaved changes" : ""
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex w-full justify-end gap-2 sm:w-auto",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: goBack,
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "submit",
							disabled: !canSubmit,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, {}),
								" ",
								saveMutation.isPending ? "Saving…" : leadId ? "Save changes" : "Create lead"
							]
						})]
					})]
				})
			]
		})]
	});
}
//#endregion
export { LeadFormPage as component };
