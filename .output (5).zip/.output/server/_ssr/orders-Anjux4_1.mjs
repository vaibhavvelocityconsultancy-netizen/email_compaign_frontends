import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { b as Pencil, t as X, v as Plus } from "../_libs/lucide-react.mjs";
import { n as DataTable } from "./DataTable-DmCzJ7wu.mjs";
import { c as updateCompany, l as updateCompanyContact, n as createCompanyContact, o as listCountries, r as listCities, s as listStates } from "./company-api-BQqpN8GR.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Modal } from "./Modal-vFtVKTX9.mjs";
import { d as getSalesOrders, h as updateSalesOrder } from "./quotation-api-BHi0BtOe.mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as Route } from "./orders-S_62a-7r.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/orders-Anjux4_1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var money = (value) => new Intl.NumberFormat("en-IN", {
	style: "currency",
	currency: "INR",
	maximumFractionDigits: 2
}).format(value || 0);
function dateLabel(value) {
	if (!value) return "—";
	const date = /* @__PURE__ */ new Date(`${value.slice(0, 10)}T00:00:00`);
	return Number.isNaN(date.getTime()) ? value : new Intl.DateTimeFormat("en-GB").format(date);
}
function DocumentLinks({ order }) {
	const documents = [
		["Quotation", order.quotationPdf],
		["FO", order.finalOfferPdf],
		["CPO", order.cpoDocument],
		["SO", order.soPdf]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap gap-x-2 gap-y-1 text-xs",
		children: documents.map(([label, url]) => url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: url,
			target: "_blank",
			rel: "noreferrer",
			className: "font-medium text-primary underline-offset-2 hover:underline",
			children: label
		}, label) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-muted-foreground",
			title: `${label} document unavailable`,
			children: [label, " —"]
		}, label))
	});
}
function SalesOrdersPage() {
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { soId } = Route.useSearch();
	const salesOrdersQuery = useQuery({
		queryKey: ["sales-orders"],
		queryFn: getSalesOrders
	});
	const salesOrders = salesOrdersQuery.data ?? [];
	const selectedOrder = salesOrders.find((order) => order.id === soId);
	const closeDialog = () => navigate({
		to: "/sales/orders",
		search: {}
	});
	const columns = (0, import_react.useMemo)(() => [
		{
			key: "companyName",
			header: "Customer / Company",
			cell: (order) => order.companyName || "—",
			filterValue: (order) => order.companyName
		},
		{
			key: "soNumber",
			header: "Sales order",
			cell: (order) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-xs",
				children: order.soNumber
			}),
			filterValue: (order) => order.soNumber
		},
		{
			key: "soDate",
			header: "SO date",
			filterType: "date",
			cell: (order) => dateLabel(order.soDate),
			filterValue: (order) => order.soDate
		},
		{
			key: "totalAmount",
			header: "Total",
			filterable: false,
			cell: (order) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium",
				children: money(order.totalAmount)
			})
		},
		{
			key: "status",
			header: "Status",
			cell: (order) => order.status.replaceAll("_", " "),
			filterValue: (order) => order.status
		},
		{
			key: "documents",
			header: "Docs",
			sortable: false,
			filterable: false,
			cell: (order) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentLinks, { order })
		},
		{
			key: "actions",
			header: "Actions",
			sortable: false,
			filterable: false,
			cell: (order) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				size: "sm",
				variant: "outline",
				onClick: () => navigate({
					to: "/sales/orders",
					search: { soId: order.id }
				}),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "mr-1 size-3.5" }), "Edit"]
			})
		}
	], [navigate]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-mono text-[11px] tracking-wide text-muted-foreground",
					children: "ORDER FLOW"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-3xl font-bold tracking-tight",
					children: "Sales Orders"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Sales orders created from customer purchase order quotations."
				})
			] }),
			salesOrdersQuery.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "text-sm text-destructive",
				children: salesOrdersQuery.error.message || "Could not load sales orders."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				data: salesOrders,
				columns,
				searchKeys: [
					"soNumber",
					"quotationNumber",
					"companyName"
				],
				searchPlaceholder: "Search sales orders, quotations, or companies",
				storageKey: "sales-orders",
				emptyMessage: salesOrdersQuery.isLoading ? "Loading sales orders…" : "No sales orders created yet."
			}),
			selectedOrder && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SalesOrderEditDialog, {
				open: true,
				order: selectedOrder,
				onClose: closeDialog,
				onSaved: async () => {
					await queryClient.invalidateQueries({ queryKey: ["sales-orders"] });
					closeDialog();
				}
			}, selectedOrder.id)
		]
	});
}
function SalesOrderEditDialog({ open, order, onClose, onSaved }) {
	const countriesQuery = useQuery({
		queryKey: ["countries"],
		queryFn: listCountries,
		enabled: open
	});
	const statesQuery = useQuery({
		queryKey: ["states"],
		queryFn: listStates,
		enabled: open
	});
	const citiesQuery = useQuery({
		queryKey: ["cities"],
		queryFn: listCities,
		enabled: open
	});
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [country, setCountry] = (0, import_react.useState)("");
	const [state, setState] = (0, import_react.useState)("");
	const [city, setCity] = (0, import_react.useState)("");
	const [contacts, setContacts] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setError("");
		setCountry(order.companyCountryId == null ? "" : String(order.companyCountryId));
		setState(order.companyStateId == null ? "" : String(order.companyStateId));
		setCity(order.companyCityId == null ? "" : String(order.companyCityId));
		setContacts(order.companyContacts.map((contact) => ({
			...contact,
			key: String(contact.id)
		})));
	}, [open, order]);
	const filteredStates = (statesQuery.data ?? []).filter((option) => !country || option.country === Number(country));
	const filteredCities = (citiesQuery.data ?? []).filter((option) => !state || option.state === Number(state));
	const locationsLoading = countriesQuery.isLoading || statesQuery.isLoading || citiesQuery.isLoading;
	function updateContact(index, field, value) {
		setContacts((current) => current.map((contact, contactIndex) => contactIndex === index ? {
			...contact,
			[field]: value
		} : contact));
	}
	async function handleSubmit(event) {
		event.preventDefault();
		if (!order.companyId) {
			setError("This sales order has no linked company.");
			return;
		}
		const data = new FormData(event.currentTarget);
		const companyName = String(data.get("company_name") ?? "").trim();
		if (!companyName) {
			setError("Company name is required.");
			return;
		}
		if (contacts.some((contact) => !contact.name.trim())) {
			setError("Every contact needs a name.");
			return;
		}
		setSaving(true);
		setError("");
		try {
			await updateCompany(order.companyId, {
				name: companyName,
				address: String(data.get("company_address") ?? "").trim(),
				city: city ? Number(city) : null,
				state: state ? Number(state) : null,
				country: country ? Number(country) : null,
				pincode: String(data.get("company_pincode") ?? "").trim(),
				gst_number: String(data.get("company_gst_number") ?? "").trim()
			});
			for (const contact of contacts) {
				const contactData = {
					name: contact.name.trim(),
					designation: contact.designation.trim(),
					phone: contact.phone.trim(),
					email: contact.email.trim(),
					is_primary: contact.is_primary
				};
				if (contact.id) await updateCompanyContact(order.companyId, contact.id, contactData);
				else await createCompanyContact(order.companyId, contactData);
			}
			await updateSalesOrder(order.id, {
				so_number: String(data.get("so_number") ?? "").trim(),
				so_date: String(data.get("so_date") ?? ""),
				payment_terms: String(data.get("payment_terms") ?? "").trim(),
				delivery_terms: String(data.get("delivery_terms") ?? "").trim(),
				remarks: String(data.get("remarks") ?? "").trim(),
				status: String(data.get("status") ?? order.status)
			});
			await onSaved();
			toast.success("Sales order and shared company details updated.");
		} catch (saveError) {
			const message = saveError instanceof Error ? saveError.message : "Could not update sales order.";
			setError(message);
			toast.error(message);
		} finally {
			setSaving(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onClose,
		title: "Edit Sales Order",
		eyebrow: order.soNumber,
		wide: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: handleSubmit,
			className: "max-h-[80vh] space-y-5 overflow-y-auto p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "font-semibold",
						children: "Company details"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm sm:col-span-2",
								children: ["Company name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									name: "company_name",
									defaultValue: order.companyName,
									required: true
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm sm:col-span-2",
								children: ["Address", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									name: "company_address",
									defaultValue: order.companyAddress
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm",
								children: ["Country", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "h-9 w-full rounded-md border border-input bg-background px-3 text-sm",
									value: country,
									disabled: locationsLoading,
									onChange: (event) => {
										setCountry(event.target.value);
										setState("");
										setCity("");
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Select country"
									}), (countriesQuery.data ?? []).map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: option.id,
										children: option.name
									}, option.id))]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm",
								children: ["State", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "h-9 w-full rounded-md border border-input bg-background px-3 text-sm",
									value: state,
									disabled: locationsLoading,
									onChange: (event) => {
										setState(event.target.value);
										setCity("");
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Select state"
									}), filteredStates.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: option.id,
										children: option.name
									}, option.id))]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm",
								children: ["City", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "h-9 w-full rounded-md border border-input bg-background px-3 text-sm",
									value: city,
									disabled: locationsLoading,
									onChange: (event) => setCity(event.target.value),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Select city"
									}), filteredCities.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: option.id,
										children: option.name
									}, option.id))]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm",
								children: ["Pincode", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									name: "company_pincode",
									defaultValue: order.companyPincode
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm sm:col-span-2",
								children: ["GST number", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									name: "company_gst_number",
									defaultValue: order.companyGstNumber
								})]
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-3 border-t border-line pt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "font-semibold",
							children: "Company contacts"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							size: "sm",
							variant: "outline",
							onClick: () => setContacts((current) => [...current, {
								key: `new-${Date.now()}`,
								name: "",
								designation: "",
								phone: "",
								email: "",
								is_primary: false
							}]),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-1 size-4" }), " Add Contact"]
						})]
					}), contacts.map((contact, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 rounded-md border border-line p-3 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								"aria-label": "Contact name",
								placeholder: "Name",
								value: contact.name,
								onChange: (event) => updateContact(index, "name", event.target.value),
								required: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								"aria-label": "Designation",
								placeholder: "Designation",
								value: contact.designation,
								onChange: (event) => updateContact(index, "designation", event.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								"aria-label": "Contact email",
								type: "email",
								placeholder: "Email",
								value: contact.email,
								onChange: (event) => updateContact(index, "email", event.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								"aria-label": "Contact phone",
								type: "tel",
								placeholder: "Phone",
								value: contact.phone,
								onChange: (event) => updateContact(index, "phone", event.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: contact.is_primary,
									onChange: (event) => updateContact(index, "is_primary", event.target.checked)
								}), "Primary contact"]
							}),
							!contact.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "Remove new contact",
								className: "justify-self-end text-muted-foreground hover:text-destructive",
								onClick: () => setContacts((current) => current.filter((item) => item.key !== contact.key)),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
							})
						]
					}, contact.key))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-3 border-t border-line pt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "font-semibold",
						children: "Sales order"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm",
								children: ["SO number", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									name: "so_number",
									defaultValue: order.soNumber,
									required: true
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm",
								children: ["SO date", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									name: "so_date",
									type: "date",
									defaultValue: order.soDate,
									required: true
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm",
								children: ["Quotation", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: order.quotationNumber,
									readOnly: true
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm",
								children: ["Project", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: order.projectName,
									readOnly: true
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm",
								children: ["Created by", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: order.createdByName,
									readOnly: true
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm",
								children: ["Status", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									name: "status",
									defaultValue: order.status,
									className: "h-9 w-full rounded-md border border-input bg-background px-3 text-sm",
									children: [
										"DRAFT",
										"CONFIRMED",
										"IN_PROGRESS",
										"COMPLETED",
										"CANCELLED"
									].map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: status,
										children: status.replaceAll("_", " ")
									}, status))
								})]
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-2 border-t border-line pt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "font-semibold",
						children: "Documents"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentLinks, { order })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-3 border-t border-line pt-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "font-semibold",
							children: "Line items"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-x-auto rounded-md border border-line",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full min-w-[640px] border-collapse text-left text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
									className: "border-b border-line bg-muted/30 text-xs text-muted-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2",
											children: "#"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2",
											children: "Module"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2",
											children: "Description"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2",
											children: "Requirements"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2 text-right",
											children: "Amount"
										})
									] })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
									className: "divide-y divide-line",
									children: [order.items.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-3",
											children: index + 1
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-3 font-medium",
											children: item.moduleName || "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "max-w-64 whitespace-pre-wrap px-3 py-3",
											children: item.description || "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "max-w-64 whitespace-pre-wrap px-3 py-3",
											children: item.requirements || "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-3 text-right",
											children: money(item.amount)
										})
									] }, item.id ?? `${item.moduleName}-${index}`)), !order.items.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										colSpan: 5,
										className: "px-3 py-8 text-center text-muted-foreground",
										children: "No line items on the source quotation."
									}) })]
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap justify-end gap-5 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Subtotal: ", money(order.subtotal)] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Discount: ", money(order.discountAmount)] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Tax: ", money(order.taxAmount)] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: ["Total: ", money(order.totalAmount)] })
							]
						})
					]
				}),
				error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "alert",
					className: "text-sm text-destructive",
					children: error
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-end gap-2 border-t border-line pt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						onClick: onClose,
						disabled: saving,
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: saving,
						children: saving ? "Saving…" : "Update SO"
					})]
				})
			]
		})
	});
}
//#endregion
export { SalesOrdersPage as component };
