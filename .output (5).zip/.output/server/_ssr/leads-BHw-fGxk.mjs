import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { F as updateLeadStatus, T as importLeads, l as deleteLead, y as getLeads } from "./api-W8TaUl4r.mjs";
import { $ as ChevronDown, b as Pencil, i as Upload, s as Trash2, v as Plus, z as Download } from "../_libs/lucide-react.mjs";
import { n as DataTable } from "./DataTable-DmCzJ7wu.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Modal } from "./Modal-vFtVKTX9.mjs";
import { g as Outlet, p as useRouterState, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as ConfirmDialog } from "./ConfirmDialog-Rjd0NwWp.mjs";
import { t as StatusBadge } from "./StatusBadge-BMe1mW6r.mjs";
import { t as downloadLeadCsvTemplate } from "./lead-csv-template-DukjP975.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/leads-BHw-fGxk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LeadsRouteView() {
	return useRouterState({ select: (state) => state.location.pathname === "/marketing/leads/form" }) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeadsPage, {});
}
var LEAD_SOURCES = [
	["WEBSITE", "Website"],
	["SOCIAL_MEDIA", "Social Media"],
	["GOOGLE", "Google Search"],
	["ADVERTISEMENT", "Advertisement"],
	["REFERENCE", "Reference"],
	["EXISTING_CLIENT", "Existing Client"],
	["COLD_CALL", "Cold Call"],
	["EMAIL_MARKETING", "Email Marketing"],
	["OTHER", "Other"]
];
var LEAD_STATUSES = [
	"NEW",
	"ACTIVE",
	"JUNK",
	"HOT",
	"COLD",
	"OTHER"
];
var selectCls = "h-9 rounded-lg border border-line bg-surface px-3 text-sm focus:border-brand focus:ring-2 focus:ring-brand/20 focus:outline-none";
function displayedLeadStatus(lead) {
	return lead.unsubscribed ? "unsubscribed" : lead.status;
}
function statusLabel(value) {
	return value ? value[0].toUpperCase() + value.slice(1).toLowerCase() : "";
}
function StatusSelect({ value, onChange, disabled, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `relative inline-flex items-center gap-1 rounded-full focus-within:ring-2 focus-within:ring-brand/30 ${disabled ? "opacity-60" : ""}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: statusLabel(value) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "pointer-events-none size-3.5 text-muted-foreground" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				"aria-label": label,
				value,
				disabled,
				onChange: (event) => onChange(event.target.value),
				className: "absolute inset-0 h-full w-full cursor-pointer opacity-0 disabled:cursor-not-allowed",
				children: [LEAD_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: s.toLowerCase(),
					children: statusLabel(s)
				}, s)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: "unsubscribed",
					children: "Unsubscribed"
				})]
			})
		]
	});
}
function LeadsPage() {
	const qc = useQueryClient();
	const navigate = useNavigate();
	const { data, isLoading } = useQuery({
		queryKey: ["leads"],
		queryFn: getLeads
	});
	const [status, setStatus] = (0, import_react.useState)("all");
	const [source, setSource] = (0, import_react.useState)("all");
	const [importOpen, setImportOpen] = (0, import_react.useState)(false);
	const [file, setFile] = (0, import_react.useState)(null);
	const [deleteTarget, setDeleteTarget] = (0, import_react.useState)(null);
	const updateStatusMut = useMutation({
		mutationFn: ({ lead, nextStatus }) => updateLeadStatus(lead.id, nextStatus),
		onSuccess: (updatedLead) => {
			qc.setQueryData(["leads"], (current) => current?.map((lead) => lead.id === updatedLead.id ? updatedLead : lead));
			toast.success("Lead status updated");
		},
		onError: (error) => {
			qc.invalidateQueries({ queryKey: ["leads"] });
			toast.error(error.message || "Unable to update lead status");
		}
	});
	const sources = (0, import_react.useMemo)(() => Array.from(new Set((data ?? []).map((l) => l.source))), [data]);
	const filtered = (0, import_react.useMemo)(() => (data ?? []).filter((lead) => (status === "all" || displayedLeadStatus(lead) === status) && (source === "all" || lead.source === source)), [
		data,
		status,
		source
	]);
	const importMut = useMutation({
		mutationFn: (f) => importLeads(f),
		onSuccess: (res) => {
			qc.invalidateQueries({ queryKey: ["leads"] });
			setImportOpen(false);
			setFile(null);
			const summary = `Imported ${res.imported} of ${res.total_rows} rows (${res.duplicates} duplicates, ${res.invalid} invalid)`;
			const firstError = res.row_errors?.[0];
			if (firstError) {
				const details = Object.entries(firstError.errors).map(([field, messages]) => `${field}: ${messages.join(", ")}`).join("; ");
				toast.error(`${summary}. Row ${firstError.row}: ${details}`);
			} else toast.success(summary);
		},
		onError: (e) => toast.error(e.message || "Import failed")
	});
	const deleteLeadMut = useMutation({
		mutationFn: (lead) => deleteLead(lead.id),
		onSuccess: () => {
			qc.invalidateQueries({ queryKey: ["leads"] });
			setDeleteTarget(null);
			toast.success("Lead removed");
		},
		onError: (e) => toast.error(e.message || "Unable to remove lead")
	});
	const openCreate = () => navigate({
		to: "/marketing/leads/form",
		search: { leadId: void 0 }
	});
	const columns = (0, import_react.useMemo)(() => [
		{
			key: "companyName",
			header: "Company",
			filterValue: (lead) => lead.companyName,
			cell: (lead) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium",
				children: lead.companyName || "—"
			})
		},
		{
			key: "contactName",
			header: "Contact",
			filterValue: (lead) => lead.contactName,
			cell: (lead) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: lead.contactName || "—" }), lead.contactMobile && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-mono text-[11px] text-muted-foreground",
				children: lead.contactMobile
			})] })
		},
		{
			key: "enquiryDate",
			header: "Enquiry date",
			filterType: "date",
			filterValue: (lead) => lead.enquiryDate,
			cell: (lead) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "whitespace-nowrap font-mono text-[11px] text-muted-foreground",
				children: (/* @__PURE__ */ new Date(`${lead.enquiryDate}T00:00:00`)).toLocaleDateString()
			})
		},
		{
			key: "source",
			header: "Source",
			filterValue: (lead) => lead.source,
			cell: (lead) => LEAD_SOURCES.find(([value]) => value === lead.source)?.[1] ?? lead.source
		},
		{
			key: "status",
			header: "Status",
			filterValue: displayedLeadStatus,
			cell: (lead) => lead.unsubscribed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: "Unsubscribed" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusSelect, {
				value: lead.status,
				disabled: updateStatusMut.isPending,
				label: `Change status for ${lead.contactName || lead.companyName}`,
				onChange: (nextStatus) => updateStatusMut.mutate({
					lead,
					nextStatus
				})
			})
		},
		{
			key: "followupDate",
			header: "Follow-up",
			filterType: "date",
			filterValue: (lead) => lead.followupDate,
			cell: (lead) => lead.followupDate ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "whitespace-nowrap font-mono text-[11px] text-muted-foreground",
				children: (/* @__PURE__ */ new Date(`${lead.followupDate}T00:00:00`)).toLocaleDateString()
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground",
				children: "—"
			})
		},
		{
			key: "actions",
			header: "Actions",
			filterable: false,
			sortable: false,
			className: "w-24 text-right",
			headerClassName: "text-right",
			cell: (lead) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-end gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => navigate({
						to: "/marketing/leads/form",
						search: { leadId: lead.id }
					}),
					className: "grid size-8 place-items-center rounded-md text-muted-foreground transition-colors hover:bg-background hover:text-foreground",
					"aria-label": `Edit enquiry ${lead.srNo}`,
					title: "Edit lead",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setDeleteTarget(lead),
					className: "grid size-8 place-items-center rounded-md text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive",
					"aria-label": `Remove enquiry ${lead.srNo}`,
					title: "Remove lead",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
				})]
			})
		}
	], [navigate, updateStatusMut]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rise flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-mono text-[11px] tracking-wide text-muted-foreground",
					children: "AUDIENCE"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-3xl font-bold tracking-tight",
					children: "Leads"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: downloadLeadCsvTemplate,
							className: "flex h-9 items-center gap-1.5 rounded-lg border border-line bg-surface px-4 text-sm font-medium transition-colors hover:bg-background",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), " Download template"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => navigate({
								to: "/tasks/form",
								search: {
									taskId: void 0,
									module: "LEAD",
									companyId: void 0,
									referenceId: void 0
								}
							}),
							className: "flex h-9 items-center gap-1.5 rounded-lg border border-line bg-surface px-4 text-sm font-medium transition-colors hover:bg-background",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " New Task"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: openCreate,
							className: "flex h-9 items-center gap-1.5 rounded-lg bg-brand px-4 text-sm font-medium text-white transition-colors hover:bg-brand/90",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " Add lead"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setImportOpen(true),
							className: "flex h-9 items-center gap-1.5 rounded-lg border border-line bg-surface px-4 text-sm font-medium transition-colors hover:bg-background",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }), " Import Leads"]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rise",
				style: { animationDelay: "80ms" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
					data: filtered,
					columns,
					searchKeys: [
						"id",
						"companyName",
						"contactName",
						"contactMobile",
						"followupRemarks"
					],
					searchPlaceholder: "Search enquiries...",
					pageSize: 12,
					storageKey: "leads",
					emptyMessage: isLoading ? "Loading enquiries…" : "No enquiries match your filters.",
					toolbarActions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						"aria-label": "Filter by status",
						value: status,
						onChange: (event) => setStatus(event.target.value),
						className: selectCls,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "All statuses"
						}), LEAD_STATUSES.map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: value.toLowerCase(),
							children: statusLabel(value)
						}, value))]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						"aria-label": "Filter by source",
						value: source,
						onChange: (event) => setSource(event.target.value),
						className: selectCls,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "All sources"
						}), sources.map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value,
							children: LEAD_SOURCES.find(([code]) => code === value)?.[1] ?? value
						}, value))]
					})] })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
				open: importOpen,
				onClose: () => setImportOpen(false),
				title: "Upload Leads",
				eyebrow: "IMPORT LEADS",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3 p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Missing columns or values are allowed. Blank dates stay empty, while source and status default to Other and enquiry type defaults to Lead. Unrecognized source or status values also default to Other."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex cursor-pointer flex-col items-center justify-center rounded-xl border border-dashed border-line bg-background px-4 py-8 text-center transition-colors hover:border-brand",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-5 text-muted-foreground" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-2 text-sm font-medium",
								children: file ? file.name : "Choose File"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 font-mono text-[11px] text-muted-foreground",
								children: "CSV, XLS, or XLSX up to 5 MB"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								accept: ".csv,.xls,.xlsx,text/csv,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
								className: "hidden",
								onChange: (e) => setFile(e.target.files?.[0] ?? null)
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-end gap-2 border-t border-line bg-background/50 px-5 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setImportOpen(false),
						className: "h-9 rounded-lg border border-line bg-surface px-4 text-sm transition-colors hover:bg-background",
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						disabled: !file || importMut.isPending,
						onClick: () => file && importMut.mutate(file),
						className: "h-9 rounded-lg bg-brand px-5 text-sm font-medium text-white transition-colors hover:bg-brand/90 disabled:opacity-50",
						children: importMut.isPending ? "Importing…" : "Import"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: Boolean(deleteTarget),
				onClose: () => setDeleteTarget(null),
				onConfirm: () => deleteTarget && deleteLeadMut.mutate(deleteTarget),
				title: "Remove lead?",
				message: `Remove enquiry #${deleteTarget?.srNo ?? ""} from the active leads list? Existing campaign history will be preserved.`,
				loading: deleteLeadMut.isPending
			})
		]
	});
}
//#endregion
export { LeadsRouteView as component };
