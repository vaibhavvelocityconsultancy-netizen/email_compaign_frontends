import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/leads.form-gmPFjeqN.js
var $$splitComponentImporter = () => import("./leads.form-Cxj3Js6z.mjs");
var Route = createFileRoute("/marketing/leads/form")({
	validateSearch: (search) => ({ leadId: typeof search.leadId === "string" ? search.leadId : void 0 }),
	head: () => ({ meta: [{ title: "Lead Form — Vantage CRM" }, {
		name: "description",
		content: "Create or update an enquiry."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
