import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/location-nNtIVYrf.js
var TABS = [
	"country",
	"state",
	"city"
];
var $$splitComponentImporter = () => import("./location-B_HZn8_F.mjs");
var Route = createFileRoute("/location")({
	validateSearch: (search) => ({ tab: TABS.includes(search.tab) ? search.tab : "country" }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { TABS as n, Route as t };
