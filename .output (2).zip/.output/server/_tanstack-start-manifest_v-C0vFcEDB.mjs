//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C0vFcEDB.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/__root.tsx",
		children: [
			"/",
			"/access-control",
			"/company",
			"/country",
			"/customer-po",
			"/final-offer",
			"/location",
			"/login",
			"/marketing",
			"/order-dashboard",
			"/register",
			"/roles",
			"/tasks",
			"/user",
			"/sales/opportunities",
			"/sales/orders",
			"/sales/quotations",
			"/sales/"
		],
		preloads: [
			"/vc_email_crm/assets/index-4r8JI-vy.js",
			"/vc_email_crm/assets/jsx-runtime-OQpaS_Dv.js",
			"/vc_email_crm/assets/react-dom-Ch54GZ4s.js",
			"/vc_email_crm/assets/Match-5cQgR4sj.js",
			"/vc_email_crm/assets/preload-helper-C-BKGnPd.js",
			"/vc_email_crm/assets/utils-DCvbpOtd.js",
			"/vc_email_crm/assets/link-CAl-Sa9v.js",
			"/vc_email_crm/assets/useMatch-BaG-rLLV.js",
			"/vc_email_crm/assets/matchContext-BLd14XSO.js",
			"/vc_email_crm/assets/useSelector-yWwUHw1M.js",
			"/vc_email_crm/assets/useRouter-FQeUpUVO.js",
			"/vc_email_crm/assets/useNavigate-bMnaDzZT.js",
			"/vc_email_crm/assets/useQuery-CRu0Hu6y.js",
			"/vc_email_crm/assets/useMutation-BT3iAFGa.js",
			"/vc_email_crm/assets/createLucideIcon-5JRSLlvH.js",
			"/vc_email_crm/assets/DataTable-DGJqtzCb.js",
			"/vc_email_crm/assets/x-DFhNn4Ci.js",
			"/vc_email_crm/assets/button-D0UaAm5H.js",
			"/vc_email_crm/assets/input-DoHRrl0J.js",
			"/vc_email_crm/assets/dist-DYAUkNtW.js",
			"/vc_email_crm/assets/api-B-lsE1jr.js",
			"/vc_email_crm/assets/Modal-BZsGyKA9.js",
			"/vc_email_crm/assets/types-CTeloYrU.js",
			"/vc_email_crm/assets/quotation-api-CVDNE5JW.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/vc_email_crm/assets/index-4r8JI-vy.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/routes-ha8ouaul.js",
			"/vc_email_crm/assets/arrow-up-right-Dv0z1hcs.js",
			"/vc_email_crm/assets/StatCard-Ef07sW3W.js"
		]
	},
	"/company": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/company.tsx",
		children: void 0,
		preloads: ["/vc_email_crm/assets/company-NtnetrK2.js", "/vc_email_crm/assets/company-api-BUI6MFYq.js"]
	},
	"/country": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/country.tsx",
		children: void 0,
		preloads: ["/vc_email_crm/assets/country-C4DJTpz-.js"]
	},
	"/customer-po": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/customer-po.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/customer-po-CIHviUa-.js",
			"/vc_email_crm/assets/file-text-CLhUqrtI.js",
			"/vc_email_crm/assets/shopping-cart-DWwt8raz.js",
			"/vc_email_crm/assets/upload-CDjpU4YU.js"
		]
	},
	"/final-offer": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/final-offer.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/final-offer-C5MsEj-c.js",
			"/vc_email_crm/assets/file-text-CLhUqrtI.js",
			"/vc_email_crm/assets/drawer-DhfOT8D-.js"
		]
	},
	"/location": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/location.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/location-CM1TU1Ng.js",
			"/vc_email_crm/assets/EntityForm-DyxcBOUq.js",
			"/vc_email_crm/assets/tabs-SLTvcZTC.js"
		]
	},
	"/login": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/login.tsx",
		children: void 0,
		preloads: ["/vc_email_crm/assets/login-DU8SXa-y.js", "/vc_email_crm/assets/AuthLayout-BWJFpEXd.js"]
	},
	"/marketing": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/marketing.tsx",
		children: ["/marketing/email-campaign", "/marketing/leads"],
		preloads: [
			"/vc_email_crm/assets/marketing-DGMMVoLS.js",
			"/vc_email_crm/assets/EmptyState-DDcb9rny.js",
			"/vc_email_crm/assets/StatCard-Ef07sW3W.js",
			"/vc_email_crm/assets/StatusBadge-CxXEaw6p.js"
		]
	},
	"/order-dashboard": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/order-dashboard.tsx",
		children: void 0,
		preloads: ["/vc_email_crm/assets/order-dashboard-DCrIXRRg.js"]
	},
	"/register": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/register.tsx",
		children: void 0,
		preloads: ["/vc_email_crm/assets/register-BmpliEPP.js", "/vc_email_crm/assets/AuthLayout-BWJFpEXd.js"]
	},
	"/tasks": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/tasks.tsx",
		children: [
			"/tasks/dashboard",
			"/tasks/form",
			"/tasks/"
		],
		preloads: ["/vc_email_crm/assets/tasks-OfWf9uOh.js"]
	},
	"/marketing/email-campaign": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/marketing/email-campaign.tsx",
		children: [
			"/marketing/email-campaign/campaigns",
			"/marketing/email-campaign/logs",
			"/marketing/email-campaign/sequences",
			"/marketing/email-campaign/templates",
			"/marketing/email-campaign/"
		],
		preloads: ["/vc_email_crm/assets/email-campaign-Y2LS2j8f.js"]
	},
	"/marketing/leads": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/marketing/leads.tsx",
		children: ["/marketing/leads/form"],
		preloads: ["/vc_email_crm/assets/leads-e5v3-kwb.js", "/vc_email_crm/assets/upload-CDjpU4YU.js"]
	},
	"/sales/opportunities": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/sales/opportunities.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/opportunities-nhQL2RcX.js",
			"/vc_email_crm/assets/EntityForm-DyxcBOUq.js",
			"/vc_email_crm/assets/file-text-CLhUqrtI.js",
			"/vc_email_crm/assets/company-api-BUI6MFYq.js",
			"/vc_email_crm/assets/drawer-DhfOT8D-.js",
			"/vc_email_crm/assets/StatusBadge-CxXEaw6p.js"
		]
	},
	"/sales/orders": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/sales/orders.tsx",
		children: void 0,
		preloads: ["/vc_email_crm/assets/orders-C_V2S3JZ.js", "/vc_email_crm/assets/company-api-BUI6MFYq.js"]
	},
	"/sales/quotations": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/sales/quotations.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/quotations-Jiedvc-4.js",
			"/vc_email_crm/assets/EntityForm-DyxcBOUq.js",
			"/vc_email_crm/assets/company-api-BUI6MFYq.js",
			"/vc_email_crm/assets/drawer-DhfOT8D-.js",
			"/vc_email_crm/assets/StatusBadge-CxXEaw6p.js"
		]
	},
	"/tasks/dashboard": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/tasks/dashboard.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/dashboard-8UVqx6ob.js",
			"/vc_email_crm/assets/calendar-days-5GeYs19G.js",
			"/vc_email_crm/assets/target-BOizoJuW.js",
			"/vc_email_crm/assets/triangle-alert-DsgdhYG4.js"
		]
	},
	"/tasks/form": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/tasks/form.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/form-emmkNd0j.js",
			"/vc_email_crm/assets/save-CK_SGmB_.js",
			"/vc_email_crm/assets/eye-4pwqTTee.js",
			"/vc_email_crm/assets/textarea-CY-dYm-r.js"
		]
	},
	"/sales/": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/sales/index.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/sales-DLPnmiQo.js",
			"/vc_email_crm/assets/arrow-up-right-Dv0z1hcs.js",
			"/vc_email_crm/assets/file-text-CLhUqrtI.js",
			"/vc_email_crm/assets/shopping-cart-DWwt8raz.js",
			"/vc_email_crm/assets/target-BOizoJuW.js"
		]
	},
	"/marketing/email-campaign/campaigns": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/marketing/email-campaign.campaigns.tsx",
		children: void 0,
		preloads: ["/vc_email_crm/assets/email-campaign.campaigns-D32Yfxqx.js", "/vc_email_crm/assets/eye-4pwqTTee.js"]
	},
	"/marketing/email-campaign/logs": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/marketing/email-campaign.logs.tsx",
		children: void 0,
		preloads: ["/vc_email_crm/assets/email-campaign.logs-DVLps41u.js"]
	},
	"/marketing/email-campaign/sequences": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/marketing/email-campaign.sequences.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/email-campaign.sequences-CB7xDKku.js",
			"/vc_email_crm/assets/EntityForm-DyxcBOUq.js",
			"/vc_email_crm/assets/triangle-alert-DsgdhYG4.js"
		]
	},
	"/marketing/email-campaign/templates": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/marketing/email-campaign.templates.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/email-campaign.templates-Bi5HEj8R.js",
			"/vc_email_crm/assets/EntityForm-DyxcBOUq.js",
			"/vc_email_crm/assets/tabs-SLTvcZTC.js"
		]
	},
	"/marketing/leads/form": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/marketing/leads.form.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/leads.form-J5jsHbOV.js",
			"/vc_email_crm/assets/save-CK_SGmB_.js",
			"/vc_email_crm/assets/target-BOizoJuW.js",
			"/vc_email_crm/assets/company-api-BUI6MFYq.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
