import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as buttonVariants, r as cn, t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { $ as Check, B as Columns3, E as ListFilter, J as ChevronsLeft, Q as ChevronDown, X as ChevronRight, Y as ChevronUp, Z as ChevronLeft, at as ArrowUp, lt as ArrowDown, nt as CalendarDays, p as Search, q as ChevronsRight, t as X } from "../_libs/lucide-react.mjs";
import { n as getDefaultClassNames, t as DayPicker } from "../_libs/react-day-picker.mjs";
import { n as CheckboxIndicator, t as Checkbox$1 } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { i as Trigger, n as Portal, r as Root2, t as Content2 } from "../_libs/radix-ui__react-popover.mjs";
import { a as Viewport, i as ScrollAreaThumb, n as Root, r as ScrollAreaScrollbar, t as Corner } from "../_libs/radix-ui__react-scroll-area.mjs";
import { a as SelectItemIndicator, c as SelectPortal, d as SelectSeparator$1, f as SelectTrigger$1, i as SelectItem$1, l as SelectScrollDownButton$1, m as SelectViewport, n as SelectContent$1, o as SelectItemText, p as SelectValue$1, r as SelectIcon, s as SelectLabel$1, t as Select$1, u as SelectScrollUpButton$1 } from "../_libs/@radix-ui/react-select+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/DataTable-DmCzJ7wu.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Calendar({ className, classNames, showOutsideDays = true, captionLayout = "label", buttonVariant = "ghost", formatters, components, ...props }) {
	const defaultClassNames = getDefaultClassNames();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DayPicker, {
		showOutsideDays,
		className: cn("bg-background group/calendar p-3 [--cell-size:2rem] [[data-slot=card-content]_&]:bg-transparent [[data-slot=popover-content]_&]:bg-transparent", String.raw`rtl:**:[.rdp-button\_next>svg]:rotate-180`, String.raw`rtl:**:[.rdp-button\_previous>svg]:rotate-180`, className),
		captionLayout,
		formatters: {
			formatMonthDropdown: (date) => date.toLocaleString("default", { month: "short" }),
			...formatters
		},
		classNames: {
			root: cn("w-fit", defaultClassNames.root),
			months: cn("relative flex flex-col gap-4 md:flex-row", defaultClassNames.months),
			month: cn("flex w-full flex-col gap-4", defaultClassNames.month),
			nav: cn("absolute inset-x-0 top-0 flex w-full items-center justify-between gap-1", defaultClassNames.nav),
			button_previous: cn(buttonVariants({ variant: buttonVariant }), "h-(--cell-size) w-(--cell-size) select-none p-0 aria-disabled:opacity-50", defaultClassNames.button_previous),
			button_next: cn(buttonVariants({ variant: buttonVariant }), "h-(--cell-size) w-(--cell-size) select-none p-0 aria-disabled:opacity-50", defaultClassNames.button_next),
			month_caption: cn("flex h-(--cell-size) w-full items-center justify-center px-(--cell-size)", defaultClassNames.month_caption),
			dropdowns: cn("flex h-(--cell-size) w-full items-center justify-center gap-1.5 text-sm font-medium", defaultClassNames.dropdowns),
			dropdown_root: cn("has-focus:border-ring border-input shadow-xs has-focus:ring-ring/50 has-focus:ring-[3px] relative rounded-md border", defaultClassNames.dropdown_root),
			dropdown: cn("bg-popover absolute inset-0 opacity-0", defaultClassNames.dropdown),
			caption_label: cn("select-none font-medium", captionLayout === "label" ? "text-sm" : "[&>svg]:text-muted-foreground flex h-8 items-center gap-1 rounded-md pl-2 pr-1 text-sm [&>svg]:size-3.5", defaultClassNames.caption_label),
			table: "w-full border-collapse",
			weekdays: cn("flex", defaultClassNames.weekdays),
			weekday: cn("text-muted-foreground flex-1 select-none rounded-md text-[0.8rem] font-normal", defaultClassNames.weekday),
			week: cn("mt-2 flex w-full", defaultClassNames.week),
			week_number_header: cn("w-(--cell-size) select-none", defaultClassNames.week_number_header),
			week_number: cn("text-muted-foreground select-none text-[0.8rem]", defaultClassNames.week_number),
			day: cn("group/day relative aspect-square h-full w-full select-none p-0 text-center [&:first-child[data-selected=true]_button]:rounded-l-md [&:last-child[data-selected=true]_button]:rounded-r-md", defaultClassNames.day),
			range_start: cn("bg-accent rounded-l-md", defaultClassNames.range_start),
			range_middle: cn("rounded-none", defaultClassNames.range_middle),
			range_end: cn("bg-accent rounded-r-md", defaultClassNames.range_end),
			today: cn("bg-accent text-accent-foreground rounded-md data-[selected=true]:rounded-none", defaultClassNames.today),
			outside: cn("text-muted-foreground aria-selected:text-muted-foreground", defaultClassNames.outside),
			disabled: cn("text-muted-foreground opacity-50", defaultClassNames.disabled),
			hidden: cn("invisible", defaultClassNames.hidden),
			...classNames
		},
		components: {
			Root: ({ className, rootRef, ...props }) => {
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					"data-slot": "calendar",
					ref: rootRef,
					className: cn(className),
					...props
				});
			},
			Chevron: ({ className, orientation, ...props }) => {
				if (orientation === "left") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
					className: cn("size-4", className),
					...props
				});
				if (orientation === "right") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
					className: cn("size-4", className),
					...props
				});
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
					className: cn("size-4", className),
					...props
				});
			},
			DayButton: CalendarDayButton,
			WeekNumber: ({ children, ...props }) => {
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					...props,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex size-(--cell-size) items-center justify-center text-center",
						children
					})
				});
			},
			...components
		},
		...props
	});
}
function CalendarDayButton({ className, day, modifiers, ...props }) {
	const defaultClassNames = getDefaultClassNames();
	const ref = import_react.useRef(null);
	import_react.useEffect(() => {
		if (modifiers["focused"]) ref.current?.focus();
	}, [modifiers]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		ref,
		variant: "ghost",
		size: "icon",
		"data-day": day.date.toLocaleDateString(),
		"data-selected-single": modifiers["selected"] && !modifiers["range_start"] && !modifiers["range_end"] && !modifiers["range_middle"],
		"data-range-start": modifiers["range_start"],
		"data-range-end": modifiers["range_end"],
		"data-range-middle": modifiers["range_middle"],
		className: cn("data-[selected-single=true]:bg-primary data-[selected-single=true]:text-primary-foreground data-[range-middle=true]:bg-accent data-[range-middle=true]:text-accent-foreground data-[range-start=true]:bg-primary data-[range-start=true]:text-primary-foreground data-[range-end=true]:bg-primary data-[range-end=true]:text-primary-foreground group-data-[focused=true]/day:border-ring group-data-[focused=true]/day:ring-ring/50 flex aspect-square h-auto w-full min-w-(--cell-size) flex-col gap-1 font-normal leading-none data-[range-end=true]:rounded-md data-[range-middle=true]:rounded-none data-[range-start=true]:rounded-md group-data-[focused=true]/day:relative group-data-[focused=true]/day:z-10 group-data-[focused=true]/day:ring-[3px] [&>span]:text-xs [&>span]:opacity-70", defaultClassNames.day, className),
		...props
	});
}
var Checkbox = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox$1, {
	ref,
	className: cn("grid place-content-center peer h-4 w-4 shrink-0 rounded-sm border border-primary shadow cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckboxIndicator, {
		className: cn("grid place-content-center text-current"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" })
	})
}));
Checkbox.displayName = Checkbox$1.displayName;
var Popover = Root2;
var PopoverTrigger = Trigger;
var PopoverContent = import_react.forwardRef(({ className, align = "center", sideOffset = 4, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	align,
	sideOffset,
	className: cn("z-50 w-72 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-popover-content-transform-origin)", className),
	...props
}) }));
PopoverContent.displayName = Content2.displayName;
var ScrollArea = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Root, {
	ref,
	className: cn("relative overflow-hidden", className),
	...props,
	children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Viewport, {
			className: "h-full w-full rounded-[inherit]",
			children
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollBar, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Corner, {})
	]
}));
ScrollArea.displayName = Root.displayName;
var ScrollBar = import_react.forwardRef(({ className, orientation = "vertical", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaScrollbar, {
	ref,
	orientation,
	className: cn("flex touch-none select-none transition-colors", orientation === "vertical" && "h-full w-2.5 border-l border-l-transparent p-[1px]", orientation === "horizontal" && "h-2.5 flex-col border-t border-t-transparent p-[1px]", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaThumb, { className: "relative flex-1 rounded-full bg-border" })
}));
ScrollBar.displayName = ScrollAreaScrollbar.displayName;
var Select = Select$1;
var SelectValue = SelectValue$1;
var SelectTrigger = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectTrigger$1, {
	ref,
	className: cn("flex h-9 w-full items-center justify-between whitespace-nowrap rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm ring-offset-background cursor-pointer data-[placeholder]:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectIcon, {
		asChild: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4 opacity-50" })
	})]
}));
SelectTrigger.displayName = SelectTrigger$1.displayName;
var SelectScrollUpButton = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectScrollUpButton$1, {
	ref,
	className: cn("flex cursor-default items-center justify-center py-1", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "h-4 w-4" })
}));
SelectScrollUpButton.displayName = SelectScrollUpButton$1.displayName;
var SelectScrollDownButton = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectScrollDownButton$1, {
	ref,
	className: cn("flex cursor-default items-center justify-center py-1", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4" })
}));
SelectScrollDownButton.displayName = SelectScrollDownButton$1.displayName;
var SelectContent = import_react.forwardRef(({ className, children, position = "popper", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent$1, {
	ref,
	className: cn("relative z-50 max-h-(--radix-select-content-available-height) min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-select-content-transform-origin)", position === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1", className),
	position,
	...props,
	children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectScrollUpButton, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectViewport, {
			className: cn("p-1", position === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"),
			children
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectScrollDownButton, {})
	]
}) }));
SelectContent.displayName = SelectContent$1.displayName;
var SelectLabel = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectLabel$1, {
	ref,
	className: cn("px-2 py-1.5 text-sm font-semibold", className),
	...props
}));
SelectLabel.displayName = SelectLabel$1.displayName;
var SelectItem = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem$1, {
	ref,
	className: cn("relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-2 pr-8 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute right-2 flex h-3.5 w-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItemIndicator, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }) })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItemText, { children })]
}));
SelectItem.displayName = SelectItem$1.displayName;
var SelectSeparator = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectSeparator$1, {
	ref,
	className: cn("-mx-1 my-1 h-px bg-muted", className),
	...props
}));
SelectSeparator.displayName = SelectSeparator$1.displayName;
var Table = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: "relative w-full overflow-auto",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
		ref,
		className: cn("w-full caption-bottom text-sm", className),
		...props
	})
}));
Table.displayName = "Table";
var TableHeader = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
	ref,
	className: cn("[&_tr]:border-b", className),
	...props
}));
TableHeader.displayName = "TableHeader";
var TableBody = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
	ref,
	className: cn("[&_tr:last-child]:border-0", className),
	...props
}));
TableBody.displayName = "TableBody";
var TableFooter = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tfoot", {
	ref,
	className: cn("border-t bg-muted/50 font-medium [&>tr]:last:border-b-0", className),
	...props
}));
TableFooter.displayName = "TableFooter";
var TableRow = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
	ref,
	className: cn("border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted", className),
	...props
}));
TableRow.displayName = "TableRow";
var TableHead = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
	ref,
	className: cn("h-10 px-2 text-left align-middle font-medium text-muted-foreground [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]", className),
	...props
}));
TableHead.displayName = "TableHead";
var TableCell = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
	ref,
	className: cn("p-2 align-middle [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]", className),
	...props
}));
TableCell.displayName = "TableCell";
var TableCaption = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("caption", {
	ref,
	className: cn("mt-4 text-sm text-muted-foreground", className),
	...props
}));
TableCaption.displayName = "TableCaption";
function DateRangeFilterDropdown({ columnKey, activeDateRange, onDateRangeChange }) {
	const [open, setOpen] = import_react.useState(false);
	const [range, setRange] = import_react.useState(activeDateRange);
	const hasActiveFilter = Boolean(activeDateRange.from || activeDateRange.to);
	import_react.useEffect(() => {
		if (open) setRange(activeDateRange);
	}, [
		open,
		activeDateRange.from,
		activeDateRange.to
	]);
	const formatDate = (date) => date?.toLocaleDateString("en-IN", {
		day: "2-digit",
		month: "short",
		year: "numeric"
	}) ?? "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": `Filter ${columnKey} by date`,
				onClick: (event) => event.stopPropagation(),
				className: cn("inline-flex size-7 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground", hasActiveFilter && "text-primary"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { className: "size-4" })
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverContent, {
			align: "start",
			className: "w-auto max-w-[calc(100vw-2rem)] p-3",
			onClick: (event) => event.stopPropagation(),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium text-muted-foreground",
							children: "Filter by date"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								className: "h-7 text-xs",
								onClick: () => {
									onDateRangeChange(columnKey, {});
									setOpen(false);
								},
								children: "Clear"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								className: "h-7 text-xs",
								onClick: () => {
									onDateRangeChange(columnKey, range);
									setOpen(false);
								},
								children: "Apply"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, {
						mode: "range",
						selected: {
							from: range.from,
							to: range.to
						},
						onSelect: (value) => setRange({
							from: value?.from,
							to: value?.to
						}),
						numberOfMonths: 1,
						initialFocus: true
					}),
					(range.from || range.to) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-center text-xs text-muted-foreground",
						children: [formatDate(range.from), range.to ? ` - ${formatDate(range.to)}` : ""]
					})
				]
			})
		})]
	});
}
function ColumnFilterDropdown({ column, data, activeFilters, onFilterChange }) {
	const [filterSearch, setFilterSearch] = import_react.useState("");
	const [localSelected, setLocalSelected] = import_react.useState(/* @__PURE__ */ new Set());
	const [open, setOpen] = import_react.useState(false);
	const uniqueValues = import_react.useMemo(() => {
		const values = /* @__PURE__ */ new Set();
		data.forEach((row) => {
			const value = column.filterValue ? column.filterValue(row) : row[column.key];
			if (value !== null && value !== void 0) values.add(String(value));
		});
		return Array.from(values).sort((a, b) => a.localeCompare(b));
	}, [column, data]);
	const filteredValues = import_react.useMemo(() => {
		const query = filterSearch.trim().toLowerCase();
		return query ? uniqueValues.filter((value) => value.toLowerCase().includes(query)) : uniqueValues;
	}, [filterSearch, uniqueValues]);
	import_react.useEffect(() => {
		if (open) {
			setLocalSelected(new Set(activeFilters ?? uniqueValues));
			setFilterSearch("");
		}
	}, [
		open,
		activeFilters,
		uniqueValues
	]);
	const allSelected = uniqueValues.length > 0 && localSelected.size === uniqueValues.length;
	const hasActiveFilter = activeFilters !== void 0 && activeFilters.size < uniqueValues.length;
	const toggleValue = (value) => {
		setLocalSelected((current) => {
			const next = new Set(current);
			if (next.has(value)) next.delete(value);
			else next.add(value);
			return next;
		});
	};
	const apply = () => {
		onFilterChange(column.key, allSelected || localSelected.size === 0 ? void 0 : new Set(localSelected));
		setOpen(false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": `Filter ${column.header}`,
				onClick: (event) => event.stopPropagation(),
				className: cn("inline-flex size-7 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground", hasActiveFilter && "text-primary"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListFilter, { className: "size-4" })
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PopoverContent, {
			align: "start",
			className: "w-60 p-0",
			onClick: (event) => event.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border-b p-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							"aria-label": `Search ${column.header} values`,
							placeholder: "Search values",
							value: filterSearch,
							onChange: (event) => setFilterSearch(event.target.value),
							className: "h-8 pl-7 text-sm"
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					role: "checkbox",
					"aria-checked": allSelected,
					onClick: () => setLocalSelected(allSelected ? /* @__PURE__ */ new Set() : new Set(uniqueValues)),
					className: "flex w-full items-center gap-2 border-b px-3 py-2 text-left text-sm hover:bg-muted/60",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-4 place-items-center rounded-[3px] border border-input bg-background",
						"aria-hidden": "true",
						children: allSelected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3 text-primary" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-muted-foreground",
						children: "Select all"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-h-48 overflow-y-auto p-1",
					children: filteredValues.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-3 text-center text-sm text-muted-foreground",
						children: "No matches"
					}) : filteredValues.map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						role: "checkbox",
						"aria-checked": localSelected.has(value),
						onClick: () => toggleValue(value),
						className: "flex w-full items-center gap-2 rounded-sm px-2 py-1.5 text-left text-sm hover:bg-muted/60",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-4 place-items-center rounded-[3px] border border-input bg-background",
							"aria-hidden": "true",
							children: localSelected.has(value) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3 text-primary" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate",
							children: value
						})]
					}, value))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2 border-t p-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						className: "h-8 flex-1",
						onClick: () => {
							onFilterChange(column.key);
							setOpen(false);
						},
						children: "Clear"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						className: "h-8 flex-1",
						onClick: apply,
						children: "Apply"
					})]
				})
			]
		})]
	});
}
function ColumnSelectorDropdown({ columns, visibleKeys, onVisibilityChange }) {
	const [open, setOpen] = import_react.useState(false);
	const selectableColumns = columns.filter((column) => column.key !== "actions");
	const allVisible = selectableColumns.every((column) => visibleKeys.has(column.key));
	const toggle = (key) => {
		const next = new Set(visibleKeys);
		if (next.has(key)) next.delete(key);
		else next.add(key);
		onVisibilityChange(next);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				size: "sm",
				className: "h-9 gap-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Columns3, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "hidden sm:inline",
					children: "Columns"
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PopoverContent, {
			align: "end",
			className: "w-56 p-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				role: "checkbox",
				"aria-checked": allVisible,
				onClick: () => onVisibilityChange(allVisible ? new Set(columns.filter((column) => column.key === "actions").map((column) => column.key)) : new Set(columns.map((column) => column.key))),
				className: "flex w-full items-center gap-2 border-b px-3 py-2 text-left text-sm hover:bg-muted/60",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-4 place-items-center rounded-[3px] border border-input bg-background",
					"aria-hidden": "true",
					children: allVisible && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3 text-primary" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium text-muted-foreground",
					children: "All columns"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollArea, {
				className: "max-h-80",
				children: selectableColumns.map((column) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					role: "checkbox",
					"aria-checked": visibleKeys.has(column.key),
					onClick: () => toggle(column.key),
					className: "flex w-full items-center gap-2 px-3 py-2 text-left text-sm hover:bg-muted/60",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-4 place-items-center rounded-[3px] border border-input bg-background",
						"aria-hidden": "true",
						children: visibleKeys.has(column.key) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3 text-primary" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate",
						children: column.header
					})]
				}, column.key))
			})]
		})]
	});
}
function safeReadSessionState(key) {
	if (!key || typeof window === "undefined") return null;
	try {
		const saved = window.sessionStorage.getItem(key);
		return saved ? JSON.parse(saved) : null;
	} catch {
		return null;
	}
}
function dateValue(value) {
	if (value instanceof Date) return Number.isNaN(value.getTime()) ? null : value;
	if (typeof value !== "string" && typeof value !== "number") return null;
	const parsed = new Date(value);
	return Number.isNaN(parsed.getTime()) ? null : parsed;
}
function sortValue(value) {
	const date = dateValue(value);
	if (date) return date.getTime();
	if (typeof value === "number") return value;
	return String(value ?? "").toLocaleLowerCase();
}
function formatDate(date) {
	return date.toLocaleDateString("en-IN", {
		day: "2-digit",
		month: "short",
		year: "numeric"
	});
}
function pageNumbers(currentPage, totalPages) {
	if (totalPages <= 7) return Array.from({ length: totalPages }, (_, index) => index + 1);
	const pages = [1];
	if (currentPage > 3) pages.push("ellipsis");
	for (let page = Math.max(2, currentPage - 1); page <= Math.min(totalPages - 1, currentPage + 1); page++) pages.push(page);
	if (currentPage < totalPages - 2) pages.push("ellipsis");
	pages.push(totalPages);
	return pages;
}
function DataTable({ data, columns, searchPlaceholder = "Search", searchKeys = [], pageSize: initialPageSize = 10, pageSizeOptions = [
	10,
	20,
	50,
	100
], emptyMessage = "No records found.", getRowClassName, toolbarActions, selectionSummary, onFilteredDataChange, onSelectionChange, selectable = false, isRowSelectable, selectionResetKey, storageKey, userId }) {
	const safeData = import_react.useMemo(() => Array.isArray(data) ? data : [], [data]);
	const [selectedIds, setSelectedIds] = import_react.useState(/* @__PURE__ */ new Set());
	const [searchQuery, setSearchQueryState] = import_react.useState("");
	const [currentPage, setCurrentPageState] = import_react.useState(1);
	const [pageSize, setPageSizeState] = import_react.useState(Math.max(1, initialPageSize));
	const [sortKey, setSortKeyState] = import_react.useState(null);
	const [sortDirection, setSortDirectionState] = import_react.useState("asc");
	const [columnFilters, setColumnFilters] = import_react.useState({});
	const [dateRangeFilters, setDateRangeFilters] = import_react.useState({});
	const [visibleKeys, setVisibleKeys] = import_react.useState(() => new Set(columns.map((column) => column.key)));
	const scrollRef = import_react.useRef(null);
	import_react.useEffect(() => {
		const onKeyDown = (event) => {
			const target = event.target;
			if (target instanceof HTMLElement && target.closest("input, textarea, select, [contenteditable='true']")) return;
			if (event.key !== "ArrowLeft" && event.key !== "ArrowRight") return;
			const element = scrollRef.current;
			if (!element) return;
			event.preventDefault();
			element.scrollBy({
				left: event.key === "ArrowRight" ? 150 : -150,
				behavior: "smooth"
			});
		};
		window.addEventListener("keydown", onKeyDown);
		return () => window.removeEventListener("keydown", onKeyDown);
	}, []);
	const columnStorageKey = storageKey ? `col-vis:${userId ? `${userId}:` : ""}${storageKey}` : null;
	const filterStorageKey = storageKey ? `filter-state:${storageKey}` : null;
	import_react.useEffect(() => {
		if (columnStorageKey) try {
			const saved = window.localStorage.getItem(columnStorageKey);
			if (saved) {
				const keys = JSON.parse(saved);
				const validKeys = new Set(columns.map((column) => column.key));
				setVisibleKeys(new Set(keys.filter((key) => validKeys.has(key))));
			}
		} catch {
			setVisibleKeys(new Set(columns.map((column) => column.key)));
		}
		const saved = safeReadSessionState(filterStorageKey);
		if (!saved) return;
		if (typeof saved.searchQuery === "string") setSearchQueryState(saved.searchQuery);
		if (typeof saved.currentPage === "number" && saved.currentPage > 0) setCurrentPageState(saved.currentPage);
		if (typeof saved.pageSize === "number" && saved.pageSize > 0) setPageSizeState(saved.pageSize);
		if (typeof saved.sortKey === "string" || saved.sortKey === null) setSortKeyState(saved.sortKey);
		if (saved.sortDirection === "asc" || saved.sortDirection === "desc") setSortDirectionState(saved.sortDirection);
		if (saved.columnFilters) setColumnFilters(Object.fromEntries(Object.entries(saved.columnFilters).map(([key, values]) => [key, new Set(values)])));
		if (saved.dateRangeFilters) setDateRangeFilters(Object.fromEntries(Object.entries(saved.dateRangeFilters).map(([key, range]) => [key, {
			...range.from ? { from: new Date(range.from) } : {},
			...range.to ? { to: new Date(range.to) } : {}
		}])));
	}, [columnStorageKey, filterStorageKey]);
	const persistState = (patch) => {
		if (!filterStorageKey || typeof window === "undefined") return;
		const current = safeReadSessionState(filterStorageKey) ?? {};
		try {
			window.sessionStorage.setItem(filterStorageKey, JSON.stringify({
				...current,
				...patch
			}));
		} catch {
			return;
		}
	};
	import_react.useEffect(() => {
		setSelectedIds(/* @__PURE__ */ new Set());
	}, [selectionResetKey]);
	const updateSearch = (value) => {
		setSearchQueryState(value);
		setCurrentPageState(1);
		setSelectedIds(/* @__PURE__ */ new Set());
		persistState({
			searchQuery: value,
			currentPage: 1
		});
	};
	const searchFilteredData = import_react.useMemo(() => {
		const query = searchQuery.trim().toLocaleLowerCase();
		if (!query || searchKeys.length === 0) return safeData;
		return safeData.filter((row) => searchKeys.some((key) => {
			const value = row[key];
			return (typeof value === "string" || typeof value === "number") && String(value).toLocaleLowerCase().includes(query);
		}));
	}, [
		safeData,
		searchQuery,
		searchKeys
	]);
	const filteredData = import_react.useMemo(() => {
		const listFilterKeys = Object.keys(columnFilters);
		const dateFilterKeys = Object.keys(dateRangeFilters);
		if (listFilterKeys.length === 0 && dateFilterKeys.length === 0) return searchFilteredData;
		return searchFilteredData.filter((row) => {
			const passesListFilters = listFilterKeys.every((key) => {
				const column = columns.find((item) => item.key === key);
				const value = column?.filterValue ? column.filterValue(row) : row[key];
				return value !== null && value !== void 0 && columnFilters[key]?.has(String(value));
			});
			const passesDateFilters = dateFilterKeys.every((key) => {
				const column = columns.find((item) => item.key === key);
				const date = dateValue(column?.filterValue ? column.filterValue(row) : row[key]);
				if (!date) return false;
				const { from, to } = dateRangeFilters[key] ?? {};
				const dateTime = date.getTime();
				if (from) {
					if (dateTime < new Date(from.getFullYear(), from.getMonth(), from.getDate()).getTime()) return false;
				}
				if (to) {
					if (dateTime >= new Date(to.getFullYear(), to.getMonth(), to.getDate() + 1).getTime()) return false;
				}
				return true;
			});
			return passesListFilters && passesDateFilters;
		});
	}, [
		searchFilteredData,
		columnFilters,
		dateRangeFilters,
		columns
	]);
	const sortedData = import_react.useMemo(() => {
		if (!sortKey) return filteredData;
		const column = columns.find((item) => item.key === sortKey);
		return [...filteredData].sort((left, right) => {
			const leftValue = column?.filterValue ? column.filterValue(left) : left[sortKey];
			const rightValue = column?.filterValue ? column.filterValue(right) : right[sortKey];
			const a = sortValue(leftValue);
			const b = sortValue(rightValue);
			const comparison = typeof a === "number" && typeof b === "number" ? a - b : String(a).localeCompare(String(b));
			return sortDirection === "asc" ? comparison : -comparison;
		});
	}, [
		filteredData,
		sortKey,
		sortDirection,
		columns
	]);
	import_react.useEffect(() => {
		onFilteredDataChange?.(sortedData);
	}, [sortedData, onFilteredDataChange]);
	const totalPages = Math.ceil(sortedData.length / pageSize);
	const displayedPage = Math.max(1, Math.min(currentPage, totalPages || 1));
	const visiblePageNumbers = pageNumbers(displayedPage, totalPages);
	const startIndex = (displayedPage - 1) * pageSize;
	const paginatedData = sortedData.slice(startIndex, startIndex + pageSize);
	const visibleColumns = columnStorageKey ? columns.filter((column) => visibleKeys.has(column.key)) : columns;
	const selectableRows = sortedData.filter((row) => isRowSelectable?.(row) !== false);
	const allSelected = selectableRows.length > 0 && selectableRows.every((row) => selectedIds.has(row.id));
	const someSelected = !allSelected && selectableRows.some((row) => selectedIds.has(row.id));
	const checkboxState = allSelected ? true : someSelected ? "indeterminate" : false;
	const hasAnyFilter = Boolean(searchQuery.trim() || Object.keys(columnFilters).length || Object.keys(dateRangeFilters).length);
	import_react.useEffect(() => {
		onSelectionChange?.(sortedData.filter((row) => selectedIds.has(row.id) && isRowSelectable?.(row) !== false));
	}, [
		selectedIds,
		sortedData,
		isRowSelectable,
		onSelectionChange
	]);
	const changeListFilter = (key, values) => {
		setColumnFilters((current) => {
			const next = { ...current };
			if (values === void 0) delete next[key];
			else next[key] = values;
			persistState({ columnFilters: Object.fromEntries(Object.entries(next).map(([name, set]) => [name, [...set]])) });
			return next;
		});
		setCurrentPageState(1);
		setSelectedIds(/* @__PURE__ */ new Set());
	};
	const changeDateFilter = (key, range) => {
		setDateRangeFilters((current) => {
			const next = { ...current };
			if (!range.from && !range.to) delete next[key];
			else next[key] = range;
			persistState({ dateRangeFilters: Object.fromEntries(Object.entries(next).map(([name, value]) => [name, {
				from: value.from?.toISOString() ?? null,
				to: value.to?.toISOString() ?? null
			}])) });
			return next;
		});
		setCurrentPageState(1);
		setSelectedIds(/* @__PURE__ */ new Set());
	};
	const changeVisibility = (keys) => {
		setVisibleKeys(keys);
		if (!columnStorageKey || typeof window === "undefined") return;
		try {
			window.localStorage.setItem(columnStorageKey, JSON.stringify([...keys]));
		} catch {
			return;
		}
	};
	const toggleSort = (key) => {
		const direction = sortKey === key && sortDirection === "asc" ? "desc" : "asc";
		const nextKey = sortKey === key ? key : key;
		setSortKeyState(nextKey);
		setSortDirectionState(direction);
		persistState({
			sortKey: nextKey,
			sortDirection: direction
		});
	};
	const toggleRow = (id) => {
		setSelectedIds((current) => {
			const next = new Set(current);
			if (next.has(id)) next.delete(id);
			else next.add(id);
			return next;
		});
	};
	const toggleAllFilteredRows = () => {
		setSelectedIds((current) => {
			const next = new Set(current);
			if (allSelected) selectableRows.forEach((row) => next.delete(row.id));
			else selectableRows.forEach((row) => next.add(row.id));
			return next;
		});
	};
	const setPage = (page) => {
		const next = Math.max(1, Math.min(page, totalPages || 1));
		setCurrentPageState(next);
		persistState({ currentPage: next });
	};
	const clearAllFilters = () => {
		setColumnFilters({});
		setDateRangeFilters({});
		setSearchQueryState("");
		setSortKeyState(null);
		setSortDirectionState("asc");
		setCurrentPageState(1);
		setSelectedIds(/* @__PURE__ */ new Set());
		if (filterStorageKey && typeof window !== "undefined") try {
			window.sessionStorage.removeItem(filterStorageKey);
		} catch {
			return;
		}
	};
	const pageOptions = pageSizeOptions.filter((size) => Number.isFinite(size) && size > 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 sm:space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between",
				children: [searchKeys.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative w-full sm:max-w-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						"aria-label": searchPlaceholder,
						placeholder: searchPlaceholder,
						value: searchQuery,
						onChange: (event) => updateSearch(event.target.value),
						className: "h-9 pl-9 text-sm"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [toolbarActions, columnStorageKey && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColumnSelectorDropdown, {
						columns,
						visibleKeys,
						onVisibilityChange: changeVisibility
					})]
				})]
			}),
			selectionSummary,
			(hasAnyFilter || sortKey) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					sortKey && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1 rounded-md border border-border bg-muted px-2 py-1 text-xs text-foreground",
						children: [
							"Sort: ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: columns.find((column) => column.key === sortKey)?.header ?? sortKey }),
							sortDirection === "asc" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-3" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "Clear sort",
								onClick: () => {
									setSortKeyState(null);
									setSortDirectionState("asc");
									persistState({
										sortKey: null,
										sortDirection: "asc"
									});
								},
								className: "ml-1 text-muted-foreground hover:text-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
							})
						]
					}),
					searchQuery.trim() && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1 rounded-md border border-border bg-brand-soft px-2 py-1 text-xs text-foreground",
						children: [
							"Search: ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: searchQuery }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "Clear search",
								onClick: () => updateSearch(""),
								className: "ml-1 text-muted-foreground hover:text-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
							})
						]
					}),
					Object.entries(columnFilters).map(([key, values]) => {
						const column = columns.find((item) => item.key === key);
						const selected = [...values];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1 rounded-md border border-border bg-brand-soft px-2 py-1 text-xs text-foreground",
							children: [
								column?.header ?? key,
								": ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: selected.length === 1 ? selected[0] : `${selected.length} selected` }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": `Clear ${column?.header ?? key} filter`,
									onClick: () => changeListFilter(key),
									className: "ml-1 text-muted-foreground hover:text-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
								})
							]
						}, key);
					}),
					Object.entries(dateRangeFilters).map(([key, range]) => {
						const column = columns.find((item) => item.key === key);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1 rounded-md border border-border bg-brand-soft px-2 py-1 text-xs text-foreground",
							children: [
								column?.header ?? key,
								": ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [range.from ? formatDate(range.from) : "", range.to ? ` - ${formatDate(range.to)}` : ""] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": `Clear ${column?.header ?? key} date filter`,
									onClick: () => changeDateFilter(key, {}),
									className: "ml-1 text-muted-foreground hover:text-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
								})
							]
						}, key);
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "link",
						size: "sm",
						className: "h-auto px-1 text-xs text-destructive",
						onClick: clearAllFilters,
						children: "Clear all"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-hidden rounded-lg border border-border bg-surface",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					ref: scrollRef,
					className: "overflow-x-auto",
					tabIndex: 0,
					"aria-label": "Scrollable table",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
						className: "min-w-[640px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [selectable && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
							className: "w-10 px-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
								checked: checkboxState,
								onCheckedChange: toggleAllFilteredRows,
								"aria-label": "Select all filtered rows"
							})
						}), visibleColumns.map((column) => {
							const sortable = column.sortable !== false && column.key !== "actions";
							const filterable = column.filterable !== false && column.key !== "actions";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: cn("px-3 py-2.5 text-xs font-semibold sm:px-4 sm:py-3 sm:text-sm", column.className, column.headerClassName, sortable && "cursor-pointer select-none hover:bg-muted/60"),
								onClick: () => sortable && toggleSort(column.key),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate",
											children: column.header
										}),
										sortable && (sortKey === column.key ? sortDirection === "asc" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-3.5 shrink-0 text-muted-foreground" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-3.5 shrink-0 text-muted-foreground" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-3.5 shrink-0 text-muted-foreground/50" })),
										filterable && (column.filterType === "date" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DateRangeFilterDropdown, {
											columnKey: column.key,
											activeDateRange: dateRangeFilters[column.key] ?? {},
											onDateRangeChange: changeDateFilter
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColumnFilterDropdown, {
											column,
											data: safeData,
											activeFilters: columnFilters[column.key],
											onFilterChange: changeListFilter
										}))
									]
								})
							}, column.key);
						})] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: paginatedData.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							colSpan: visibleColumns.length + (selectable ? 1 : 0),
							className: "h-24 text-center text-sm text-muted-foreground",
							children: emptyMessage
						}) }) : paginatedData.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
							className: cn(getRowClassName?.(row), selectedIds.has(row.id) && "bg-brand-soft hover:bg-brand-soft"),
							children: [selectable && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "w-10 px-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
									checked: selectedIds.has(row.id),
									disabled: isRowSelectable?.(row) === false,
									onCheckedChange: () => toggleRow(row.id),
									"aria-label": `Select row ${row.id}`
								})
							}), visibleColumns.map((column) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: cn("px-3 py-2 text-xs sm:px-4 sm:py-3 sm:text-sm", column.className),
								children: column.cell(row)
							}, column.key))]
						}, row.id)) })]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 px-1 sm:flex-row sm:items-center sm:justify-between sm:px-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 text-xs text-muted-foreground sm:text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "whitespace-nowrap",
						children: "Rows per page"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: String(pageSize),
						onValueChange: (value) => {
							const next = Number(value);
							setPageSizeState(next);
							setCurrentPageState(1);
							persistState({
								pageSize: next,
								currentPage: 1
							});
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "h-8 w-[76px]",
							"aria-label": "Rows per page",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: pageOptions.map((size) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: String(size),
							children: size
						}, size)) })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2 sm:justify-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground sm:text-sm",
						children: sortedData.length === 0 ? "0 of 0" : `${startIndex + 1}-${Math.min(startIndex + pageSize, sortedData.length)} of ${sortedData.length}`
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "icon",
								className: "size-8",
								onClick: () => setPage(1),
								disabled: displayedPage === 1,
								"aria-label": "First page",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsLeft, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "icon",
								className: "size-8",
								onClick: () => setPage(displayedPage - 1),
								disabled: displayedPage === 1,
								"aria-label": "Previous page",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {})
							}),
							visiblePageNumbers.map((page, index) => page === "ellipsis" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "px-1 text-sm text-muted-foreground",
								children: "..."
							}, `ellipsis-${index}`) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: displayedPage === page ? "default" : "outline",
								size: "icon",
								className: "size-8 text-xs",
								onClick: () => setPage(page),
								"aria-label": `Page ${page}`,
								"aria-current": displayedPage === page ? "page" : void 0,
								children: page
							}, page)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "icon",
								className: "size-8",
								onClick: () => setPage(displayedPage + 1),
								disabled: displayedPage >= totalPages || totalPages === 0,
								"aria-label": "Next page",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "icon",
								className: "size-8",
								onClick: () => setPage(totalPages),
								disabled: displayedPage >= totalPages || totalPages === 0,
								"aria-label": "Last page",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsRight, {})
							})
						]
					})]
				})]
			})
		]
	});
}
//#endregion
export { PopoverTrigger as a, SelectItem as c, Table as d, TableBody as f, TableRow as g, TableHeader as h, PopoverContent as i, SelectTrigger as l, TableHead as m, DataTable as n, Select as o, TableCell as p, Popover as r, SelectContent as s, Checkbox as t, SelectValue as u };
