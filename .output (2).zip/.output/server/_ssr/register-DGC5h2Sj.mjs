import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as useAuth } from "./auth-C8Fxb5sC.mjs";
import { a as buttonClass, i as PasswordField, n as Field, r as FormError, t as AuthLayout } from "./AuthLayout-BQiOvwrQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/register-DGC5h2Sj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function RegisterPage({ onSubmit }) {
	const auth = useAuth();
	const navigate = useNavigate();
	const [errors, setErrors] = (0, import_react.useState)({});
	const [formError, setFormError] = (0, import_react.useState)();
	const [loading, setLoading] = (0, import_react.useState)(false);
	async function handleSubmit(event) {
		event.preventDefault();
		const formData = new FormData(event.currentTarget);
		const name = String(formData.get("name") ?? "").trim();
		const email = String(formData.get("email") ?? "").trim();
		const password = String(formData.get("password") ?? "");
		const confirm = String(formData.get("confirm") ?? "");
		const terms = formData.get("terms") === "on";
		const next = {};
		const nameParts = name.split(/\s+/).filter(Boolean);
		if (nameParts.length < 2) next.name = "Enter your first and last name.";
		if (!/^\S+@\S+\.\S+$/.test(email)) next.email = "Enter a valid email address.";
		if (password.length < 8) next.password = "Use at least 8 characters.";
		if (confirm !== password) next.confirm = "Passwords don't match.";
		if (!terms) next.terms = "Accept the terms to continue.";
		setErrors(next);
		setFormError(void 0);
		if (Object.keys(next).length) return;
		setLoading(true);
		try {
			if (onSubmit) await onSubmit({
				name,
				email,
				password
			});
			else await auth.register({
				first_name: nameParts[0] ?? "",
				last_name: nameParts.slice(1).join(" "),
				email,
				password
			});
			await navigate({
				to: "/",
				replace: true
			});
		} catch (error) {
			setFormError(error instanceof Error ? error.message : "Couldn't create your account. Try again.");
		} finally {
			setLoading(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthLayout, {
		title: "Create your account",
		subtitle: "Set up your workspace in a minute.",
		footer: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
			"Already have an account?",
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/login",
				className: "font-medium text-brand hover:underline",
				children: "Sign in"
			})
		] }),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: handleSubmit,
			noValidate: true,
			className: "space-y-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Full name",
					name: "name",
					autoComplete: "name",
					placeholder: "Your name",
					error: errors.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Work email",
					name: "email",
					type: "email",
					autoComplete: "email",
					placeholder: "you@company.com",
					error: errors.email
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordField, {
					label: "Password",
					name: "password",
					autoComplete: "new-password",
					placeholder: "At least 8 characters",
					error: errors.password
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordField, {
					label: "Confirm password",
					name: "confirm",
					autoComplete: "new-password",
					placeholder: "Repeat your password",
					error: errors.confirm
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex cursor-pointer items-start gap-2.5 text-sm text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						name: "terms",
						"aria-invalid": Boolean(errors.terms),
						className: "mt-0.5 size-4 rounded border-input accent-[var(--brand)]"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "I agree to the workspace terms and privacy policy." })]
				}), errors.terms && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1.5 text-xs text-destructive",
					children: errors.terms
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormError, { message: formError }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					disabled: loading,
					className: buttonClass,
					children: loading ? "Creating account…" : "Create account"
				})
			]
		})
	});
}
var SplitComponent = RegisterPage;
//#endregion
export { SplitComponent as component };
