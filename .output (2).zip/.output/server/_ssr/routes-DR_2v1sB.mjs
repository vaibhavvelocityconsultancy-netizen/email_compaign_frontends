import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { g as getEmailLogs, m as getBatches, y as getLeads } from "./api-DpU7a2cS.mjs";
import { S as Megaphone, ot as ArrowUpRight, rt as Briefcase } from "../_libs/lucide-react.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as StatCard } from "./StatCard-DjGEnZSv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DR_2v1sB.js
var import_jsx_runtime = require_jsx_runtime();
function Dashboard() {
	const leads = useQuery({
		queryKey: ["leads"],
		queryFn: getLeads
	});
	const campaigns = useQuery({
		queryKey: ["campaigns"],
		queryFn: getBatches
	});
	const logs = useQuery({
		queryKey: ["logs"],
		queryFn: getEmailLogs
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rise",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-mono text-[11px] tracking-wide text-muted-foreground",
					children: "OVERVIEW"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-3xl font-bold",
					children: "Dashboard"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				"aria-labelledby": "marketing-heading",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						id: "marketing-heading",
						className: "flex items-center gap-2 font-display text-lg font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Megaphone, { className: "size-5 text-brand" }), " Marketing"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/marketing",
						className: "inline-flex items-center gap-1 text-sm font-medium text-brand hover:underline",
						children: ["View dashboard ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4" })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-4 lg:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
							label: "TOTAL LEADS",
							value: leads.data?.length ?? "…",
							sub: "across all sources"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
							label: "ACTIVE CAMPAIGNS",
							value: campaigns.data?.filter((c) => c.status === "active").length ?? "…",
							sub: "currently running",
							delay: 40
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
							label: "EMAILS DELIVERED",
							value: logs.data?.filter((l) => l.status === "delivered").length ?? "…",
							sub: "all campaigns",
							tone: "good",
							delay: 80
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				"aria-labelledby": "sales-heading",
				className: "border-t border-line pt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 flex items-center justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							id: "sales-heading",
							className: "flex items-center gap-2 font-display text-lg font-semibold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-5 text-brand" }), " Sales"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/sales",
							className: "inline-flex items-center gap-1 text-sm font-medium text-brand hover:underline",
							children: ["View dashboard ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4" })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Sales data isn’t connected yet. Opportunities and quotations will appear here when available."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-4 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/sales/opportunities",
							className: "text-brand hover:underline",
							children: ["Opportunities ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "inline size-4" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/sales/quotations",
							className: "text-brand hover:underline",
							children: ["Quotations ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "inline size-4" })]
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { Dashboard as component };
