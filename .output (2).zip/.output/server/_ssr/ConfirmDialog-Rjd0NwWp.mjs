import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Modal } from "./Modal-vFtVKTX9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ConfirmDialog-Rjd0NwWp.js
var import_jsx_runtime = require_jsx_runtime();
function ConfirmDialog({ open, onClose, onConfirm, title, message, confirmLabel = "Delete", loading }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		open,
		onClose,
		title,
		eyebrow: "CONFIRM",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "p-5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: message
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-end gap-2 border-t border-line bg-background/50 px-5 py-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: onClose,
				className: "h-9 rounded-lg border border-line bg-surface px-4 text-sm transition-colors hover:bg-background",
				children: "Cancel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: onConfirm,
				disabled: loading,
				className: "h-9 rounded-lg bg-destructive px-4 text-sm font-medium text-destructive-foreground transition-colors hover:bg-destructive/90 disabled:opacity-50",
				children: loading ? "Working…" : confirmLabel
			})]
		})]
	});
}
//#endregion
export { ConfirmDialog as t };
