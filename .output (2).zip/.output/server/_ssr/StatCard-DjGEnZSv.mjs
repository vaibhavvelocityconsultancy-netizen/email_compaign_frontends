import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/StatCard-DjGEnZSv.js
var import_jsx_runtime = require_jsx_runtime();
function StatCard({ label, value, sub, tone = "muted", delay = 0 }) {
	const toneClass = tone === "good" ? "text-good" : tone === "bad" ? "text-bad" : "text-muted-foreground";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rise rounded-xl border border-line bg-surface p-4",
		style: { animationDelay: `${delay}ms` },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-mono text-[11px] text-muted-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 font-display text-3xl font-bold tracking-tight",
				children: value
			}),
			sub && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `mt-1 font-mono text-[11px] ${toneClass}`,
				children: sub
			})
		]
	});
}
//#endregion
export { StatCard as t };
