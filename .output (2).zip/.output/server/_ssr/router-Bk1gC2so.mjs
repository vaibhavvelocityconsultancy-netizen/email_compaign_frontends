import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { I as require_jsx_runtime, a as Overlay2, c as Title2, d as DialogContent, f as DialogDescription, h as DialogTitle, i as Description2, j as Slot, l as Dialog, m as DialogPortal, n as Cancel, o as Portal2, p as DialogOverlay, r as Content2, s as Root2, t as Action, u as DialogClose } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { n as buttonVariants, r as cn, t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { C as hasAuthTokens, E as logoutUser, O as registerUser, T as loginUser, h as getCurrentUser, k as request, t as clearAuthTokens } from "./api-DpU7a2cS.mjs";
import { $ as Check, A as KeyRound, C as LogOut, D as ListChecks, G as CircleAlert, H as ClipboardList, O as LayoutDashboard, Q as ChevronDown, S as Megaphone, T as LoaderCircle, U as Circle, X as ChevronRight, _ as Plus, d as Shield, f as ShieldCheck, g as RefreshCw, h as Repeat, it as Bell, n as Users, r as UserRound, rt as Briefcase, s as Trash2, st as ArrowRight, t as X, w as LockKeyhole, x as PanelLeft, y as Pencil, z as Database } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent$1, o as DialogTitle$1, r as DialogDescription$1, t as Dialog$1 } from "./dialog-BA-nrckz.mjs";
import { a as Label2, c as Root2$1, d as SubTrigger2, f as Trigger, i as ItemIndicator2, l as Separator2, n as Content2$1, o as Portal2$1, r as Item2, s as RadioItem2, t as CheckboxItem2, u as SubContent2 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
import { n as DataTable } from "./DataTable-DmCzJ7wu.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { K as redirect, S as useRouter, _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, v as createFileRoute, x as useNavigate, y as createRootRouteWithContext } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { c as useTasks, i as useDeleteTask } from "./task-api-Kgl7XzYs.mjs";
import { t as Route$24 } from "./dashboard-CzYjY-mN.mjs";
import { t as ConfirmDialog } from "./ConfirmDialog-Rjd0NwWp.mjs";
import { a as enumType, c as objectType, i as coerce, l as stringType, n as arrayType, s as numberType, t as anyType } from "../_libs/zod.mjs";
import { t as Route$25 } from "./email-campaign.campaigns-DNJB6Z5O.mjs";
import { n as Switch, t as Label } from "./label-CgdiPI6k.mjs";
import { t as Route$26 } from "./form-D5V-sZkR.mjs";
import { t as Route$27 } from "./leads.form-DWxL1Agx.mjs";
import { t as Route$28 } from "./location-Map1bQKb.mjs";
import { n as Recoil_index_5, t as Recoil_index_22 } from "../_libs/recoil.mjs";
import { n as authStateAtom, r as useAuth, t as AuthContext } from "./auth-C8Fxb5sC.mjs";
import { t as Route$29 } from "./orders-IqRm1BHq.mjs";
import { n as CollapsibleTrigger$1, r as Root, t as CollapsibleContent$1 } from "../_libs/radix-ui__react-collapsible.mjs";
import { t as Root$1 } from "../_libs/radix-ui__react-separator.mjs";
import { a as Trigger$1, i as Root3, n as Portal, r as Provider, t as Content2$2 } from "../_libs/radix-ui__react-tooltip.mjs";
import { n as AvatarFallback$1, r as AvatarImage$1, t as Avatar$1 } from "../_libs/radix-ui__react-avatar.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-Bk1gC2so.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/vc_email_crm/assets/styles-Cf1aBGSh.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var Collapsible = Root;
var CollapsibleTrigger = CollapsibleTrigger$1;
var CollapsibleContent = CollapsibleContent$1;
var MOBILE_BREAKPOINT = 768;
function useIsMobile() {
	const [isMobile, setIsMobile] = import_react.useState(void 0);
	import_react.useEffect(() => {
		const mql = window.matchMedia(`(max-width: 767px)`);
		const onChange = () => {
			setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
		};
		mql.addEventListener("change", onChange);
		setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
		return () => mql.removeEventListener("change", onChange);
	}, []);
	return !!isMobile;
}
var Separator = import_react.forwardRef(({ className, orientation = "horizontal", decorative = true, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root$1, {
	ref,
	decorative,
	orientation,
	className: cn("shrink-0 bg-border", orientation === "horizontal" ? "h-[1px] w-full" : "h-full w-[1px]", className),
	...props
}));
Separator.displayName = Root$1.displayName;
var Sheet = Dialog;
var SheetPortal = DialogPortal;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props,
	ref
}));
SheetOverlay.displayName = DialogOverlay.displayName;
var sheetVariants = cva("fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out", {
	variants: { side: {
		top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
		bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
		left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
		right: "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"
	} },
	defaultVariants: { side: "right" }
});
var SheetContent = import_react.forwardRef(({ side = "right", className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
	ref,
	className: cn(sheetVariants({ side }), className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	}), children]
})] }));
SheetContent.displayName = DialogContent.displayName;
var SheetHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
	...props
});
SheetHeader.displayName = "SheetHeader";
var SheetFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
SheetFooter.displayName = "SheetFooter";
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
	ref,
	className: cn("text-lg font-semibold text-foreground", className),
	...props
}));
SheetTitle.displayName = DialogTitle.displayName;
var SheetDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
SheetDescription.displayName = DialogDescription.displayName;
function Skeleton({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse rounded-md bg-primary/10", className),
		...props
	});
}
var TooltipProvider = Provider;
var Tooltip = Root3;
var TooltipTrigger = Trigger$1;
var TooltipContent = import_react.forwardRef(({ className, sideOffset = 4, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2$2, {
	ref,
	sideOffset,
	className: cn("z-50 overflow-hidden rounded-md bg-primary px-3 py-1.5 text-xs text-primary-foreground animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-tooltip-content-transform-origin)", className),
	...props
}) }));
TooltipContent.displayName = Content2$2.displayName;
var SIDEBAR_COOKIE_NAME = "sidebar_state";
var SIDEBAR_COOKIE_MAX_AGE = 604800;
var SIDEBAR_WIDTH = "16rem";
var SIDEBAR_WIDTH_MOBILE = "18rem";
var SIDEBAR_WIDTH_ICON = "3rem";
var SIDEBAR_KEYBOARD_SHORTCUT = "b";
var SidebarContext = import_react.createContext(null);
function useSidebar() {
	const context = import_react.useContext(SidebarContext);
	if (!context) throw new Error("useSidebar must be used within a SidebarProvider.");
	return context;
}
var SidebarProvider = import_react.forwardRef(({ defaultOpen = true, open: openProp, onOpenChange: setOpenProp, className, style, children, ...props }, ref) => {
	const isMobile = useIsMobile();
	const [openMobile, setOpenMobile] = import_react.useState(false);
	const [_open, _setOpen] = import_react.useState(defaultOpen);
	const open = openProp ?? _open;
	const setOpen = import_react.useCallback((value) => {
		const openState = typeof value === "function" ? value(open) : value;
		if (setOpenProp) setOpenProp(openState);
		else _setOpen(openState);
		document.cookie = `${SIDEBAR_COOKIE_NAME}=${openState}; path=/; max-age=${SIDEBAR_COOKIE_MAX_AGE}`;
	}, [setOpenProp, open]);
	const toggleSidebar = import_react.useCallback(() => {
		return isMobile ? setOpenMobile((open) => !open) : setOpen((open) => !open);
	}, [
		isMobile,
		setOpen,
		setOpenMobile
	]);
	import_react.useEffect(() => {
		const handleKeyDown = (event) => {
			if (event.key === SIDEBAR_KEYBOARD_SHORTCUT && (event.metaKey || event.ctrlKey)) {
				event.preventDefault();
				toggleSidebar();
			}
		};
		window.addEventListener("keydown", handleKeyDown);
		return () => window.removeEventListener("keydown", handleKeyDown);
	}, [toggleSidebar]);
	const state = open ? "expanded" : "collapsed";
	const contextValue = import_react.useMemo(() => ({
		state,
		open,
		setOpen,
		isMobile,
		openMobile,
		setOpenMobile,
		toggleSidebar
	}), [
		state,
		open,
		setOpen,
		isMobile,
		openMobile,
		setOpenMobile,
		toggleSidebar
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarContext.Provider, {
		value: contextValue,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipProvider, {
			delayDuration: 0,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					"--sidebar-width": SIDEBAR_WIDTH,
					"--sidebar-width-icon": SIDEBAR_WIDTH_ICON,
					...style
				},
				className: cn("group/sidebar-wrapper flex min-h-svh w-full has-[[data-variant=inset]]:bg-sidebar", className),
				ref,
				...props,
				children
			})
		})
	});
});
SidebarProvider.displayName = "SidebarProvider";
var Sidebar = import_react.forwardRef(({ side = "left", variant = "sidebar", collapsible = "offcanvas", className, children, ...props }, ref) => {
	const { isMobile, state, openMobile, setOpenMobile } = useSidebar();
	if (collapsible === "none") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex h-full w-(--sidebar-width) flex-col bg-sidebar text-sidebar-foreground", className),
		ref,
		...props,
		children
	});
	if (isMobile) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open: openMobile,
		onOpenChange: setOpenMobile,
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			"data-sidebar": "sidebar",
			"data-mobile": "true",
			className: "w-(--sidebar-width) bg-sidebar p-0 text-sidebar-foreground [&>button]:hidden",
			style: { "--sidebar-width": SIDEBAR_WIDTH_MOBILE },
			side,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetHeader, {
				className: "sr-only",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "Sidebar" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetDescription, { children: "Displays the mobile sidebar." })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-full w-full flex-col",
				children
			})]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref,
		className: "group peer hidden text-sidebar-foreground md:block",
		"data-state": state,
		"data-collapsible": state === "collapsed" ? collapsible : "",
		"data-variant": variant,
		"data-side": side,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("relative w-(--sidebar-width) bg-transparent transition-[width] duration-200 ease-linear", "group-data-[collapsible=offcanvas]:w-0", "group-data-[side=right]:rotate-180", variant === "floating" || variant === "inset" ? "group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)_+_theme(spacing.4))]" : "group-data-[collapsible=icon]:w-(--sidebar-width-icon)") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("fixed inset-y-0 z-10 hidden h-svh w-(--sidebar-width) transition-[left,right,width] duration-200 ease-linear md:flex", side === "left" ? "left-0 group-data-[collapsible=offcanvas]:left-[calc(var(--sidebar-width)*-1)]" : "right-0 group-data-[collapsible=offcanvas]:right-[calc(var(--sidebar-width)*-1)]", variant === "floating" || variant === "inset" ? "p-2 group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)_+_theme(spacing.4)_+2px)]" : "group-data-[collapsible=icon]:w-(--sidebar-width-icon) group-data-[side=left]:border-r group-data-[side=right]:border-l", className),
			...props,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"data-sidebar": "sidebar",
				className: "flex h-full w-full flex-col bg-sidebar group-data-[variant=floating]:rounded-lg group-data-[variant=floating]:border group-data-[variant=floating]:border-sidebar-border group-data-[variant=floating]:shadow",
				children
			})
		})]
	});
});
Sidebar.displayName = "Sidebar";
var SidebarTrigger = import_react.forwardRef(({ className, onClick, ...props }, ref) => {
	const { toggleSidebar } = useSidebar();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		ref,
		"data-sidebar": "trigger",
		variant: "ghost",
		size: "icon",
		className: cn("h-7 w-7", className),
		onClick: (event) => {
			onClick?.(event);
			toggleSidebar();
		},
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelLeft, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Toggle Sidebar"
		})]
	});
});
SidebarTrigger.displayName = "SidebarTrigger";
var SidebarRail = import_react.forwardRef(({ className, ...props }, ref) => {
	const { toggleSidebar } = useSidebar();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		ref,
		"data-sidebar": "rail",
		"aria-label": "Toggle Sidebar",
		tabIndex: -1,
		onClick: toggleSidebar,
		title: "Toggle Sidebar",
		className: cn("absolute inset-y-0 z-20 hidden w-4 -translate-x-1/2 transition-all ease-linear after:absolute after:inset-y-0 after:left-1/2 after:w-[2px] hover:after:bg-sidebar-border group-data-[side=left]:-right-4 group-data-[side=right]:left-0 sm:flex", "[[data-side=left]_&]:cursor-w-resize [[data-side=right]_&]:cursor-e-resize", "[[data-side=left][data-state=collapsed]_&]:cursor-e-resize [[data-side=right][data-state=collapsed]_&]:cursor-w-resize", "group-data-[collapsible=offcanvas]:translate-x-0 group-data-[collapsible=offcanvas]:after:left-full group-data-[collapsible=offcanvas]:hover:bg-sidebar", "[[data-side=left][data-collapsible=offcanvas]_&]:-right-2", "[[data-side=right][data-collapsible=offcanvas]_&]:-left-2", className),
		...props
	});
});
SidebarRail.displayName = "SidebarRail";
var SidebarInset = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		ref,
		className: cn("relative flex w-full flex-1 flex-col bg-background", "md:peer-data-[variant=inset]:m-2 md:peer-data-[state=collapsed]:peer-data-[variant=inset]:ml-2 md:peer-data-[variant=inset]:ml-0 md:peer-data-[variant=inset]:rounded-xl md:peer-data-[variant=inset]:shadow", className),
		...props
	});
});
SidebarInset.displayName = "SidebarInset";
var SidebarInput = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
		ref,
		"data-sidebar": "input",
		className: cn("h-8 w-full bg-background shadow-none focus-visible:ring-2 focus-visible:ring-sidebar-ring", className),
		...props
	});
});
SidebarInput.displayName = "SidebarInput";
var SidebarHeader = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		"data-sidebar": "header",
		className: cn("flex flex-col gap-2 p-2", className),
		...props
	});
});
SidebarHeader.displayName = "SidebarHeader";
var SidebarFooter = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		"data-sidebar": "footer",
		className: cn("flex flex-col gap-2 p-2", className),
		...props
	});
});
SidebarFooter.displayName = "SidebarFooter";
var SidebarSeparator = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {
		ref,
		"data-sidebar": "separator",
		className: cn("mx-2 w-auto bg-sidebar-border", className),
		...props
	});
});
SidebarSeparator.displayName = "SidebarSeparator";
var SidebarContent = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		"data-sidebar": "content",
		className: cn("flex min-h-0 flex-1 flex-col gap-2 overflow-auto group-data-[collapsible=icon]:overflow-hidden", className),
		...props
	});
});
SidebarContent.displayName = "SidebarContent";
var SidebarGroup = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		"data-sidebar": "group",
		className: cn("relative flex w-full min-w-0 flex-col p-2", className),
		...props
	});
});
SidebarGroup.displayName = "SidebarGroup";
var SidebarGroupLabel = import_react.forwardRef(({ className, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "div", {
		ref,
		"data-sidebar": "group-label",
		className: cn("flex h-8 shrink-0 items-center rounded-md px-2 text-xs font-medium text-sidebar-foreground/70 outline-none ring-sidebar-ring transition-[margin,opacity] duration-200 ease-linear focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0", "group-data-[collapsible=icon]:-mt-8 group-data-[collapsible=icon]:opacity-0", className),
		...props
	});
});
SidebarGroupLabel.displayName = "SidebarGroupLabel";
var SidebarGroupAction = import_react.forwardRef(({ className, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		ref,
		"data-sidebar": "group-action",
		className: cn("absolute right-3 top-3.5 flex aspect-square w-5 items-center justify-center rounded-md p-0 text-sidebar-foreground outline-none ring-sidebar-ring cursor-pointer transition-transform hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0", "after:absolute after:-inset-2 after:md:hidden", "group-data-[collapsible=icon]:hidden", className),
		...props
	});
});
SidebarGroupAction.displayName = "SidebarGroupAction";
var SidebarGroupContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	"data-sidebar": "group-content",
	className: cn("w-full text-sm", className),
	...props
}));
SidebarGroupContent.displayName = "SidebarGroupContent";
var SidebarMenu = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
	ref,
	"data-sidebar": "menu",
	className: cn("flex w-full min-w-0 flex-col gap-1", className),
	...props
}));
SidebarMenu.displayName = "SidebarMenu";
var SidebarMenuItem = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
	ref,
	"data-sidebar": "menu-item",
	className: cn("group/menu-item relative", className),
	...props
}));
SidebarMenuItem.displayName = "SidebarMenuItem";
var sidebarMenuButtonVariants = cva("peer/menu-button flex w-full items-center gap-2 overflow-hidden rounded-md p-2 text-left text-sm outline-none ring-sidebar-ring cursor-pointer transition-[width,height,padding] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed group-has-[[data-sidebar=menu-action]]/menu-item:pr-8 aria-disabled:pointer-events-none aria-disabled:opacity-50 data-[active=true]:bg-sidebar-accent data-[active=true]:font-medium data-[active=true]:text-sidebar-accent-foreground data-[state=open]:hover:bg-sidebar-accent data-[state=open]:hover:text-sidebar-accent-foreground group-data-[collapsible=icon]:!size-8 group-data-[collapsible=icon]:!p-2 [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0", {
	variants: {
		variant: {
			default: "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
			outline: "bg-background shadow-[0_0_0_1px_var(--sidebar-border)] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground hover:shadow-[0_0_0_1px_var(--sidebar-accent)]"
		},
		size: {
			default: "h-8 text-sm",
			sm: "h-7 text-xs",
			lg: "h-12 text-sm group-data-[collapsible=icon]:!p-0"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var SidebarMenuButton = import_react.forwardRef(({ asChild = false, isActive = false, variant = "default", size = "default", tooltip, className, ...props }, ref) => {
	const Comp = asChild ? Slot : "button";
	const { isMobile, state } = useSidebar();
	const button = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Comp, {
		ref,
		"data-sidebar": "menu-button",
		"data-size": size,
		"data-active": isActive,
		className: cn(sidebarMenuButtonVariants({
			variant,
			size
		}), className),
		...props
	});
	if (!tooltip) return button;
	if (typeof tooltip === "string") tooltip = { children: tooltip };
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
		asChild: true,
		children: button
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, {
		side: "right",
		align: "center",
		hidden: state !== "collapsed" || isMobile,
		...tooltip
	})] });
});
SidebarMenuButton.displayName = "SidebarMenuButton";
var SidebarMenuAction = import_react.forwardRef(({ className, asChild = false, showOnHover = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		ref,
		"data-sidebar": "menu-action",
		className: cn("absolute right-1 top-1.5 flex aspect-square w-5 items-center justify-center rounded-md p-0 text-sidebar-foreground outline-none ring-sidebar-ring cursor-pointer transition-transform hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 peer-hover/menu-button:text-sidebar-accent-foreground [&>svg]:size-4 [&>svg]:shrink-0", "after:absolute after:-inset-2 after:md:hidden", "peer-data-[size=sm]/menu-button:top-1", "peer-data-[size=default]/menu-button:top-1.5", "peer-data-[size=lg]/menu-button:top-2.5", "group-data-[collapsible=icon]:hidden", showOnHover && "group-focus-within/menu-item:opacity-100 group-hover/menu-item:opacity-100 data-[state=open]:opacity-100 peer-data-[active=true]/menu-button:text-sidebar-accent-foreground md:opacity-0", className),
		...props
	});
});
SidebarMenuAction.displayName = "SidebarMenuAction";
var SidebarMenuBadge = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	"data-sidebar": "menu-badge",
	className: cn("pointer-events-none absolute right-1 flex h-5 min-w-5 select-none items-center justify-center rounded-md px-1 text-xs font-medium tabular-nums text-sidebar-foreground", "peer-hover/menu-button:text-sidebar-accent-foreground peer-data-[active=true]/menu-button:text-sidebar-accent-foreground", "peer-data-[size=sm]/menu-button:top-1", "peer-data-[size=default]/menu-button:top-1.5", "peer-data-[size=lg]/menu-button:top-2.5", "group-data-[collapsible=icon]:hidden", className),
	...props
}));
SidebarMenuBadge.displayName = "SidebarMenuBadge";
var SidebarMenuSkeleton = import_react.forwardRef(({ className, showIcon = false, ...props }, ref) => {
	const width = import_react.useMemo(() => {
		return `${Math.floor(Math.random() * 40) + 50}%`;
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref,
		"data-sidebar": "menu-skeleton",
		className: cn("flex h-8 items-center gap-2 rounded-md px-2", className),
		...props,
		children: [showIcon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {
			className: "size-4 rounded-md",
			"data-sidebar": "menu-skeleton-icon"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {
			className: "h-4 max-w-(--skeleton-width) flex-1",
			"data-sidebar": "menu-skeleton-text",
			style: { "--skeleton-width": width }
		})]
	});
});
SidebarMenuSkeleton.displayName = "SidebarMenuSkeleton";
var SidebarMenuSub = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
	ref,
	"data-sidebar": "menu-sub",
	className: cn("mx-3.5 flex min-w-0 translate-x-px flex-col gap-1 border-l border-sidebar-border px-2.5 py-0.5", "group-data-[collapsible=icon]:hidden", className),
	...props
}));
SidebarMenuSub.displayName = "SidebarMenuSub";
var SidebarMenuSubItem = import_react.forwardRef(({ ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
	ref,
	...props
}));
SidebarMenuSubItem.displayName = "SidebarMenuSubItem";
var SidebarMenuSubButton = import_react.forwardRef(({ asChild = false, size = "md", isActive, className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "a", {
		ref,
		"data-sidebar": "menu-sub-button",
		"data-size": size,
		"data-active": isActive,
		className: cn("flex h-7 min-w-0 -translate-x-px items-center gap-2 overflow-hidden rounded-md px-2 text-sidebar-foreground outline-none ring-sidebar-ring cursor-pointer hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed aria-disabled:pointer-events-none aria-disabled:opacity-50 [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0 [&>svg]:text-sidebar-accent-foreground", "data-[active=true]:bg-sidebar-accent data-[active=true]:text-sidebar-accent-foreground", size === "sm" && "text-xs", size === "md" && "text-sm", "group-data-[collapsible=icon]:hidden", className),
		...props
	});
});
SidebarMenuSubButton.displayName = "SidebarMenuSubButton";
var MENU_ITEMS = [
	{
		key: "dashboard",
		label: "Dashboard",
		icon: LayoutDashboard,
		to: "/"
	},
	{
		key: "marketing",
		label: "Marketing",
		icon: Megaphone,
		items: [
			{
				to: "/marketing",
				label: "Marketing Dashboard"
			},
			{
				to: "/marketing/leads",
				label: "Leads"
			},
			{
				to: "/marketing/email-campaign",
				label: "Email Campaign"
			}
		]
	},
	{
		key: "sales",
		label: "Sales",
		icon: Briefcase,
		items: [
			{
				to: "/sales",
				label: "Sales Dashboard"
			},
			{
				to: "/sales/opportunities",
				label: "Opportunity"
			},
			{
				to: "/sales/quotations",
				label: "Quotation"
			}
		]
	},
	{
		key: "Order",
		label: "Order",
		icon: ClipboardList,
		items: [
			{
				to: "/order-dashboard",
				label: "Order Dashboard"
			},
			{
				to: "/final-offer",
				label: "Final Offer - FO"
			},
			{
				to: "/customer-po",
				label: "Customer PO - CPO"
			},
			{
				to: "/sales/orders",
				label: "Sales Order - SO"
			}
		]
	},
	{
		key: "Tasks",
		label: "Tasks",
		icon: ListChecks,
		items: [{
			to: "/tasks/dashboard",
			label: "Task Dashboard"
		}, {
			to: "/tasks",
			label: "Task List"
		}]
	},
	{
		key: "Masters",
		label: "Masters",
		icon: Database,
		items: [{
			to: "/company",
			label: "Company"
		}, {
			to: "/location",
			label: "Location"
		}]
	},
	{
		key: "User & Roles",
		label: "User & Roles",
		icon: ShieldCheck,
		items: [
			{
				to: "/user",
				label: "User"
			},
			{
				to: "/roles",
				label: "Roles"
			},
			{
				to: "/access-control",
				label: "Access Control"
			}
		]
	}
];
function AppSidebar() {
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	const isActive = (to) => pathname === to || pathname.startsWith(`${to}/`);
	const isParentActive = (items) => items?.some(({ to }) => isActive(to)) ?? false;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sidebar, {
		collapsible: "icon",
		className: "border-r border-sidebar-border",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarHeader, {
			className: "h-16 justify-center border-b border-white/10 px-5 group-data-[collapsible=icon]:px-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid size-8 place-items-center rounded-lg bg-brand font-display text-lg font-bold text-white",
					children: "V"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "leading-none group-data-[collapsible=icon]:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-display text-[15px] font-bold text-white",
						children: "Vantage"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 font-mono text-[10px] text-white/40",
						children: "CRM · OPS"
					})]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarGroup, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarGroupContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenu, { children: MENU_ITEMS.map((item) => {
			if (!(!!item.items && item.items.length > 0)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenuItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenuButton, {
				asChild: true,
				tooltip: item.label,
				isActive: item.to ? isActive(item.to) : false,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: item.to ?? "/",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.label })]
				})
			}) }, item.key);
			const parentActive = isParentActive(item.items);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Collapsible, {
				defaultOpen: parentActive,
				className: "group/collapsible",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SidebarMenuItem, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollapsibleTrigger, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SidebarMenuButton, {
						tooltip: item.label,
						isActive: parentActive,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.label }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "ml-auto h-4 w-4 transition-transform group-data-[state=open]/collapsible:rotate-180" })
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollapsibleContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenuSub, { children: item.items?.map((child) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenuSubItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenuSubButton, {
					asChild: true,
					isActive: isActive(child.to),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: child.to,
						children: child.label
					})
				}) }, child.to)) }) })] })
			}, item.key);
		}) }) }) }) })]
	});
}
var DropdownMenu = Root2$1;
var DropdownMenuTrigger = Trigger;
var DropdownMenuSubTrigger = import_react.forwardRef(({ className, inset, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SubTrigger2, {
	ref,
	className: cn("flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent data-[state=open]:bg-accent [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", inset && "pl-8", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "ml-auto" })]
}));
DropdownMenuSubTrigger.displayName = SubTrigger2.displayName;
var DropdownMenuSubContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubContent2, {
	ref,
	className: cn("z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-lg data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)", className),
	...props
}));
DropdownMenuSubContent.displayName = SubContent2.displayName;
var DropdownMenuContent = import_react.forwardRef(({ className, sideOffset = 4, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal2$1, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2$1, {
	ref,
	sideOffset,
	className: cn("z-50 max-h-[var(--radix-dropdown-menu-content-available-height)] min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md", "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)", className),
	...props
}) }));
DropdownMenuContent.displayName = Content2$1.displayName;
var DropdownMenuItem = import_react.forwardRef(({ className, inset, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item2, {
	ref,
	className: cn("relative flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&>svg]:size-4 [&>svg]:shrink-0", inset && "pl-8", className),
	...props
}));
DropdownMenuItem.displayName = Item2.displayName;
var DropdownMenuCheckboxItem = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CheckboxItem2, {
	ref,
	className: cn("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemIndicator2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }) })
	}), children]
}));
DropdownMenuCheckboxItem.displayName = CheckboxItem2.displayName;
var DropdownMenuRadioItem = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RadioItem2, {
	ref,
	className: cn("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemIndicator2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "h-2 w-2 fill-current" }) })
	}), children]
}));
DropdownMenuRadioItem.displayName = RadioItem2.displayName;
var DropdownMenuLabel = import_react.forwardRef(({ className, inset, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label2, {
	ref,
	className: cn("px-2 py-1.5 text-sm font-semibold", inset && "pl-8", className),
	...props
}));
DropdownMenuLabel.displayName = Label2.displayName;
var DropdownMenuSeparator = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator2, {
	ref,
	className: cn("-mx-1 my-1 h-px bg-muted", className),
	...props
}));
DropdownMenuSeparator.displayName = Separator2.displayName;
var DropdownMenuShortcut = ({ className, ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("ml-auto text-xs tracking-widest opacity-60", className),
		...props
	});
};
DropdownMenuShortcut.displayName = "DropdownMenuShortcut";
var Avatar = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar$1, {
	ref,
	className: cn("relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full", className),
	...props
}));
Avatar.displayName = Avatar$1.displayName;
var AvatarImage = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvatarImage$1, {
	ref,
	className: cn("aspect-square h-full w-full", className),
	...props
}));
AvatarImage.displayName = AvatarImage$1.displayName;
var AvatarFallback = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvatarFallback$1, {
	ref,
	className: cn("flex h-full w-full items-center justify-center rounded-full bg-muted", className),
	...props
}));
AvatarFallback.displayName = AvatarFallback$1.displayName;
function AppLayout() {
	const navigate = useNavigate();
	const { user, logout } = useAuth();
	const displayName = [user?.first_name, user?.last_name].filter(Boolean).join(" ") || user?.email || "Account";
	const initials = displayName.split(/\s+/).map((part) => part[0]).slice(0, 2).join("").toUpperCase();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen bg-background font-body text-foreground antialiased",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SidebarProvider, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppSidebar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SidebarInset, {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "sticky top-0 z-10 flex h-[74px] items-center justify-between border-b border-line bg-background/95 px-5 backdrop-blur sm:px-7",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 items-center gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarTrigger, { className: "size-8 shrink-0 rounded-md text-foreground hover:bg-surface" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-7 w-px bg-line",
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex min-w-0 items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid size-10 shrink-0 place-items-center rounded-[13px] bg-brand font-display text-xl font-bold text-white shadow-sm",
									children: "V"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "hidden min-w-0 leading-none sm:block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "truncate font-display text-sm font-bold tracking-tight text-foreground",
										children: "Vantage"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-1 font-mono text-[10px] font-medium tracking-[0.16em] text-muted-foreground",
										children: "CRM · OPS"
									})]
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "ghost",
							className: "relative size-10 rounded-full p-0 text-muted-foreground hover:bg-surface hover:text-foreground",
							"aria-label": "Open notifications",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-[18px]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute right-2 top-2 size-1.5 rounded-full bg-brand",
								"aria-hidden": "true"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								className: "size-10 rounded-full p-0 hover:bg-surface",
								"aria-label": "Open profile menu",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
									className: "size-9",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvatarFallback, {
										className: "bg-brand/15 text-sm font-semibold text-brand",
										children: initials || "A"
									})
								})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
							align: "end",
							className: "w-56",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuLabel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-medium",
									children: displayName
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs font-normal text-muted-foreground",
									children: user?.email
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
									onClick: () => {
										logout();
										navigate({ to: "/login" });
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { "data-icon": "inline-start" }), "Sign out"]
								})
							]
						})] })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "flex-1 p-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				position: "bottom-right",
				richColors: true
			})
		] })
	});
}
function AuthProvider({ children }) {
	const [{ user, status }, setAuthState] = Recoil_index_22(authStateAtom);
	(0, import_react.useEffect)(() => {
		if (!hasAuthTokens()) {
			(0, import_react.startTransition)(() => {
				setAuthState({
					user: null,
					status: "anonymous"
				});
			});
			return;
		}
		let active = true;
		getCurrentUser().then((currentUser) => {
			if (!active) return;
			setAuthState({
				user: currentUser,
				status: "authenticated"
			});
		}).catch(() => {
			if (!active) return;
			clearAuthTokens();
			setAuthState({
				user: null,
				status: "anonymous"
			});
		});
		return () => {
			active = false;
		};
	}, [setAuthState]);
	async function login(email, password) {
		const currentUser = await loginUser(email, password);
		setAuthState({
			user: currentUser,
			status: "authenticated"
		});
	}
	async function register(data) {
		const currentUser = await registerUser(data);
		setAuthState({
			user: currentUser,
			status: "authenticated"
		});
	}
	async function logout() {
		try {
			await logoutUser();
		} catch {
			clearAuthTokens();
		} finally {
			setAuthState({
				user: null,
				status: "anonymous"
			});
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthContext.Provider, {
		value: {
			user,
			status,
			login,
			register,
			logout
		},
		children
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-brand px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-brand/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	const exactError = error instanceof Response ? `HTTP ${error.status}${error.statusText ? ` ${error.statusText}` : ""}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? `${error.name}: ${error.message}` : String(error);
	const technicalDetails = error instanceof Error ? error.stack : void 0;
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-screen w-full max-w-4xl flex-col justify-center gap-5 bg-background px-5 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs uppercase text-destructive",
					children: "Application error"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 text-2xl font-semibold text-foreground",
					children: "This page could not load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The exact error is shown below. Share it with support if you need help."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "max-h-48 overflow-auto whitespace-pre-wrap break-words rounded-md border border-destructive/30 bg-destructive/5 p-4 font-mono text-sm text-foreground",
				role: "alert",
				children: exactError || "No error message was provided."
			}),
			technicalDetails && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "rounded-md border border-border p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
					className: "cursor-pointer text-sm font-medium",
					children: "Technical details"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "mt-3 max-h-72 overflow-auto whitespace-pre-wrap break-words font-mono text-xs text-muted-foreground",
					children: technicalDetails
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => {
						router.invalidate();
						reset();
					},
					className: "inline-flex items-center justify-center rounded-md bg-brand px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-brand/90",
					children: "Try again"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "/",
					className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
					children: "Go home"
				})]
			})
		]
	});
}
var Route$23 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Vantage —  CRM" },
			{
				name: "description",
				content: "Manage leads, email templates, sequences, and campaigns in one clean CRM."
			},
			{
				property: "og:title",
				content: "Vantage — Email Campaign CRM"
			},
			{
				property: "og:description",
				content: "Manage leads, email templates, sequences, and campaigns in one clean CRM."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "/favicon.ico",
				type: "image/x-icon"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$23.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Recoil_index_5, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RootContent, {}) }) })
	});
}
function RootContent() {
	const navigate = useNavigate();
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	const { status } = useAuth();
	const isAuthRoute = pathname === "/login" || pathname === "/register";
	(0, import_react.useEffect)(() => {
		if (status === "anonymous" && !isAuthRoute) navigate({
			to: "/login",
			replace: true
		});
		else if (status === "authenticated" && isAuthRoute) navigate({
			to: "/",
			replace: true
		});
	}, [
		isAuthRoute,
		navigate,
		status
	]);
	if (isAuthRoute) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {});
	if (status !== "authenticated") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-screen place-items-center bg-background text-sm text-muted-foreground",
		role: "status",
		children: "Checking your session…"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppLayout, {});
}
var $$splitComponentImporter$17 = () => import("./routes-DR_2v1sB.mjs");
var Route$22 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "Dashboard — Vantage CRM" },
		{
			name: "description",
			content: "Overall overview of marketing and sales in Vantage CRM."
		},
		{
			property: "og:title",
			content: "Dashboard — Vantage CRM"
		},
		{
			property: "og:description",
			content: "Overall overview of marketing and sales in Vantage CRM."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$17, "component")
});
async function listUsers() {
	const response = await request("/auth/users/");
	return Array.isArray(response) ? response : response.results;
}
function createUser(data) {
	return request("/auth/users/", {
		method: "POST",
		body: JSON.stringify(data)
	});
}
function updateUser(id, data) {
	return request(`/auth/users/${id}/`, {
		method: "PATCH",
		body: JSON.stringify(data)
	});
}
function deleteUser(id) {
	return request(`/auth/users/${id}/`, { method: "DELETE" });
}
async function listRoles() {
	const response = await request("/auth/roles/");
	return Array.isArray(response) ? response : response.results;
}
function createRole(data) {
	return request("/auth/roles/", {
		method: "POST",
		body: JSON.stringify(data)
	});
}
function updateRole(id, data) {
	return request(`/auth/roles/${id}/`, {
		method: "PATCH",
		body: JSON.stringify(data)
	});
}
function deleteRole(id) {
	return request(`/auth/roles/${id}/`, { method: "DELETE" });
}
async function listModules() {
	const response = await request("/auth/modules/");
	return Array.isArray(response) ? response : response.results;
}
async function listRolePermissions() {
	const response = await request("/auth/role-permissions/");
	return Array.isArray(response) ? response : response.results;
}
function createRolePermission(data) {
	return request("/auth/role-permissions/", {
		method: "POST",
		body: JSON.stringify(data)
	});
}
function updateRolePermission(id, data) {
	return request(`/auth/role-permissions/${id}/`, {
		method: "PATCH",
		body: JSON.stringify(data)
	});
}
function slugify$1(value) {
	return value.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}
function RoleFormDialog({ open, onOpenChange, role = null, onSaved }) {
	const [name, setName] = import_react.useState("");
	const [code, setCode] = import_react.useState("");
	const [codeEdited, setCodeEdited] = import_react.useState(false);
	const [saving, setSaving] = import_react.useState(false);
	const [error, setError] = import_react.useState("");
	import_react.useEffect(() => {
		setName(role?.name ?? "");
		setCode(role?.code ?? "");
		setCodeEdited(Boolean(role));
		setError("");
	}, [open, role]);
	async function handleSubmit(event) {
		event.preventDefault();
		setError("");
		const trimmedName = name.trim();
		const trimmedCode = code.trim();
		if (!trimmedName || !trimmedCode) {
			setError("Enter both a role name and code.");
			return;
		}
		setSaving(true);
		try {
			await onSaved(role ? await updateRole(role.id, {
				name: trimmedName,
				code: trimmedCode
			}) : await createRole({
				name: trimmedName,
				code: trimmedCode
			}));
			onOpenChange(false);
			toast.success(role ? "Role updated." : "Role created.");
		} catch (saveError) {
			setError(saveError instanceof Error ? saveError.message : "Could not save role.");
		} finally {
			setSaving(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog$1, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
			className: "sm:max-w-md",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, { children: role ? "Edit role" : "Create role" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, { children: role ? "Update this role's name and unique code." : "Create a role that can be assigned access permissions." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: handleSubmit,
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1.5 text-sm font-medium",
						children: ["Role name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							autoFocus: true,
							required: true,
							maxLength: 50,
							placeholder: "e.g. Sales Manager",
							value: name,
							onChange: (event) => {
								const nextName = event.target.value;
								setName(nextName);
								if (!codeEdited) setCode(slugify$1(nextName));
							}
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1.5 text-sm font-medium",
						children: [
							"Role code",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								required: true,
								maxLength: 50,
								placeholder: "e.g. sales-manager",
								value: code,
								onChange: (event) => {
									setCodeEdited(true);
									setCode(event.target.value.toLowerCase().replace(/[^a-z0-9-]+/g, "-"));
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs font-normal text-muted-foreground",
								children: "Unique identifier used by the system."
							})
						]
					}),
					error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "alert",
						className: "text-sm text-destructive",
						children: error
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						onClick: () => onOpenChange(false),
						disabled: saving,
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: saving,
						children: saving ? "Saving…" : role ? "Save changes" : "Create role"
					})] })
				]
			})]
		})
	});
}
var badgeVariants = cva("inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2", {
	variants: { variant: {
		default: "border-transparent bg-primary text-primary-foreground shadow hover:bg-primary/80",
		secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
		destructive: "border-transparent bg-destructive text-destructive-foreground shadow hover:bg-destructive/80",
		outline: "text-foreground"
	} },
	defaultVariants: { variant: "default" }
});
function Badge$1({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var Card = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("rounded-xl border bg-card text-card-foreground shadow", className),
	...props
}));
Card.displayName = "Card";
var CardHeader = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("flex flex-col space-y-1.5 p-6", className),
	...props
}));
CardHeader.displayName = "CardHeader";
var CardTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("font-semibold leading-none tracking-tight", className),
	...props
}));
CardTitle.displayName = "CardTitle";
var CardDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
CardDescription.displayName = "CardDescription";
var CardContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("p-6 pt-0", className),
	...props
}));
CardContent.displayName = "CardContent";
var CardFooter = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("flex items-center p-6 pt-0", className),
	...props
}));
CardFooter.displayName = "CardFooter";
var Route$21 = createFileRoute("/access-control")({
	head: () => ({ meta: [{ title: "Access Control — Vantage CRM" }, {
		name: "description",
		content: "Configure role permissions in Vantage CRM."
	}] }),
	validateSearch: (search) => ({ roleId: typeof search.roleId === "number" && Number.isInteger(search.roleId) ? search.roleId : void 0 }),
	component: AccessControlPage
});
var PERMISSION_COLUMNS = [{
	field: "can_view",
	label: "View"
}, {
	field: "can_create",
	label: "Create"
}];
function AccessControlPage() {
	const { roleId } = Route$21.useSearch();
	const [roles, setRoles] = import_react.useState([]);
	const [modules, setModules] = import_react.useState([]);
	const [permissions, setPermissions] = import_react.useState([]);
	const [selectedRoleId, setSelectedRoleId] = import_react.useState(roleId ?? null);
	const [loading, setLoading] = import_react.useState(true);
	const [error, setError] = import_react.useState("");
	const [roleDialogOpen, setRoleDialogOpen] = import_react.useState(false);
	const loadData = import_react.useCallback(async () => {
		setLoading(true);
		setError("");
		try {
			const [roleList, moduleList, permissionList] = await Promise.all([
				listRoles(),
				listModules(),
				listRolePermissions()
			]);
			setRoles(roleList);
			setModules(moduleList);
			setPermissions(permissionList);
		} catch (loadError) {
			const message = loadError instanceof Error ? loadError.message : "Unable to load access control.";
			setError(message);
			toast.error(message);
		} finally {
			setLoading(false);
		}
	}, []);
	import_react.useEffect(() => {
		loadData();
	}, [loadData]);
	import_react.useEffect(() => {
		if (roleId !== void 0) setSelectedRoleId(roleId);
	}, [roleId]);
	import_react.useEffect(() => {
		if (loading) return;
		if (roles.length === 0) setSelectedRoleId(null);
		else if (selectedRoleId === null || !roles.some((role) => role.id === selectedRoleId)) setSelectedRoleId(roles[0].id);
	}, [
		loading,
		roles,
		selectedRoleId
	]);
	const selectedRole = roles.find((role) => role.id === selectedRoleId) ?? roles[0] ?? null;
	const permissionMap = import_react.useMemo(() => {
		const map = /* @__PURE__ */ new Map();
		for (const permission of permissions) map.set(`${permission.role}:${permission.module}`, permission);
		return map;
	}, [permissions]);
	const handleRoleSaved = import_react.useCallback(async (role) => {
		setSelectedRoleId(role.id);
		await loadData();
	}, [loadData]);
	const handleToggle = import_react.useCallback(async (module, field, checked) => {
		if (!selectedRole) return;
		const key = `${selectedRole.id}:${module.id}`;
		const existing = permissionMap.get(key);
		const payload = {
			role: selectedRole.id,
			module: module.id,
			can_view: existing?.can_view ?? false,
			can_create: existing?.can_create ?? false,
			can_edit: existing?.can_edit ?? false,
			can_delete: existing?.can_delete ?? false
		};
		payload[field] = checked;
		try {
			if (existing) await updateRolePermission(existing.id, payload);
			else await createRolePermission(payload);
			await loadData();
		} catch (toggleError) {
			toast.error(toggleError instanceof Error ? toggleError.message : "Could not update permission.");
		}
	}, [
		loadData,
		permissionMap,
		selectedRole
	]);
	if (!loading && roles.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-mono text-[11px] tracking-wide text-muted-foreground",
				children: "USER & ROLES"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-3xl font-bold",
				children: "Access control"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "p-6 text-sm text-muted-foreground",
				children: ["No roles exist yet. Create one to begin managing permissions.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => setRoleDialogOpen(true),
						children: "Create first role"
					})
				})]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleFormDialog, {
				open: roleDialogOpen,
				onOpenChange: setRoleDialogOpen,
				onSaved: handleRoleSaved
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-7",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col justify-between gap-4 sm:flex-row sm:items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-mono text-[11px] tracking-wide text-muted-foreground",
						children: "USER & ROLES"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-display text-3xl font-bold",
						children: "Access control"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: "Define what each role can see and do across Vantage."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => setRoleDialogOpen(true),
					children: "Create role"
				})]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				role: "alert",
				className: "rounded-lg border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive",
				children: [error, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					className: "ml-3",
					onClick: () => void loadData(),
					children: "Retry"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-6 xl:grid-cols-[280px_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "h-fit",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Roles" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: "Choose a role to configure." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "flex flex-col gap-2",
						children: [
							roles.map((role) => {
								const count = permissions.filter((permission) => permission.role === role.id).length;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleButton, {
									icon: role.name.toLowerCase().includes("admin") ? Shield : Users,
									label: role.name,
									count: count === 0 ? "No permissions" : `${count} permission${count === 1 ? "" : "s"}`,
									active: selectedRole?.id === role.id,
									onClick: () => setSelectedRoleId(role.id)
								}, role.id);
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, { className: "my-2" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								className: "justify-start",
								onClick: () => setRoleDialogOpen(true),
								children: "+ Create custom role"
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: selectedRole?.name ?? "Role" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge$1, { children: "Role" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, {
						className: "mt-1",
						children: "Configure access permissions for this role."
					})] })
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-[460px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-[minmax(220px,1.6fr)_repeat(2,110px)] items-center border-b bg-muted/30 px-4 py-3 text-xs font-medium text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Module" }), PERMISSION_COLUMNS.map((column) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-center",
								children: column.label
							}, column.field))]
						}), loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "px-4 py-8 text-center text-sm text-muted-foreground",
							children: "Loading access settings…"
						}) : modules.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "px-4 py-8 text-center text-sm text-muted-foreground",
							children: "No modules are configured yet."
						}) : modules.map((module) => {
							const record = selectedRole ? permissionMap.get(`${selectedRole.id}:${module.id}`) : null;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-[minmax(220px,1.6fr)_repeat(2,110px)] items-center border-b px-4 py-4 last:border-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium",
									children: module.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted-foreground",
									children: module.code
								})] }), PERMISSION_COLUMNS.map(({ field, label }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex justify-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
										checked: Boolean(record?.[field]),
										onCheckedChange: (checked) => void handleToggle(module, field, checked),
										"aria-label": `${module.name} ${label}`
									})
								}, `${module.id}-${field}`))]
							}, module.id);
						})]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex items-center justify-between rounded-lg bg-brand-soft px-4 py-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: selectedRole ? permissions.filter((permission) => permission.role === selectedRole.id).length : 0 }),
						" ",
						"permission rows configured"
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-2 text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockKeyhole, { className: "size-4" }), " Role-based access"]
					})]
				})] })] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleFormDialog, {
				open: roleDialogOpen,
				onOpenChange: setRoleDialogOpen,
				onSaved: handleRoleSaved
			})
		]
	});
}
function RoleButton({ icon: Icon, label, count, active = false, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: `flex items-center gap-3 rounded-lg px-3 py-3 text-left transition-colors ${active ? "bg-brand-soft text-brand" : "hover:bg-muted"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block truncate text-sm font-medium",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-xs text-muted-foreground",
					children: count
				})]
			}),
			active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "size-2 rounded-full bg-brand",
				"aria-hidden": "true"
			})
		]
	});
}
var $$splitComponentImporter$16 = () => import("./company-3Fhs6Lcn.mjs");
var Route$20 = createFileRoute("/company")({ component: lazyRouteComponent($$splitComponentImporter$16, "component") });
var $$splitComponentImporter$15 = () => import("./country-Bhbs4eus.mjs");
var Route$19 = createFileRoute("/country")({ component: lazyRouteComponent($$splitComponentImporter$15, "component") });
var $$splitComponentImporter$14 = () => import("./customer-po-C5V1FZka.mjs");
var Route$18 = createFileRoute("/customer-po")({
	head: () => ({ meta: [{ title: "Customer Purchase Orders — Vantage CRM" }, {
		name: "description",
		content: "Review quotations marked for customer purchase order processing."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./final-offer-wWW4DgYR.mjs");
var Route$17 = createFileRoute("/final-offer")({
	head: () => ({ meta: [
		{ title: "Final Offer — Vantage CRM" },
		{
			name: "description",
			content: "Review and manage final offers generated from approved quotations."
		},
		{
			property: "og:title",
			content: "Final Offer — Vantage CRM"
		},
		{
			property: "og:description",
			content: "Review and manage final offers generated from approved quotations."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./login-Cl28LaIz.mjs");
var Route$16 = createFileRoute("/login")({
	head: () => ({ meta: [{ title: "Sign in — Vantage CRM" }] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./marketing-BpGbMazo.mjs");
var Route$15 = createFileRoute("/marketing")({
	head: () => ({ meta: [
		{ title: "Marketing Dashboard — Vantage CRM" },
		{
			name: "description",
			content: "Marketing leads, campaigns, and email activity in one dashboard."
		},
		{
			property: "og:title",
			content: "Marketing Dashboard — Vantage CRM"
		},
		{
			property: "og:description",
			content: "Marketing leads, campaigns, and email activity in one dashboard."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./order-dashboard-Cy-T8Yl-.mjs");
var Route$14 = createFileRoute("/order-dashboard")({
	head: () => ({ meta: [{ title: "Order Dashboard — Vantage CRM" }, {
		name: "description",
		content: "Track quotation-to-sales-order performance."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./register-DGC5h2Sj.mjs");
var Route$13 = createFileRoute("/register")({
	head: () => ({ meta: [{ title: "Create account — Vantage CRM" }] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var Route$12 = createFileRoute("/roles")({
	head: () => ({ meta: [{ title: "Roles — Vantage CRM" }] }),
	component: RolesPage
});
function slugify(value) {
	return value.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "role";
}
function RolesPage() {
	const [roles, setRoles] = import_react.useState([]);
	const [permissionCounts, setPermissionCounts] = import_react.useState({});
	const [loading, setLoading] = import_react.useState(true);
	const [error, setError] = import_react.useState("");
	const [createOpen, setCreateOpen] = import_react.useState(false);
	const [newName, setNewName] = import_react.useState("");
	const [creating, setCreating] = import_react.useState(false);
	const [roleToDelete, setRoleToDelete] = import_react.useState(null);
	const [deleting, setDeleting] = import_react.useState(false);
	const loadData = import_react.useCallback(async () => {
		setLoading(true);
		setError("");
		try {
			const [roleList, permissionList] = await Promise.all([listRoles(), listRolePermissions()]);
			const counts = {};
			for (const permission of permissionList) counts[permission.role] = (counts[permission.role] ?? 0) + 1;
			setRoles(roleList);
			setPermissionCounts(counts);
		} catch (loadError) {
			const message = loadError instanceof Error ? loadError.message : "Unable to load roles.";
			setError(message);
			toast.error(message);
		} finally {
			setLoading(false);
		}
	}, []);
	import_react.useEffect(() => {
		loadData();
	}, [loadData]);
	const trimmedName = newName.trim();
	const generatedCode = slugify(trimmedName);
	const isDuplicate = roles.some((role) => role.code === generatedCode || role.name.trim().toLowerCase() === trimmedName.toLowerCase());
	const nameError = trimmedName && isDuplicate ? "A role with this name already exists." : "";
	const openCreate = () => {
		setNewName("");
		setCreateOpen(true);
	};
	const handleCreateRole = async (event) => {
		event.preventDefault();
		if (!trimmedName || isDuplicate || creating) return;
		setCreating(true);
		try {
			await createRole({
				name: trimmedName,
				code: generatedCode
			});
			toast.success("Role created.");
			setCreateOpen(false);
			await loadData();
		} catch (createError) {
			toast.error(createError instanceof Error ? createError.message : "Could not create role.");
		} finally {
			setCreating(false);
		}
	};
	const handleDeleteRole = async () => {
		if (!roleToDelete || deleting) return;
		setDeleting(true);
		try {
			await deleteRole(roleToDelete.id);
			toast.success("Role deleted.");
			setRoleToDelete(null);
			await loadData();
		} catch (deleteError) {
			toast.error(deleteError instanceof Error ? deleteError.message : "Could not delete role.");
		} finally {
			setDeleting(false);
		}
	};
	const showSkeleton = loading && roles.length === 0;
	const showEmpty = !loading && !error && roles.length === 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex w-full max-w-7xl flex-col gap-6 sm:gap-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium text-muted-foreground",
							children: "Users & roles"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-1 font-display text-2xl font-bold sm:text-3xl",
							children: "Roles"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-prose text-sm text-muted-foreground",
							children: "Create reusable permission sets, then assign them to people in your workspace."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: openCreate,
					className: "w-full sm:w-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { "data-icon": "inline-start" }), " Create role"]
				})]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				role: "alert",
				className: "flex flex-col gap-3 rounded-lg border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "mt-0.5 size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "break-words",
						children: error
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => void loadData(),
					disabled: loading,
					className: "w-full sm:w-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
						className: loading ? "animate-spin" : "",
						"data-icon": "inline-start"
					}), " Try again"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3",
				"aria-busy": loading,
				children: [
					showSkeleton && Array.from({ length: 3 }).map((_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "size-10 rounded-xl" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "mt-3 h-5 w-2/3" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-1/3" })
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-9 w-full" }) })] }, index)),
					showEmpty && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "col-span-full flex flex-col items-center gap-3 rounded-lg border border-dashed px-6 py-12 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid size-12 place-items-center rounded-xl bg-brand-soft text-brand",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-6" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: "No roles yet"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: "Create your first role to start granting permissions."
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: openCreate,
								className: "w-full sm:w-auto",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { "data-icon": "inline-start" }), " Create role"]
							})
						]
					}),
					roles.map((role) => {
						const permissionCount = permissionCounts[role.id] ?? 0;
						const permissionsLabel = permissionCount === 0 ? "No permissions" : `${permissionCount} permission${permissionCount === 1 ? "" : "s"}`;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "flex flex-col transition-shadow focus-within:shadow-md hover:shadow-md",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid size-10 shrink-0 place-items-center rounded-xl bg-brand-soft text-brand",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-5" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										size: "icon",
										className: "-mr-2 -mt-1 size-10 text-muted-foreground hover:text-destructive sm:size-8 sm:mr-0 sm:mt-0",
										"aria-label": `Delete ${role.name}`,
										onClick: () => setRoleToDelete(role),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
									className: "truncate pt-2",
									title: role.name,
									children: role.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, {
									className: "truncate font-mono text-xs",
									title: role.code,
									children: role.code
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
								className: "mt-auto",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center justify-between gap-x-3 gap-y-2 border-t pt-4 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge$1, {
										variant: permissionCount === 0 ? "outline" : "secondary",
										className: "gap-1.5 font-normal",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-3.5" }), permissionsLabel]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/access-control",
										search: { roleId: role.id },
										className: "inline-flex min-h-10 items-center gap-1 rounded-md px-1 font-medium text-brand hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:min-h-0",
										children: ["Manage access", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
									})]
								})
							})]
						}, role.id);
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog$1, {
				open: createOpen,
				onOpenChange: (open) => !creating && setCreateOpen(open),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent$1, {
					className: "w-[calc(100%-2rem)] sm:max-w-md",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleCreateRole,
						className: "flex flex-col gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, { children: "Create role" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, { children: "Name the role. You can set its permissions next." })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "role-name",
										children: "Role name"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "role-name",
										value: newName,
										onChange: (event) => setNewName(event.target.value),
										placeholder: "e.g. Sales manager",
										autoComplete: "off",
										autoFocus: true,
										maxLength: 60,
										"aria-invalid": Boolean(nameError),
										"aria-describedby": "role-name-hint"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										id: "role-name-hint",
										className: nameError ? "text-xs text-destructive" : "text-xs text-muted-foreground",
										children: nameError || (trimmedName ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Code: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono",
											children: generatedCode
										})] }) : "The code is generated from the name.")
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
								className: "flex-col-reverse gap-2 sm:flex-row",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "outline",
									onClick: () => setCreateOpen(false),
									disabled: creating,
									className: "w-full sm:w-auto",
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "submit",
									disabled: !trimmedName || isDuplicate || creating,
									className: "w-full sm:w-auto",
									children: [creating && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
										className: "animate-spin",
										"data-icon": "inline-start"
									}), creating ? "Creating…" : "Create role"]
								})]
							})
						]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog$1, {
				open: roleToDelete !== null,
				onOpenChange: (open) => !open && !deleting && setRoleToDelete(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
					className: "w-[calc(100%-2rem)] sm:max-w-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle$1, { children: [
						"Delete “",
						roleToDelete?.name,
						"”?"
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, { children: "This removes the role and its permission settings. This can’t be undone." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
						className: "flex-col-reverse gap-2 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setRoleToDelete(null),
							disabled: deleting,
							className: "w-full sm:w-auto",
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "destructive",
							onClick: () => void handleDeleteRole(),
							disabled: deleting,
							className: "w-full sm:w-auto",
							children: [deleting && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
								className: "animate-spin",
								"data-icon": "inline-start"
							}), deleting ? "Deleting…" : "Delete role"]
						})]
					})]
				})
			})
		]
	});
}
var $$splitComponentImporter$8 = () => import("./tasks-n-0mlVeX.mjs");
var Route$11 = createFileRoute("/tasks")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var emptyForm = {
	username: "",
	email: "",
	first_name: "",
	last_name: "",
	role: "",
	is_active: true,
	password: ""
};
function UserFormDialog({ open, onOpenChange, user, onSaved }) {
	const [form, setForm] = (0, import_react.useState)(emptyForm);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		setForm(user ? {
			username: user.username,
			email: user.email,
			first_name: user.first_name,
			last_name: user.last_name,
			role: user.role === null ? "" : String(user.role),
			is_active: user.is_active,
			password: ""
		} : emptyForm);
		setError("");
	}, [open, user]);
	function updateField(key, value) {
		setForm((current) => ({
			...current,
			[key]: value
		}));
	}
	async function handleSubmit(event) {
		event.preventDefault();
		setError("");
		const role = form.role.trim() ? Number(form.role) : null;
		if (role !== null && (!Number.isInteger(role) || role < 1)) {
			setError("Enter a valid role ID or leave the field blank.");
			return;
		}
		const data = {
			username: form.username.trim(),
			email: form.email.trim(),
			first_name: form.first_name.trim(),
			last_name: form.last_name.trim(),
			role,
			is_active: form.is_active
		};
		if (!user || form.password) data.password = form.password;
		setSaving(true);
		try {
			if (user) await updateUser(user.id, data);
			else await createUser(data);
			await onSaved();
			onOpenChange(false);
			toast.success(user ? "User updated." : "User created.");
		} catch (submitError) {
			setError(submitError instanceof Error ? submitError.message : "Could not save user.");
		} finally {
			setSaving(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog$1, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
			className: "sm:max-w-xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, { children: user ? "Edit user" : "Add user" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, { children: user ? "Update account details or set a new password." : "Create a user account." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: handleSubmit,
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm font-medium",
								children: ["Username", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									required: true,
									maxLength: 150,
									autoComplete: "username",
									value: form.username,
									onChange: (event) => updateField("username", event.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm font-medium",
								children: ["Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "email",
									required: true,
									autoComplete: "email",
									value: form.email,
									onChange: (event) => updateField("email", event.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm font-medium",
								children: ["First name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									maxLength: 30,
									autoComplete: "given-name",
									value: form.first_name,
									onChange: (event) => updateField("first_name", event.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm font-medium",
								children: ["Last name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									maxLength: 30,
									autoComplete: "family-name",
									value: form.last_name,
									onChange: (event) => updateField("last_name", event.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm font-medium",
								children: [
									"Password",
									" ",
									user && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-normal text-muted-foreground",
										children: "(optional)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "password",
										required: !user,
										autoComplete: "new-password",
										value: form.password,
										onChange: (event) => updateField("password", event.target.value)
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm font-medium",
								children: [
									"Role ID ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-normal text-muted-foreground",
										children: "(optional)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										min: 1,
										step: 1,
										inputMode: "numeric",
										value: form.role,
										onChange: (event) => updateField("role", event.target.value)
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm font-medium",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: form.is_active,
							onChange: (event) => updateField("is_active", event.target.checked),
							className: "size-4 rounded border-input accent-primary"
						}), "Account is active"]
					}),
					error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "alert",
						className: "text-sm text-destructive",
						children: error
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						onClick: () => onOpenChange(false),
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: saving,
						children: saving ? "Saving…" : user ? "Save changes" : "Create user"
					})] })
				]
			})]
		})
	});
}
var Route$10 = createFileRoute("/user")({
	head: () => ({ meta: [{ title: "Users — Vantage CRM" }, {
		name: "description",
		content: "Manage Vantage CRM users and roles."
	}] }),
	component: UsersPage
});
var SEARCH_KEYS = [
	"username",
	"email",
	"first_name",
	"last_name"
];
function UsersPage() {
	const [users, setUsers] = import_react.useState([]);
	const [loading, setLoading] = import_react.useState(true);
	const [loadError, setLoadError] = import_react.useState("");
	const [formOpen, setFormOpen] = import_react.useState(false);
	const [editing, setEditing] = import_react.useState(null);
	const [deleting, setDeleting] = import_react.useState(null);
	const [deletePending, setDeletePending] = import_react.useState(false);
	const refresh = import_react.useCallback(async () => {
		setLoading(true);
		setLoadError("");
		try {
			setUsers(await listUsers());
		} catch (error) {
			const message = error instanceof Error ? error.message : "Could not load users.";
			setLoadError(message);
			toast.error(message);
		} finally {
			setLoading(false);
		}
	}, []);
	import_react.useEffect(() => {
		refresh();
	}, [refresh]);
	const openForm = import_react.useCallback((user = null) => {
		setEditing(user);
		setFormOpen(true);
	}, []);
	const confirmDelete = import_react.useCallback(async () => {
		if (!deleting) return;
		setDeletePending(true);
		try {
			await deleteUser(deleting.id);
			toast.success("User deleted.");
			setDeleting(null);
			await refresh();
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Could not delete user.");
		} finally {
			setDeletePending(false);
		}
	}, [deleting, refresh]);
	const columns = import_react.useMemo(() => [
		{
			key: "username",
			header: "User",
			cell: (user) => {
				const fullName = [user.first_name, user.last_name].filter(Boolean).join(" ");
				const initials = (fullName || user.username).split(/[\s@._-]+/).filter(Boolean).map((part) => part[0]).join("").slice(0, 2).toUpperCase();
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
						className: "size-9",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvatarFallback, {
							className: "bg-brand-soft text-xs font-semibold text-brand",
							children: initials
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "truncate font-medium",
							children: fullName || user.username
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "truncate text-xs text-muted-foreground",
							children: [fullName ? `@${user.username} · ` : "", user.email]
						})]
					})]
				});
			}
		},
		{
			key: "role",
			header: "Role",
			filterValue: (user) => user.role === null ? "Unassigned" : `Role #${user.role}`,
			cell: (user) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge$1, {
				variant: "outline",
				className: "font-normal",
				children: user.role === null ? "Unassigned" : `Role #${user.role}`
			})
		},
		{
			key: "is_active",
			header: "Status",
			filterValue: (user) => user.is_active ? "Active" : "Inactive",
			cell: (user) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge$1, {
				variant: user.is_active ? "default" : "secondary",
				children: user.is_active ? "Active" : "Inactive"
			})
		},
		{
			key: "actions",
			header: "",
			className: "w-20",
			cell: (user) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-end gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					className: "size-8",
					"aria-label": `Edit ${user.username}`,
					onClick: () => openForm(user),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					className: "size-8 text-destructive hover:text-destructive",
					"aria-label": `Delete ${user.username}`,
					onClick: () => setDeleting(user),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
				})]
			})
		}
	], [openForm]);
	const activeCount = users.filter((user) => user.is_active).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-7",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col justify-between gap-4 sm:flex-row sm:items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-mono text-[11px] tracking-wide text-muted-foreground",
						children: "USER & ROLES"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-display text-3xl font-bold",
						children: "Users"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: "Manage people and workspace access."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => openForm(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { "data-icon": "inline-start" }), " Add user"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "flex items-center gap-3 p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid size-10 place-items-center rounded-xl bg-brand-soft text-brand",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "TOTAL USERS"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl font-bold",
						children: loading ? "—" : users.length
					})] })]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "flex items-center gap-3 p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid size-10 place-items-center rounded-xl bg-good/10 text-good",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "ACTIVE USERS"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl font-bold",
						children: loading ? "—" : activeCount
					})] })]
				}) })]
			}),
			loadError && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				role: "alert",
				className: "flex flex-wrap items-center justify-between gap-3 rounded-lg border border-destructive/30 bg-destructive/5 p-4 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: loadError }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => void refresh(),
					children: "Retry"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				data: users,
				columns,
				searchKeys: SEARCH_KEYS,
				searchPlaceholder: "Search users",
				emptyMessage: loading ? "Loading users…" : loadError ? "Users could not be loaded." : "No users found.",
				pageSize: 10,
				storageKey: "vantage-users"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserFormDialog, {
				open: formOpen,
				onOpenChange: setFormOpen,
				user: editing,
				onSaved: refresh
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: deleting !== null,
				onClose: () => setDeleting(null),
				onConfirm: () => void confirmDelete(),
				title: "Delete user",
				message: `Delete ${deleting?.username ?? "this user"}? This action cannot be undone.`,
				loading: deletePending
			})
		]
	});
}
var $$splitComponentImporter$7 = () => import("./email-campaign-DLLAYQXK.mjs");
var Route$9 = createFileRoute("/marketing/email-campaign")({
	head: () => ({ meta: [
		{ title: "Email Campaign — Vantage CRM" },
		{
			name: "description",
			content: "Campaigns, email templates, sequences and logs in one place."
		},
		{
			property: "og:title",
			content: "Email Campaign — Vantage CRM"
		},
		{
			property: "og:description",
			content: "Campaigns, email templates, sequences and logs in one place."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./leads-DUQOiY7a.mjs");
var Route$8 = createFileRoute("/marketing/leads")({
	head: () => ({ meta: [
		{ title: "Leads — Vantage CRM" },
		{
			name: "description",
			content: "Browse, filter, and import your lead database."
		},
		{
			property: "og:title",
			content: "Leads — Vantage CRM"
		},
		{
			property: "og:description",
			content: "Browse, filter, and import your lead database."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./sales-7ywE24Rl.mjs");
var Route$7 = createFileRoute("/sales/")({
	head: () => ({ meta: [
		{ title: "Sales Dashboard — Vantage CRM" },
		{
			name: "description",
			content: "Overview of sales opportunities and quotations in Vantage CRM."
		},
		{
			property: "og:title",
			content: "Sales Dashboard — Vantage CRM"
		},
		{
			property: "og:description",
			content: "Overview of sales opportunities and quotations in Vantage CRM."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./opportunities-ByjGM5wg.mjs");
var Route$6 = createFileRoute("/sales/opportunities")({
	head: () => ({ meta: [
		{ title: "Opportunities — Vantage CRM" },
		{
			name: "description",
			content: "Track and manage sales opportunities."
		},
		{
			property: "og:title",
			content: "Opportunities — Vantage CRM"
		},
		{
			property: "og:description",
			content: "Track and manage sales opportunities."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
objectType({
	company_name: stringType().trim().min(1, "Company name is required"),
	enquiry_for: stringType().min(1, "Enquiry type is required"),
	status: stringType().min(1),
	enquiry_date: stringType().regex(/^\d{2}-\d{2}-\d{4}$/, "Use MM-DD-YYYY"),
	modules: arrayType(objectType({
		module_number: numberType().int().positive(),
		module_name: stringType().trim().min(1, "Module name is required"),
		description: stringType(),
		requirements: stringType(),
		estimated_cost: numberType().min(0),
		estimated_days: numberType().int().min(0),
		priority: enumType([
			"LOW",
			"MEDIUM",
			"HIGH"
		]),
		remarks: stringType()
	}))
});
var $$splitComponentImporter$3 = () => import("./quotations-D8rYgoaG.mjs");
var Route$5 = createFileRoute("/sales/quotations")({
	head: () => ({ meta: [
		{ title: "Quotations — Vantage CRM" },
		{
			name: "description",
			content: "Create and manage quotations for sales opportunities."
		},
		{
			property: "og:title",
			content: "Quotations — Vantage CRM"
		},
		{
			property: "og:description",
			content: "Create and manage quotations for sales opportunities."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
objectType({
	quotation_number: stringType().trim().min(1, "Quotation number is required"),
	company_name: stringType().optional(),
	company_id: coerce.number().int().positive("Select a company"),
	quotation_date: stringType().min(1, "Date is required"),
	delivery_timeline: stringType(),
	status: stringType().min(1),
	tax_type: stringType(),
	tax_percentage: coerce.number().min(0),
	discount: coerce.number().min(0),
	packing_charges: coerce.number().min(0),
	terms_conditions: stringType(),
	modules: arrayType(objectType({
		module: stringType().nullable(),
		module_name: stringType().trim().min(1, "Module name is required"),
		description: stringType(),
		requirements: stringType(),
		estimated_cost: numberType().min(0),
		estimated_days: numberType().int().min(0),
		priority: enumType([
			"LOW",
			"MEDIUM",
			"HIGH"
		]),
		remarks: stringType(),
		amount: numberType().min(0)
	}))
});
var AlertDialog = Root2;
var AlertDialogPortal = Portal2;
var AlertDialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay2, {
	className: cn("fixed inset-0 z-50 bg-black/80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props,
	ref
}));
AlertDialogOverlay.displayName = Overlay2.displayName;
var AlertDialogContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg", className),
	...props
})] }));
AlertDialogContent.displayName = Content2.displayName;
var AlertDialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
	...props
});
AlertDialogHeader.displayName = "AlertDialogHeader";
var AlertDialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
AlertDialogFooter.displayName = "AlertDialogFooter";
var AlertDialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title2, {
	ref,
	className: cn("text-lg font-semibold", className),
	...props
}));
AlertDialogTitle.displayName = Title2.displayName;
var AlertDialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Description2, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
AlertDialogDescription.displayName = Description2.displayName;
var AlertDialogAction = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
	ref,
	className: cn(buttonVariants(), className),
	...props
}));
AlertDialogAction.displayName = Action.displayName;
var AlertDialogCancel = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cancel, {
	ref,
	className: cn(buttonVariants({ variant: "outline" }), "mt-2 sm:mt-0", className),
	...props
}));
AlertDialogCancel.displayName = Cancel.displayName;
var Route$4 = createFileRoute("/tasks/")({ component: TasksPage });
var MODULE_OPTIONS = [
	{
		value: "LEAD",
		label: "Lead"
	},
	{
		value: "OPPORTUNITY",
		label: "Opportunity"
	},
	{
		value: "QUOTATION",
		label: "Quotation"
	}
];
var PRIORITY_OPTIONS = [
	{
		value: "LOW",
		label: "Low"
	},
	{
		value: "MEDIUM",
		label: "Medium"
	},
	{
		value: "HIGH",
		label: "High"
	},
	{
		value: "URGENT",
		label: "Urgent"
	}
];
var STATUS_OPTIONS = [
	{
		value: "PENDING",
		label: "Pending"
	},
	{
		value: "IN_PROGRESS",
		label: "In Progress"
	},
	{
		value: "COMPLETED",
		label: "Completed"
	},
	{
		value: "CANCELLED",
		label: "Cancelled"
	}
];
var label = (opts, v) => opts.find((o) => o.value === v)?.label ?? v ?? "-";
var formatTaskDate = (value) => {
	const match = value.match(/^(\d{4})-(\d{2})-(\d{2})$/);
	return match ? `${match[3]}-${match[2]}-${match[1]}` : value;
};
var localToday = () => {
	const d = /* @__PURE__ */ new Date();
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};
var PRIORITY_STYLE = {
	LOW: "bg-slate-100 text-slate-700",
	MEDIUM: "bg-blue-100 text-blue-700",
	HIGH: "bg-amber-100 text-amber-800",
	URGENT: "bg-red-100 text-red-700"
};
var STATUS_STYLE = {
	PENDING: "bg-amber-100 text-amber-800",
	IN_PROGRESS: "bg-blue-100 text-blue-700",
	COMPLETED: "bg-green-100 text-green-700",
	CANCELLED: "bg-slate-100 text-slate-600"
};
var FILTER_TABS = [
	{
		value: "all",
		label: "All"
	},
	{
		value: "today",
		label: "Today"
	},
	{
		value: "upcoming",
		label: "Upcoming"
	},
	{
		value: "recurring",
		label: "Recurring"
	}
];
var isOpen = (t) => t.status === "PENDING" || t.status === "IN_PROGRESS";
var matchesFilter = (t, filter, today) => {
	switch (filter) {
		case "today": return t.followup_date === today;
		case "upcoming": return t.followup_date > today && isOpen(t);
		case "recurring": return t.is_recurring;
		default: return true;
	}
};
function Badge({ text, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex rounded-full px-2 py-0.5 text-xs font-medium", className),
		children: text
	});
}
function TasksPage() {
	const navigate = useNavigate();
	const { data: tasks = [], isLoading } = useTasks();
	const remove = useDeleteTask();
	const [toDelete, setToDelete] = import_react.useState(null);
	const [filter, setFilter] = import_react.useState("all");
	const today = localToday();
	const counts = import_react.useMemo(() => ({
		all: tasks.length,
		today: tasks.filter((t) => matchesFilter(t, "today", today)).length,
		upcoming: tasks.filter((t) => matchesFilter(t, "upcoming", today)).length,
		recurring: tasks.filter((t) => matchesFilter(t, "recurring", today)).length
	}), [tasks, today]);
	const visibleTasks = import_react.useMemo(() => tasks.filter((t) => matchesFilter(t, filter, today)), [
		tasks,
		filter,
		today
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-center justify-between gap-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold",
					children: "Tasks"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Follow-ups and reminders across leads, opportunities and quotations."
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				role: "tablist",
				"aria-label": "Task filters",
				children: FILTER_TABS.map((tab) => {
					const active = filter === tab.value;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						role: "tab",
						"aria-selected": active,
						onClick: () => setFilter(tab.value),
						className: cn("inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-sm font-medium transition-colors", active ? "border-primary bg-primary text-primary-foreground" : "bg-background text-muted-foreground hover:bg-accent hover:text-accent-foreground"),
						children: [tab.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("rounded-full px-1.5 text-xs", active ? "bg-primary-foreground/20" : "bg-muted"),
							children: counts[tab.value]
						})]
					}, tab.value);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				data: visibleTasks,
				columns: [
					{
						key: "followup_date",
						header: "Date",
						filterType: "date",
						cell: (r) => formatTaskDate(r.followup_date),
						filterValue: (r) => r.followup_date
					},
					{
						key: "module",
						header: "Module",
						cell: (r) => label(MODULE_OPTIONS, r.module)
					},
					{
						key: "company_name",
						header: "Company",
						cell: (r) => r.company_name || "-",
						filterValue: (r) => r.company_name || ""
					},
					{
						key: "task_regarding",
						header: "Task Regarding",
						cell: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1.5",
							children: [r.task_regarding === "MISCELLANEOUS" ? "Miscellaneous" : r.task_regarding || "-", r.is_recurring && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, {
								className: "size-3.5 text-muted-foreground",
								"aria-label": "Recurring task"
							})]
						}),
						filterValue: (r) => r.task_regarding || ""
					},
					{
						key: "priority",
						header: "Priority",
						cell: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							text: label(PRIORITY_OPTIONS, r.priority),
							className: PRIORITY_STYLE[r.priority]
						}),
						filterValue: (r) => label(PRIORITY_OPTIONS, r.priority)
					},
					{
						key: "status",
						header: "Status",
						cell: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							text: label(STATUS_OPTIONS, r.status),
							className: STATUS_STYLE[r.status]
						}),
						filterValue: (r) => label(STATUS_OPTIONS, r.status)
					},
					{
						key: "assigned_to",
						header: "Assigned To",
						cell: (r) => r.assigned_to_name ?? "-",
						filterValue: (r) => r.assigned_to_name ?? "Unassigned"
					},
					{
						key: "actions",
						header: "Actions",
						className: "w-24",
						cell: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								className: "size-8",
								"aria-label": `Edit ${r.title}`,
								onClick: () => navigate({
									to: "/tasks/form",
									search: { taskId: String(r.id) }
								}),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								className: "size-8 text-destructive hover:text-destructive",
								"aria-label": `Delete ${r.title}`,
								onClick: () => setToDelete(r),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
							})]
						})
					}
				],
				searchKeys: [
					"title",
					"reference_id",
					"description"
				],
				searchPlaceholder: "Search tasks",
				emptyMessage: isLoading ? "Loading tasks..." : filter === "all" ? "No tasks found." : `No ${filter} tasks.`,
				storageKey: "tasks-table",
				selectionResetKey: filter,
				getRowClassName: (r) => r.followup_date < today && isOpen(r) ? "bg-red-50/60" : "",
				toolbarActions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					className: "h-9 gap-1.5",
					onClick: () => navigate({
						to: "/tasks/form",
						search: { taskId: void 0 }
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "New Task"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: Boolean(toDelete),
				onOpenChange: (o) => !o && setToDelete(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: "Delete task?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogDescription, { children: [
					"“",
					toDelete?.title,
					"” will be removed. This cannot be undone."
				] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
					disabled: remove.isPending,
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
					disabled: remove.isPending,
					className: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
					onClick: async (e) => {
						e.preventDefault();
						if (!toDelete) return;
						try {
							await remove.mutateAsync(toDelete.id);
							toast.success("Task deleted");
							setToDelete(null);
						} catch (err) {
							toast.error(err instanceof Error ? err.message : "Could not delete task");
						}
					},
					children: remove.isPending ? "Deleting..." : "Delete"
				})] })] })
			})
		]
	});
}
var Route$3 = createFileRoute("/marketing/email-campaign/")({ beforeLoad: () => {
	throw redirect({
		to: "/marketing/email-campaign/campaigns",
		search: { create: false }
	});
} });
var $$splitComponentImporter$2 = () => import("./email-campaign.logs-DJpbjeIF.mjs");
var Route$2 = createFileRoute("/marketing/email-campaign/logs")({
	head: () => ({ meta: [{ title: "Email Logs — Vantage CRM" }, {
		name: "description",
		content: "Track all outgoing campaign emails and delivery statuses."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./email-campaign.sequences-CKxWkcmm.mjs");
var Route$1 = createFileRoute("/marketing/email-campaign/sequences")({
	head: () => ({ meta: [{ title: "Sequences — Vantage CRM" }, {
		name: "description",
		content: "Build reusable email sequences from templates."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
objectType({
	name: stringType().trim().min(1, "Sequence name is required"),
	description: stringType(),
	steps: arrayType(objectType({
		templateId: numberType().int().positive("Choose an email template"),
		delayDays: numberType().int().min(0, "Delay cannot be negative"),
		delayMinutes: numberType().int().min(0, "Delay cannot be negative")
	})).min(1, "Add at least one step")
});
var $$splitComponentImporter = () => import("./email-campaign.templates-CLFqTN1J.mjs");
var Route = createFileRoute("/marketing/email-campaign/templates")({
	head: () => ({ meta: [
		{ title: "Message Templates — Vantage CRM" },
		{
			name: "description",
			content: "Create, edit, and preview reusable email and WhatsApp templates."
		},
		{
			property: "og:title",
			content: "Message Templates — Vantage CRM"
		},
		{
			property: "og:description",
			content: "Create, edit, and preview reusable email and WhatsApp templates."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
objectType({
	channel: enumType(["email", "whatsapp"]),
	name: stringType().trim().min(1, "Name is required"),
	subject: stringType().optional(),
	body: stringType().trim().min(1, "Body is required"),
	signature: stringType().optional(),
	logo: anyType().optional(),
	attachment: anyType().optional(),
	waTemplateName: stringType().optional(),
	waLanguage: stringType().optional()
}).superRefine((v, ctx) => {
	if (v.channel === "email" && !v.subject?.trim()) ctx.addIssue({
		code: "custom",
		path: ["subject"],
		message: "Subject is required"
	});
	if (v.channel === "whatsapp" && !v.waTemplateName?.trim()) ctx.addIssue({
		code: "custom",
		path: ["waTemplateName"],
		message: "Meta template name is required"
	});
});
var IndexRoute = Route$22.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$23
});
var AccessControlRoute = Route$21.update({
	id: "/access-control",
	path: "/access-control",
	getParentRoute: () => Route$23
});
var CompanyRoute = Route$20.update({
	id: "/company",
	path: "/company",
	getParentRoute: () => Route$23
});
var CountryRoute = Route$19.update({
	id: "/country",
	path: "/country",
	getParentRoute: () => Route$23
});
var CustomerPoRoute = Route$18.update({
	id: "/customer-po",
	path: "/customer-po",
	getParentRoute: () => Route$23
});
var FinalOfferRoute = Route$17.update({
	id: "/final-offer",
	path: "/final-offer",
	getParentRoute: () => Route$23
});
var LocationRoute = Route$28.update({
	id: "/location",
	path: "/location",
	getParentRoute: () => Route$23
});
var LoginRoute = Route$16.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => Route$23
});
var MarketingRoute = Route$15.update({
	id: "/marketing",
	path: "/marketing",
	getParentRoute: () => Route$23
});
var OrderDashboardRoute = Route$14.update({
	id: "/order-dashboard",
	path: "/order-dashboard",
	getParentRoute: () => Route$23
});
var RegisterRoute = Route$13.update({
	id: "/register",
	path: "/register",
	getParentRoute: () => Route$23
});
var RolesRoute = Route$12.update({
	id: "/roles",
	path: "/roles",
	getParentRoute: () => Route$23
});
var TasksRoute = Route$11.update({
	id: "/tasks",
	path: "/tasks",
	getParentRoute: () => Route$23
});
var UserRoute = Route$10.update({
	id: "/user",
	path: "/user",
	getParentRoute: () => Route$23
});
var MarketingEmailCampaignRoute = Route$9.update({
	id: "/email-campaign",
	path: "/email-campaign",
	getParentRoute: () => MarketingRoute
});
var MarketingLeadsRoute = Route$8.update({
	id: "/leads",
	path: "/leads",
	getParentRoute: () => MarketingRoute
});
var SalesIndexRoute = Route$7.update({
	id: "/sales/",
	path: "/sales/",
	getParentRoute: () => Route$23
});
var SalesOpportunitiesRoute = Route$6.update({
	id: "/sales/opportunities",
	path: "/sales/opportunities",
	getParentRoute: () => Route$23
});
var SalesOrdersRoute = Route$29.update({
	id: "/sales/orders",
	path: "/sales/orders",
	getParentRoute: () => Route$23
});
var SalesQuotationsRoute = Route$5.update({
	id: "/sales/quotations",
	path: "/sales/quotations",
	getParentRoute: () => Route$23
});
var TasksIndexRoute = Route$4.update({
	id: "/",
	path: "/",
	getParentRoute: () => TasksRoute
});
var TasksDashboardRoute = Route$24.update({
	id: "/dashboard",
	path: "/dashboard",
	getParentRoute: () => TasksRoute
});
var TasksFormRoute = Route$26.update({
	id: "/form",
	path: "/form",
	getParentRoute: () => TasksRoute
});
var MarketingEmailCampaignIndexRoute = Route$3.update({
	id: "/",
	path: "/",
	getParentRoute: () => MarketingEmailCampaignRoute
});
var MarketingEmailCampaignCampaignsRoute = Route$25.update({
	id: "/campaigns",
	path: "/campaigns",
	getParentRoute: () => MarketingEmailCampaignRoute
});
var MarketingEmailCampaignLogsRoute = Route$2.update({
	id: "/logs",
	path: "/logs",
	getParentRoute: () => MarketingEmailCampaignRoute
});
var MarketingEmailCampaignSequencesRoute = Route$1.update({
	id: "/sequences",
	path: "/sequences",
	getParentRoute: () => MarketingEmailCampaignRoute
});
var MarketingEmailCampaignTemplatesRoute = Route.update({
	id: "/templates",
	path: "/templates",
	getParentRoute: () => MarketingEmailCampaignRoute
});
var MarketingLeadsFormRoute = Route$27.update({
	id: "/form",
	path: "/form",
	getParentRoute: () => MarketingLeadsRoute
});
var MarketingEmailCampaignRouteChildren = {
	MarketingEmailCampaignCampaignsRoute,
	MarketingEmailCampaignLogsRoute,
	MarketingEmailCampaignSequencesRoute,
	MarketingEmailCampaignTemplatesRoute,
	MarketingEmailCampaignIndexRoute
};
var MarketingEmailCampaignRouteWithChildren = MarketingEmailCampaignRoute._addFileChildren(MarketingEmailCampaignRouteChildren);
var MarketingLeadsRouteChildren = { MarketingLeadsFormRoute };
var MarketingRouteChildren = {
	MarketingEmailCampaignRoute: MarketingEmailCampaignRouteWithChildren,
	MarketingLeadsRoute: MarketingLeadsRoute._addFileChildren(MarketingLeadsRouteChildren)
};
var MarketingRouteWithChildren = MarketingRoute._addFileChildren(MarketingRouteChildren);
var TasksRouteChildren = {
	TasksDashboardRoute,
	TasksFormRoute,
	TasksIndexRoute
};
var rootRouteChildren = {
	IndexRoute,
	AccessControlRoute,
	CompanyRoute,
	CountryRoute,
	CustomerPoRoute,
	FinalOfferRoute,
	LocationRoute,
	LoginRoute,
	MarketingRoute: MarketingRouteWithChildren,
	OrderDashboardRoute,
	RegisterRoute,
	RolesRoute,
	TasksRoute: TasksRoute._addFileChildren(TasksRouteChildren),
	UserRoute,
	SalesOpportunitiesRoute,
	SalesOrdersRoute,
	SalesQuotationsRoute,
	SalesIndexRoute
};
var routeTree = Route$23._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
