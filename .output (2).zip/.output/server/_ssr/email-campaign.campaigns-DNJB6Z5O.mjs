import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as objectType, l as stringType, n as arrayType, s as numberType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/email-campaign.campaigns-DNJB6Z5O.js
var $$splitComponentImporter = () => import("./email-campaign.campaigns-vS2PxKYT.mjs");
var Route = createFileRoute("/marketing/email-campaign/campaigns")({
	validateSearch: (search) => ({ create: search.create === true || search.create === "true" }),
	head: () => ({ meta: [{ title: "Campaigns — Vantage CRM" }, {
		name: "description",
		content: "Create and manage email campaigns."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
objectType({
	name: stringType().trim().min(1, "Campaign name is required"),
	sequenceId: numberType().int().positive("Choose a sequence"),
	leadIds: arrayType(numberType().int().positive()).min(1, "Choose at least one lead")
});
//#endregion
export { Route as t };
