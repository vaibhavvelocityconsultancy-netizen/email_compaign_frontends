import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { N as FileText, R as Download, _ as Plus, s as Trash2, st as ArrowRight, y as Pencil } from "../_libs/lucide-react.mjs";
import { n as DataTable } from "./DataTable-DmCzJ7wu.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Modal } from "./Modal-vFtVKTX9.mjs";
import { f as updateFinalOffer, l as getQuotationById, m as updateQuotationCpo, o as generateFinalOffer, u as getQuotations } from "./quotation-api-BZJz0fjn.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { a as DrawerTitle, i as DrawerHeader, n as DrawerContent, r as DrawerDescription, t as Drawer$1 } from "./drawer-DTNx6Hns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/final-offer-wWW4DgYR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var money = (value) => new Intl.NumberFormat("en-IN", {
	style: "currency",
	currency: "INR",
	maximumFractionDigits: 2
}).format(value || 0);
var dateLabel = (value) => {
	if (!value) return "—";
	const date = new Date(value);
	if (Number.isNaN(date.getTime())) return value;
	return new Intl.DateTimeFormat("en-GB", {
		day: "2-digit",
		month: "2-digit",
		year: "numeric"
	}).format(date);
};
function inputDate(value) {
	if (!value) return "";
	if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return value;
	const match = value.match(/^(\d{2})-(\d{2})-(\d{4})$/);
	return match ? `${match[3]}-${match[1]}-${match[2]}` : "";
}
function finalOfferColumns(onEdit, onGenerate, isGenerating) {
	return [
		{
			key: "companyName",
			header: "Company",
			cell: (offer) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium",
				children: offer.companyName || "—"
			}),
			filterValue: (offer) => offer.companyName || ""
		},
		{
			key: "quotationNumber",
			header: "Quo. No.",
			cell: (offer) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-xs",
				children: offer.quotationNumber || "—"
			}),
			filterValue: (offer) => offer.quotationNumber || ""
		},
		{
			key: "foDate",
			header: "FO Date",
			filterType: "date",
			cell: (offer) => dateLabel(offer.foDate ?? offer.quotationDate),
			filterValue: (offer) => offer.foDate ?? offer.quotationDate
		},
		{
			key: "city",
			header: "City",
			cell: (offer) => offer.city || "—",
			filterValue: (offer) => offer.city || ""
		},
		{
			key: "totalAmount",
			header: "Total",
			filterable: false,
			cell: (offer) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium text-brand",
				children: money(offer.totalAmount)
			}),
			filterValue: (offer) => offer.totalAmount
		},
		{
			key: "docs",
			header: "Docs",
			sortable: false,
			filterable: false,
			cell: (offer) => offer.finalOfferPdf ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				href: offer.finalOfferPdf,
				target: "_blank",
				rel: "noreferrer",
				className: "inline-flex items-center gap-1 text-primary underline-offset-4 hover:underline",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5" }), "PDF"]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground",
				children: "—"
			})
		},
		{
			key: "actions",
			header: "Action",
			sortable: false,
			filterable: false,
			cell: (offer) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-center gap-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					size: "sm",
					variant: "outline",
					onClick: () => onEdit(offer),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "mr-1 size-3.5" }), " Edit"]
				})
			})
		}
	];
}
function FinalOfferPage() {
	const queryClient = useQueryClient();
	const quotationsQuery = useQuery({
		queryKey: ["quotations"],
		queryFn: getQuotations
	});
	const [editingOffer, setEditingOffer] = (0, import_react.useState)(null);
	const [foDate, setFoDate] = (0, import_react.useState)("");
	const [items, setItems] = (0, import_react.useState)([]);
	const [itemDrawerIndex, setItemDrawerIndex] = (0, import_react.useState)(null);
	const updateItem = (index, changes) => {
		setItems((current) => current.map((item, itemIndex) => itemIndex === index ? {
			...item,
			...changes
		} : item));
	};
	const generateMutation = useMutation({
		mutationFn: (quotationId) => generateFinalOffer(quotationId),
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: ["quotations"] });
			toast.success("Final offer generated");
		},
		onError: (error) => toast.error(error.message || "Could not generate final offer")
	});
	const updateMutation = useMutation({
		mutationFn: () => {
			if (!editingOffer) throw new Error("Select a final offer to edit.");
			return updateFinalOffer(editingOffer.id, {
				fo_date: foDate,
				items: items.map((item) => ({
					module: item.module,
					module_name: item.moduleName,
					description: item.description,
					requirements: item.requirements,
					estimated_cost: item.estimatedCost,
					estimated_days: item.estimatedDays,
					priority: item.priority,
					remarks: item.remarks,
					amount: item.amount
				}))
			});
		},
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: ["quotations"] });
			setEditingOffer(null);
			toast.success("Final offer updated");
		},
		onError: (error) => toast.error(error.message || "Could not update final offer")
	});
	const cpoMutation = useMutation({
		mutationFn: (quotationId) => updateQuotationCpo(quotationId, { cpo_created: true }),
		onSuccess: async (quotation) => {
			setEditingOffer((current) => current ? {
				...current,
				cpoCreated: quotation.cpoCreated
			} : current);
			await Promise.all([queryClient.invalidateQueries({ queryKey: ["quotations"] }), queryClient.invalidateQueries({ queryKey: ["cpos"] })]);
			toast.success("Quotation marked for CPO processing");
		},
		onError: (error) => toast.error(error.message || "Could not mark quotation for CPO")
	});
	const openEdit = async (offer) => {
		try {
			const quotation = await getQuotationById(offer.id);
			setEditingOffer(quotation);
			setFoDate(inputDate(quotation.foDate ?? quotation.quotationDate));
			setItems(quotation.items.map((item) => ({ ...item })));
		} catch {
			toast.error("Could not load final offer");
		}
	};
	const columns = finalOfferColumns(openEdit, (offer) => generateMutation.mutate(offer.id), generateMutation.isPending);
	const finalOffers = (quotationsQuery.data ?? []).filter((quotation) => quotation.finalOfferGenerated || quotation.status === "APPROVED");
	const isEmpty = !quotationsQuery.isLoading && finalOffers.length === 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rise",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-mono text-[11px] tracking-wide text-muted-foreground",
					children: "ORDER FLOW"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-3xl font-bold tracking-tight",
					children: "Final Offer"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rise",
				style: { animationDelay: "90ms" },
				children: isEmpty ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center justify-center gap-4 rounded-xl border border-line bg-surface/80 py-12 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid size-12 place-items-center rounded-full bg-brand-soft text-brand",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-6" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl font-semibold",
							children: "No final offers generated yet"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: "Create a quotation and generate the final offer from the sales workflow."
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							className: "gap-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/sales/quotations",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" }), "Open quotations"]
							})
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
					data: finalOffers,
					columns,
					searchKeys: [
						"companyName",
						"quotationNumber",
						"city"
					],
					searchPlaceholder: "Search final offers",
					emptyMessage: quotationsQuery.isLoading ? "Loading final offers…" : "No final offers found.",
					storageKey: "final-offers-table"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
				open: Boolean(editingOffer),
				onClose: () => !updateMutation.isPending && setEditingOffer(null),
				title: `Edit Final Offer${editingOffer ? ` - ${editingOffer.quotationNumber}` : ""}`,
				eyebrow: "FINAL OFFER",
				wide: true,
				children: editingOffer && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "space-y-5 p-5",
					onSubmit: (event) => {
						event.preventDefault();
						updateMutation.mutate();
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "grid gap-x-6 gap-y-3 rounded-md border border-line bg-background p-4 sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs font-medium uppercase text-muted-foreground",
									children: "Company"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1 text-sm font-medium",
									children: editingOffer.companyName || "—"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs font-medium uppercase text-muted-foreground",
									children: "Quotation No."
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1 font-mono text-sm",
									children: editingOffer.quotationNumber
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs font-medium uppercase text-muted-foreground",
									children: "City / State"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1 text-sm",
									children: [editingOffer.city, editingOffer.state].filter(Boolean).join(", ") || "—"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs font-medium uppercase text-muted-foreground",
									children: "Status"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1 text-sm",
									children: editingOffer.status
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs font-medium uppercase text-muted-foreground",
									children: "Current Total"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1 text-sm font-medium",
									children: money(editingOffer.totalAmount)
								})] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block max-w-xs space-y-1.5 text-sm font-medium",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Final Offer Date" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								required: true,
								value: foDate,
								onChange: (event) => setFoDate(event.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
								className: "rounded-lg border border-line bg-surface",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2 p-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-sm font-semibold",
										children: "Items"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "button",
										size: "sm",
										className: "gap-1.5",
										onClick: () => {
											const nextIndex = items.length;
											setItems((current) => [...current, {
												module: null,
												moduleName: "",
												description: "",
												requirements: "",
												estimatedCost: 0,
												estimatedDays: 0,
												priority: "MEDIUM",
												remarks: "",
												amount: 0
											}]);
											setItemDrawerIndex(nextIndex);
										},
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " Add Item"]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "overflow-x-auto",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
										className: "w-full min-w-[1080px] text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
											className: "border-y border-line text-left text-xs text-muted-foreground",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "w-10 px-4 py-2 font-medium",
													children: "#"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "w-56 px-2 py-2 font-medium",
													children: "Item name"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "w-56 px-2 py-2 font-medium",
													children: "Description"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "w-56 px-2 py-2 font-medium",
													children: "Requirements"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "w-28 px-2 py-2 font-medium",
													children: "Cost"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "w-24 px-2 py-2 font-medium",
													children: "Days"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "w-28 px-2 py-2 font-medium",
													children: "Priority"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "w-36 px-2 py-2 font-medium",
													children: "Remarks"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "w-36 px-2 py-2 text-right font-medium",
													children: "Amount"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "w-12 px-2 py-2" })
											] })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [items.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											colSpan: 10,
											className: "px-4 py-8 text-center text-muted-foreground",
											children: "No items added. Click \"Add Item\" to create a custom final offer item."
										}) }), items.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
											className: "border-b border-line last:border-0 align-top",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-4 py-3 text-muted-foreground",
													children: index + 1
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-2 py-3 text-sm text-foreground",
													children: item.moduleName || "—"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-2 py-3 text-sm text-foreground",
													children: item.description || "—"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-2 py-3 text-sm text-foreground",
													children: item.requirements || "—"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-2 py-3 text-right text-sm font-medium text-foreground",
													children: money(Number(item.estimatedCost ?? 0))
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-2 py-3 text-right text-sm text-foreground",
													children: item.estimatedDays ?? 0
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-2 py-3 text-sm text-foreground",
													children: item.priority || "MEDIUM"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-2 py-3 text-sm text-foreground",
													children: item.remarks || "—"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-2 py-3 text-right text-sm font-medium text-foreground",
													children: money(Number(item.amount ?? 0))
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-2 py-3",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center justify-end",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
															type: "button",
															variant: "ghost",
															size: "icon",
															onClick: () => setItemDrawerIndex(index),
															"aria-label": `Edit item ${index + 1}`,
															title: "Edit item",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
															type: "button",
															size: "icon",
															variant: "ghost",
															className: "h-8 w-8",
															"aria-label": `Remove item ${index + 1}`,
															onClick: () => setItems((current) => current.filter((_, rowIndex) => rowIndex !== index)),
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
														})]
													})
												})
											]
										}, `new-${index}`))] })]
									})
								})]
							})
						}),
						itemDrawerIndex !== null && items[itemDrawerIndex] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer$1, {
							open: true,
							onOpenChange: (open) => !open && setItemDrawerIndex(null),
							direction: "right",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DrawerContent, {
								className: "inset-y-0 right-0 bottom-auto left-auto mt-0 h-full w-full max-w-xl rounded-none border-l",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DrawerHeader, {
									className: "border-b border-line text-left",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DrawerTitle, { children: items[itemDrawerIndex].moduleName || "New final offer item" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DrawerDescription, { children: "Edit the details for this final offer item." })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid flex-1 gap-3 overflow-y-auto p-5 sm:grid-cols-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "space-y-1.5 text-sm sm:col-span-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium",
												children: "Item name"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												placeholder: "Inventory Management",
												value: items[itemDrawerIndex].moduleName,
												onChange: (event) => updateItem(itemDrawerIndex, { moduleName: event.target.value })
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "space-y-1.5 text-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium",
												children: "Description"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
												className: "min-h-24 w-full rounded-md border border-input bg-background px-3 py-2 text-sm",
												value: items[itemDrawerIndex].description,
												onChange: (event) => updateItem(itemDrawerIndex, { description: event.target.value })
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "space-y-1.5 text-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium",
												children: "Requirements"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
												className: "min-h-24 w-full rounded-md border border-input bg-background px-3 py-2 text-sm",
												value: items[itemDrawerIndex].requirements,
												onChange: (event) => updateItem(itemDrawerIndex, { requirements: event.target.value })
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "space-y-1.5 text-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium",
												children: "Estimated cost"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "number",
												min: 0,
												step: "0.01",
												value: items[itemDrawerIndex].estimatedCost ?? "",
												onChange: (event) => updateItem(itemDrawerIndex, { estimatedCost: event.target.value === "" ? null : Number(event.target.value) })
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "space-y-1.5 text-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium",
												children: "Estimated days"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "number",
												min: 0,
												step: 1,
												value: items[itemDrawerIndex].estimatedDays ?? "",
												onChange: (event) => updateItem(itemDrawerIndex, { estimatedDays: event.target.value === "" ? null : Number(event.target.value) })
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "space-y-1.5 text-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium",
												children: "Priority"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
												className: "h-10 w-full rounded-md border border-input bg-background px-3 text-sm",
												value: items[itemDrawerIndex].priority,
												onChange: (event) => updateItem(itemDrawerIndex, { priority: event.target.value }),
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "LOW",
														children: "Low"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "MEDIUM",
														children: "Medium"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "HIGH",
														children: "High"
													})
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "space-y-1.5 text-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium",
												children: "Remarks"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												value: items[itemDrawerIndex].remarks,
												onChange: (event) => updateItem(itemDrawerIndex, { remarks: event.target.value })
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "space-y-1.5 text-sm sm:col-span-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium",
												children: "Final offer amount"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "number",
												min: 0,
												step: "0.01",
												value: items[itemDrawerIndex].amount,
												onChange: (event) => updateItem(itemDrawerIndex, { amount: Number(event.target.value) || 0 })
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex justify-end sm:col-span-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "button",
												onClick: () => setItemDrawerIndex(null),
												children: "Done"
											})
										})
									]
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between gap-2 border-t border-line pt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "outline",
									disabled: editingOffer.cpoCreated || cpoMutation.isPending,
									onClick: () => cpoMutation.mutate(editingOffer.id),
									children: editingOffer.cpoCreated ? "Marked for CPO Processing" : cpoMutation.isPending ? "Marking..." : "Mark for CPO Processing"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									type: "button",
									variant: "outline",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/customer-po",
										children: "Open CPO list"
									})
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "outline",
									disabled: updateMutation.isPending,
									onClick: () => setEditingOffer(null),
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									disabled: updateMutation.isPending || !foDate,
									children: updateMutation.isPending ? "Updating..." : "Update Final Offer"
								})]
							})]
						})
					]
				})
			})
		]
	});
}
//#endregion
export { FinalOfferPage as component };
