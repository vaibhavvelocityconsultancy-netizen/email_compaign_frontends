import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as useAuth } from "./auth-C8Fxb5sC.mjs";
import { a as buttonClass, i as PasswordField, n as Field, r as FormError, t as AuthLayout } from "./AuthLayout-BQiOvwrQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-Cl28LaIz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LoginPage({ onSubmit }) {
	const auth = useAuth();
	const navigate = useNavigate();
	const [errors, setErrors] = (0, import_react.useState)({});
	const [formError, setFormError] = (0, import_react.useState)();
	const [loading, setLoading] = (0, import_react.useState)(false);
	async function handleSubmit(event) {
		event.preventDefault();
		const formData = new FormData(event.currentTarget);
		const values = {
			email: String(formData.get("email") ?? "").trim(),
			password: String(formData.get("password") ?? "")
		};
		const next = {};
		if (!/^\S+@\S+\.\S+$/.test(values.email)) next.email = "Enter a valid email address.";
		if (!values.password) next.password = "Enter your password.";
		setErrors(next);
		setFormError(void 0);
		if (Object.keys(next).length) return;
		setLoading(true);
		try {
			if (onSubmit) await onSubmit(values);
			else await auth.login(values.email, values.password);
			await navigate({
				to: "/",
				replace: true
			});
		} catch (error) {
			setFormError(error instanceof Error ? error.message : "Couldn't sign you in. Try again.");
		} finally {
			setLoading(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthLayout, {
		title: "Sign in",
		subtitle: "Enter your details to open your workspace.",
		footer: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
			"New here?",
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/register",
				className: "font-medium text-brand hover:underline",
				children: "Create an account"
			})
		] }),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: handleSubmit,
			noValidate: true,
			className: "space-y-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Email",
					name: "email",
					type: "email",
					autoComplete: "email",
					placeholder: "you@company.com",
					error: errors.email
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordField, {
					label: "Password",
					name: "password",
					autoComplete: "current-password",
					placeholder: "Your password",
					error: errors.password
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormError, { message: formError }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					disabled: loading,
					className: buttonClass,
					children: loading ? "Signing in…" : "Sign in"
				})
			]
		})
	});
}
var SplitComponent = LoginPage;
//#endregion
export { SplitComponent as component };
