import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { k as request } from "./api-DpU7a2cS.mjs";
import { _ as Plus, y as Pencil } from "../_libs/lucide-react.mjs";
import { n as DataTable } from "./DataTable-DmCzJ7wu.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as objectType, l as stringType, o as literalType, r as booleanType, s as numberType, u as unionType } from "../_libs/zod.mjs";
import { s as fieldPresets, t as EntityForm } from "./EntityForm-CgVD88J8.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-CA_Ke5Cp.mjs";
import { n as TABS, t as Route } from "./location-Map1bQKb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/location-CBd9ox58.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ENDPOINTS = {
	country: "/countries/",
	state: "/states/",
	city: "/cities/"
};
var LABEL = {
	country: "Country",
	state: "State",
	city: "City"
};
var name = stringType().trim().min(1, "Enter a name.").max(100, "Keep this under 100 characters.");
var pick = (message) => unionType([numberType(), literalType("")]).refine((v) => v !== "", message);
var schemas = {
	country: objectType({
		name,
		code: stringType().trim().regex(/^([A-Za-z]{2,3})?$/, "Use a 2 or 3 letter code."),
		is_active: booleanType()
	}),
	state: objectType({
		name,
		country: pick("Select a country."),
		is_active: booleanType()
	}),
	city: objectType({
		name,
		state: pick("Select a state."),
		is_active: booleanType()
	})
};
var fetchAll = async (url) => {
	const data = await request(url);
	return Array.isArray(data) ? data : data.results;
};
var statusBadge = (active) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
	className: `rounded-md px-2 py-0.5 text-xs font-medium ${active ? "bg-good/10 text-good" : "bg-muted text-muted-foreground"}`,
	children: active ? "Active" : "Inactive"
});
var SEARCH_KEYS_COUNTRY = ["name", "code"];
var SEARCH_KEYS_NAME = ["name"];
function LocationPage() {
	const { tab } = Route.useSearch();
	const navigate = Route.useNavigate();
	const [countries, setCountries] = import_react.useState([]);
	const [states, setStates] = import_react.useState([]);
	const [cities, setCities] = import_react.useState([]);
	const [loading, setLoading] = import_react.useState(true);
	const [formOpen, setFormOpen] = import_react.useState(false);
	const [editing, setEditing] = import_react.useState(null);
	const [saving, setSaving] = import_react.useState(false);
	const refresh = import_react.useCallback(async () => {
		try {
			const [c, s, ci] = await Promise.all([
				fetchAll(ENDPOINTS.country),
				fetchAll(ENDPOINTS.state),
				fetchAll(ENDPOINTS.city)
			]);
			setCountries(c);
			setStates(s);
			setCities(ci);
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Could not load locations");
		} finally {
			setLoading(false);
		}
	}, []);
	import_react.useEffect(() => {
		refresh();
	}, [refresh]);
	const countryName = import_react.useMemo(() => new Map(countries.map((c) => [c.id, c.name])), [countries]);
	const stateById = import_react.useMemo(() => new Map(states.map((s) => [s.id, s])), [states]);
	const statesPerCountry = import_react.useMemo(() => {
		const map = /* @__PURE__ */ new Map();
		states.forEach((s) => map.set(s.country, (map.get(s.country) ?? 0) + 1));
		return map;
	}, [states]);
	const citiesPerState = import_react.useMemo(() => {
		const map = /* @__PURE__ */ new Map();
		cities.forEach((c) => map.set(c.state, (map.get(c.state) ?? 0) + 1));
		return map;
	}, [cities]);
	const openEdit = (row) => {
		setEditing(row);
		setFormOpen(true);
	};
	const openCreate = () => {
		setEditing(null);
		setFormOpen(true);
	};
	const editButton = (row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		variant: "ghost",
		size: "icon",
		className: "size-8",
		"aria-label": `Edit ${row.name}`,
		onClick: () => openEdit(row),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
	});
	const countryColumns = import_react.useMemo(() => [
		{
			key: "name",
			header: "Country",
			filterable: false,
			cell: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium",
				children: r.name
			})
		},
		{
			key: "code",
			header: "Code",
			filterable: false,
			cell: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-xs",
				children: r.code || "—"
			})
		},
		{
			key: "states",
			header: "States",
			sortable: false,
			filterable: false,
			cell: (r) => statesPerCountry.get(r.id) ?? 0
		},
		{
			key: "is_active",
			header: "Status",
			filterValue: (r) => r.is_active ? "Active" : "Inactive",
			cell: (r) => statusBadge(r.is_active)
		},
		{
			key: "actions",
			header: "",
			className: "w-10",
			cell: editButton
		}
	], [statesPerCountry]);
	const stateColumns = import_react.useMemo(() => [
		{
			key: "name",
			header: "State",
			filterable: false,
			cell: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium",
				children: r.name
			})
		},
		{
			key: "country",
			header: "Country",
			filterValue: (r) => countryName.get(r.country) ?? null,
			cell: (r) => countryName.get(r.country) ?? "—"
		},
		{
			key: "cities",
			header: "Cities",
			sortable: false,
			filterable: false,
			cell: (r) => citiesPerState.get(r.id) ?? 0
		},
		{
			key: "is_active",
			header: "Status",
			filterValue: (r) => r.is_active ? "Active" : "Inactive",
			cell: (r) => statusBadge(r.is_active)
		},
		{
			key: "actions",
			header: "",
			className: "w-10",
			cell: editButton
		}
	], [countryName, citiesPerState]);
	const cityColumns = import_react.useMemo(() => [
		{
			key: "name",
			header: "City",
			filterable: false,
			cell: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium",
				children: r.name
			})
		},
		{
			key: "state",
			header: "State",
			filterValue: (r) => stateById.get(r.state)?.name ?? null,
			cell: (r) => stateById.get(r.state)?.name ?? "—"
		},
		{
			key: "country",
			header: "Country",
			filterValue: (r) => countryName.get(stateById.get(r.state)?.country ?? -1) ?? null,
			cell: (r) => countryName.get(stateById.get(r.state)?.country ?? -1) ?? "—"
		},
		{
			key: "is_active",
			header: "Status",
			filterValue: (r) => r.is_active ? "Active" : "Inactive",
			cell: (r) => statusBadge(r.is_active)
		},
		{
			key: "actions",
			header: "",
			className: "w-10",
			cell: editButton
		}
	], [stateById, countryName]);
	const statusField = fieldPresets.switch("is_active", "Status", {
		defaultValue: true,
		placeholder: "Active"
	});
	const formFields = import_react.useMemo(() => ({
		country: [fieldPresets.row([fieldPresets.text("name", "Country name", {
			required: true,
			placeholder: "India"
		}), fieldPresets.text("code", "ISO code", { placeholder: "IN" })]), statusField],
		state: [
			fieldPresets.searchableSelect("country", "Country", countries.map((c) => ({
				value: c.id,
				label: c.name
			})), {
				required: true,
				colSpan: 2,
				placeholder: "Select country"
			}),
			fieldPresets.text("name", "State name", {
				required: true,
				colSpan: 2,
				placeholder: "Maharashtra"
			}),
			statusField
		],
		city: [
			fieldPresets.searchableSelect("state", "State", states.map((s) => ({
				value: s.id,
				label: `${s.name}, ${countryName.get(s.country) ?? ""}`
			})), {
				required: true,
				colSpan: 2,
				placeholder: "Select state"
			}),
			fieldPresets.text("name", "City name", {
				required: true,
				colSpan: 2,
				placeholder: "Mumbai"
			}),
			statusField
		]
	}), [
		countries,
		states,
		countryName
	]);
	const editingValues = import_react.useMemo(() => {
		if (!editing) return void 0;
		if (tab === "country") {
			const r = countries.find((c) => c.id === editing.id);
			return r && {
				name: r.name,
				code: r.code,
				is_active: r.is_active
			};
		}
		if (tab === "state") {
			const r = states.find((s) => s.id === editing.id);
			return r && {
				name: r.name,
				country: r.country,
				is_active: r.is_active
			};
		}
		const r = cities.find((c) => c.id === editing.id);
		return r && {
			name: r.name,
			state: r.state,
			is_active: r.is_active
		};
	}, [
		editing,
		tab,
		countries,
		states,
		cities
	]);
	const onSubmit = async (values) => {
		setSaving(true);
		try {
			const payload = { ...values };
			if (tab === "country") payload.code = String(values.code ?? "").toUpperCase();
			if (tab === "state") payload.country = Number(values.country);
			if (tab === "city") payload.state = Number(values.state);
			await request(editing ? `${ENDPOINTS[tab]}${editing.id}/` : ENDPOINTS[tab], {
				method: editing ? "PUT" : "POST",
				body: JSON.stringify(payload)
			});
			toast.success(`${LABEL[tab]} ${editing ? "updated" : "added"}`);
			setFormOpen(false);
			await refresh();
		} finally {
			setSaving(false);
		}
	};
	const missingParent = tab === "state" && countries.length === 0 || tab === "city" && states.length === 0;
	const counts = {
		country: countries.length,
		state: states.length,
		city: cities.length
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl font-semibold tracking-tight",
					children: "Locations"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Countries, states and cities used across the app."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					className: "gap-1.5",
					onClick: openCreate,
					disabled: loading || missingParent,
					title: missingParent ? `Add a ${tab === "state" ? "country" : "state"} first` : void 0,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }),
						"Add ",
						LABEL[tab].toLowerCase()
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				value: tab,
				onValueChange: (value) => navigate({ search: { tab: value } }),
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsList, { children: TABS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
						value: t,
						className: "gap-2",
						children: [LABEL[t], /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded bg-muted px-1.5 text-xs text-muted-foreground",
							children: counts[t]
						})]
					}, t)) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "country",
						className: "mt-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
							data: countries,
							columns: countryColumns,
							searchKeys: SEARCH_KEYS_COUNTRY,
							searchPlaceholder: "Search countries",
							emptyMessage: loading ? "Loading…" : "No countries yet. Add the first one.",
							storageKey: "location-country"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "state",
						className: "mt-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
							data: states,
							columns: stateColumns,
							searchKeys: SEARCH_KEYS_NAME,
							searchPlaceholder: "Search states",
							emptyMessage: loading ? "Loading…" : "No states yet. Add a country first, then its states.",
							storageKey: "location-state"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "city",
						className: "mt-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
							data: cities,
							columns: cityColumns,
							searchKeys: SEARCH_KEYS_NAME,
							searchPlaceholder: "Search cities",
							emptyMessage: loading ? "Loading…" : "No cities yet. Add a state first, then its cities.",
							storageKey: "location-city"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityForm, {
				open: formOpen,
				onOpenChange: setFormOpen,
				title: `${editing ? "Edit" : "Add"} ${LABEL[tab].toLowerCase()}`,
				fields: formFields[tab],
				schema: schemas[tab],
				defaultValues: editingValues,
				isEdit: Boolean(editing),
				isLoading: saving,
				size: "sm",
				submitLabel: editing ? "Save changes" : `Add ${LABEL[tab].toLowerCase()}`,
				onSubmit
			}, `${tab}-${editing?.id ?? "new"}`)
		]
	});
}
//#endregion
export { LocationPage as component };
