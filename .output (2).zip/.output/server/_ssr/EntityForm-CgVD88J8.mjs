import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { I as require_jsx_runtime, j as Slot } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as cn, t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { $ as Check, K as ChevronsUpDown, _ as Plus, p as Search, t as X } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, t as Dialog } from "./dialog-BA-nrckz.mjs";
import { a as PopoverTrigger, c as SelectItem, i as PopoverContent, l as SelectTrigger, o as Select, r as Popover, s as SelectContent, t as Checkbox, u as SelectValue } from "./DataTable-DmCzJ7wu.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Switch, t as Label } from "./label-CgdiPI6k.mjs";
import { t as Textarea } from "./textarea-DjqHhWkA.mjs";
import { a as useForm, n as Controller, o as useFormContext, r as FormProvider, t as u } from "../_libs/@hookform/resolvers+[...].mjs";
import { t as _e } from "../_libs/cmdk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/EntityForm-CgVD88J8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Command$1 = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e, {
	ref,
	className: cn("flex h-full w-full flex-col overflow-hidden rounded-md bg-popover text-popover-foreground", className),
	...props
}));
Command$1.displayName = _e.displayName;
var CommandInput = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
	className: "flex items-center border-b px-3",
	"cmdk-input-wrapper": "",
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "mr-2 h-4 w-4 shrink-0 opacity-50" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.Input, {
		ref,
		className: cn("flex h-10 w-full rounded-md bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	})]
}));
CommandInput.displayName = _e.Input.displayName;
var CommandList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.List, {
	ref,
	className: cn("max-h-[300px] overflow-y-auto overflow-x-hidden", className),
	...props
}));
CommandList.displayName = _e.List.displayName;
var CommandEmpty = import_react.forwardRef((props, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.Empty, {
	ref,
	className: "py-6 text-center text-sm",
	...props
}));
CommandEmpty.displayName = _e.Empty.displayName;
var CommandGroup = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.Group, {
	ref,
	className: cn("overflow-hidden p-1 text-foreground [&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-muted-foreground", className),
	...props
}));
CommandGroup.displayName = _e.Group.displayName;
var CommandSeparator = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.Separator, {
	ref,
	className: cn("-mx-1 h-px bg-border", className),
	...props
}));
CommandSeparator.displayName = _e.Separator.displayName;
var CommandItem = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.Item, {
	ref,
	className: cn("relative flex cursor-default gap-2 select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none data-[disabled=true]:pointer-events-none data-[selected=true]:bg-accent data-[selected=true]:text-accent-foreground data-[disabled=true]:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", className),
	...props
}));
CommandItem.displayName = _e.Item.displayName;
var CommandShortcut = ({ className, ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("ml-auto text-xs tracking-widest text-muted-foreground", className),
		...props
	});
};
CommandShortcut.displayName = "CommandShortcut";
var Form = FormProvider;
var FormFieldContext = import_react.createContext(null);
var FormField = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormFieldContext.Provider, {
		value: { name: props.name },
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Controller, { ...props })
	});
};
var useFormField = () => {
	const fieldContext = import_react.useContext(FormFieldContext);
	const itemContext = import_react.useContext(FormItemContext);
	const { getFieldState, formState } = useFormContext();
	if (!fieldContext) throw new Error("useFormField should be used within <FormField>");
	if (!itemContext) throw new Error("useFormField should be used within <FormItem>");
	const fieldState = getFieldState(fieldContext.name, formState);
	const { id } = itemContext;
	return {
		id,
		name: fieldContext.name,
		formItemId: `${id}-form-item`,
		formDescriptionId: `${id}-form-item-description`,
		formMessageId: `${id}-form-item-message`,
		...fieldState
	};
};
var FormItemContext = import_react.createContext(null);
var FormItem = import_react.forwardRef(({ className, ...props }, ref) => {
	const id = import_react.useId();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormItemContext.Provider, {
		value: { id },
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref,
			className: cn("space-y-2", className),
			...props
		})
	});
});
FormItem.displayName = "FormItem";
var FormLabel = import_react.forwardRef(({ className, ...props }, ref) => {
	const { error, formItemId } = useFormField();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
		ref,
		className: cn(error && "text-destructive", className),
		htmlFor: formItemId,
		...props
	});
});
FormLabel.displayName = "FormLabel";
var FormControl = import_react.forwardRef(({ ...props }, ref) => {
	const { error, formItemId, formDescriptionId, formMessageId } = useFormField();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slot, {
		ref,
		id: formItemId,
		"aria-describedby": !error ? `${formDescriptionId}` : `${formDescriptionId} ${formMessageId}`,
		"aria-invalid": !!error,
		...props
	});
});
FormControl.displayName = "FormControl";
var FormDescription = import_react.forwardRef(({ className, ...props }, ref) => {
	const { formDescriptionId } = useFormField();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		ref,
		id: formDescriptionId,
		className: cn("text-[0.8rem] text-muted-foreground", className),
		...props
	});
});
FormDescription.displayName = "FormDescription";
var FormMessage = import_react.forwardRef(({ className, children, ...props }, ref) => {
	const { error, formMessageId } = useFormField();
	const body = error ? String(error?.message ?? "") : children;
	if (!body) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		ref,
		id: formMessageId,
		className: cn("text-[0.8rem] font-medium text-destructive", className),
		...props,
		children: body
	});
});
FormMessage.displayName = "FormMessage";
var sizeClasses = {
	sm: "max-w-md",
	md: "max-w-lg",
	lg: "max-w-2xl",
	xl: "max-w-4xl",
	full: "max-w-6xl"
};
var gridColumnClasses = {
	1: "sm:grid-cols-1",
	2: "sm:grid-cols-2",
	3: "sm:grid-cols-3",
	4: "sm:grid-cols-4",
	5: "sm:grid-cols-5",
	6: "sm:grid-cols-6"
};
function toInputDate(value) {
	if (!value) return "";
	if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return value;
	const match = value.match(/^(\d{2})-(\d{2})-(\d{4})$/);
	return match ? `${match[3]}-${match[2]}-${match[1]}` : value;
}
function fromInputDate(value) {
	if (!value) return "";
	const match = value.match(/^(\d{4})-(\d{2})-(\d{2})$/);
	return match ? `${match[3]}-${match[2]}-${match[1]}` : value;
}
function todayAsDateField() {
	const today = /* @__PURE__ */ new Date();
	return `${String(today.getDate()).padStart(2, "0")}-${String(today.getMonth() + 1).padStart(2, "0")}-${today.getFullYear()}`;
}
function SearchableSelectInput({ label, placeholder, options, value, disabled, onChange }) {
	const [open, setOpen] = import_react.useState(false);
	const selected = options.find((option) => String(option.value) === String(value));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "outline",
				role: "combobox",
				"aria-expanded": open,
				disabled,
				className: cn("w-full justify-between font-normal", !selected && "text-muted-foreground"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: selected?.label ?? placeholder ?? `Select ${label.toLowerCase()}`
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsUpDown, { className: "ml-2 size-4 shrink-0 opacity-50" })]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverContent, {
			className: "w-[var(--radix-popover-trigger-width)] p-0",
			align: "start",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Command$1, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandInput, { placeholder: `Search ${label.toLowerCase()}...` }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandList, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandEmpty, { children: "No results found." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandGroup, { children: options.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
				value: `${option.label} ${String(option.value)}`,
				onSelect: () => {
					onChange(option.value);
					setOpen(false);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: cn("mr-2 size-4", String(value) === String(option.value) ? "opacity-100" : "opacity-0") }), option.label]
			}, String(option.value))) })] })] })
		})]
	});
}
function EntityForm({ open, onOpenChange, title, fields, schema, defaultValues, onSubmit, isEdit = false, submitLabel, cancelLabel = "Cancel", isLoading = false, size = "md", onValueChange, children, headerActions, footerActions, subHeader }) {
	const scrollable = size === "lg" || size === "full";
	const pendingFilesRef = import_react.useRef({});
	const form = useForm({
		resolver: u(schema),
		defaultValues,
		mode: "onChange"
	});
	import_react.useEffect(() => {
		if (!open || !onValueChange) return;
		Object.entries(form.getValues()).forEach(([name, value]) => {
			onValueChange(name, value, form.setValue, form.getValues);
		});
		const subscription = form.watch((values, state) => {
			const name = state.name;
			if (!name) return;
			onValueChange(name, values[name], form.setValue, form.getValues);
		});
		return () => subscription.unsubscribe();
	}, [
		open,
		form,
		onValueChange
	]);
	import_react.useEffect(() => {
		if (!open) return;
		pendingFilesRef.current = {};
		if (isEdit && defaultValues) {
			form.reset(defaultValues);
			return;
		}
		const initialValues = { ...defaultValues };
		const applyDefaults = (items) => {
			items.forEach((field) => {
				if (field.type === "row") {
					applyDefaults(field.fields ?? []);
					return;
				}
				if (initialValues[field.name] !== void 0) return;
				if (field.defaultValue !== void 0) initialValues[field.name] = field.defaultValue;
				else if (field.type === "number" || field.type === "currency") initialValues[field.name] = 0;
				else if (field.type === "switch" || field.type === "checkbox") initialValues[field.name] = false;
				else if (field.type === "date" && field.defaultToToday) initialValues[field.name] = todayAsDateField();
				else initialValues[field.name] = "";
			});
		};
		applyDefaults(fields);
		form.reset(initialValues);
	}, [open, isEdit]);
	const renderFileField = (config, fieldValue, onChange, disabled) => {
		const savedFiles = Array.isArray(fieldValue) ? fieldValue.filter((item) => Boolean(item && typeof item === "object" && "id" in item)) : [];
		const pendingFiles = pendingFilesRef.current[config.name] ?? [];
		const updateFiles = (files) => {
			pendingFilesRef.current[config.name] = files;
			onChange([...savedFiles, ...files]);
		};
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2",
			children: [
				savedFiles.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-1 rounded-md border border-border bg-muted/40 p-2",
					children: savedFiles.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate text-xs",
							children: file.file_name ?? "Saved attachment"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex shrink-0 items-center gap-2",
							children: [(file.file_url || file.file) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: file.file_url ?? file.file,
								target: "_blank",
								rel: "noreferrer",
								className: "text-xs font-medium text-primary underline-offset-4 hover:underline",
								children: "View"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": `Remove ${file.file_name ?? "attachment"}`,
								className: "rounded p-1 text-muted-foreground hover:bg-accent hover:text-destructive",
								onClick: () => onChange([...savedFiles.filter((item) => item.id !== file.id), ...pendingFiles]),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
							})]
						})]
					}, file.id))
				}),
				pendingFiles.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1 rounded-md border border-border bg-brand-soft p-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs font-medium text-muted-foreground",
						children: [pendingFiles.length, " selected"]
					}), pendingFiles.map((file, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate text-xs",
							children: file.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": `Remove ${file.name}`,
							className: "rounded p-1 text-muted-foreground hover:bg-accent hover:text-destructive",
							onClick: () => updateFiles(pendingFiles.filter((_, fileIndex) => fileIndex !== index)),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
						})]
					}, `${file.name}-${file.lastModified}`))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: `entity-file-${config.name}`,
					type: "file",
					multiple: config.multiple,
					disabled: disabled || isLoading,
					className: "sr-only",
					onClick: (event) => {
						event.currentTarget.value = "";
					},
					onChange: (event) => {
						const chosen = Array.from(event.currentTarget.files ?? []);
						if (!config.multiple) {
							updateFiles(chosen.slice(0, 1));
							return;
						}
						const next = [...pendingFilesRef.current[config.name] ?? []];
						chosen.forEach((file) => {
							if (!next.some((item) => item.name === file.name && item.size === file.size)) next.push(file);
						});
						updateFiles(next);
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "outline",
					size: "sm",
					disabled: disabled || isLoading,
					onClick: () => document.getElementById(`entity-file-${config.name}`)?.click(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), config.multiple ? "Add attachments" : "Choose file"]
				})
			]
		});
	};
	const renderField = (config) => {
		if (config.hidden?.(form)) return null;
		if (config.type === "row") {
			const columns = Math.max(1, Math.min(config.columns ?? 2, 6));
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("col-span-full grid grid-cols-1 gap-4 sm:gap-5", gridColumnClasses[columns], config.className),
				children: (config.fields ?? []).map(renderField)
			}, config.key ?? config.name);
		}
		const { name, label, type, placeholder, description, required, disabled = false, options = [], min, max, step, rows, colSpan = 1 } = config;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
			control: form.control,
			name,
			render: ({ field }) => {
				const fieldDisabled = disabled || isLoading;
				const value = field.value;
				const update = (next) => field.onChange(next);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormItem, {
					className: cn("min-w-0 space-y-2", colSpan === 2 && "col-span-full", config.className),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-w-0 items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormLabel, { children: [label, required && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-1 text-destructive",
								children: "*"
							})] }), config.headerActions]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							(type === "text" || type === "name" || type === "email" || type === "tel" || type === "password") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: type === "name" ? "text" : type,
								placeholder,
								disabled: fieldDisabled,
								readOnly: config.readonly,
								value: String(value ?? ""),
								onChange: (event) => update(event.target.value)
							}),
							(type === "number" || type === "currency") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								placeholder,
								disabled: fieldDisabled,
								min,
								max,
								step: step ?? 1,
								value: value === void 0 || value === null ? "" : value,
								onChange: (event) => update(event.target.value === "" ? "" : Number(event.target.value)),
								readOnly: config.readonly
							}),
							type === "textarea" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								placeholder,
								disabled: fieldDisabled,
								rows: rows ?? 3,
								value: String(value ?? ""),
								onChange: (event) => update(event.target.value)
							}),
							type === "file" && renderFileField(config, value, update, disabled),
							type === "date" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								placeholder,
								disabled: fieldDisabled,
								value: toInputDate(typeof value === "string" ? value : ""),
								onChange: (event) => update(fromInputDate(event.target.value))
							}),
							type === "time" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "time",
								placeholder,
								disabled: fieldDisabled,
								value: String(value ?? ""),
								onChange: (event) => update(event.target.value)
							}),
							type === "select" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: value === void 0 || value === null ? "" : String(value),
								onValueChange: (selected) => {
									const option = options.find((item) => String(item.value) === selected);
									update(option?.value ?? selected);
								},
								onOpenChange: config.onOpenChange,
								disabled: fieldDisabled,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: placeholder ?? `Select ${label.toLowerCase()}` }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: options.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: String(option.value),
									children: option.label
								}, String(option.value))) })]
							}),
							type === "searchable-select" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelectInput, {
								label,
								placeholder,
								options,
								value,
								disabled: fieldDisabled,
								onChange: update
							}),
							type === "multi-select" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-2",
								children: options.map((option) => {
									const values = Array.isArray(value) ? value : [];
									const checked = values.some((item) => String(item) === String(option.value));
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex cursor-pointer items-center gap-2 text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
											checked,
											disabled: fieldDisabled,
											onCheckedChange: (isChecked) => update(isChecked ? [...values, option.value] : values.filter((item) => String(item) !== String(option.value)))
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: option.label })]
									}, String(option.value));
								})
							}),
							type === "checkbox" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
									checked: Boolean(value),
									onCheckedChange: update,
									disabled: fieldDisabled
								}), placeholder && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: placeholder
								})]
							}),
							type === "switch" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									checked: Boolean(value),
									onCheckedChange: update,
									disabled: fieldDisabled
								}), placeholder && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-muted-foreground",
									children: placeholder
								})]
							})
						] }) }),
						description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormDescription, { children: description }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormMessage, {})
					]
				});
			}
		}, config.key ?? name);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: cn("w-[calc(100vw-2rem)] gap-0 p-5 sm:p-6", sizeClasses[size], scrollable && "flex max-h-[calc(100dvh-2rem)] flex-col overflow-hidden"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
				className: "shrink-0",
				children: [
					headerActions && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-2",
						children: headerActions
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "pr-8",
						children: title
					}),
					subHeader
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Form, {
				...form,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: form.handleSubmit(async (values) => {
						try {
							await onSubmit(values);
						} catch (error) {
							toast.error(error instanceof Error ? error.message : "Could not save this item");
						}
					}, (errors) => {
						const firstError = Object.entries(errors)[0];
						if (!firstError) {
							toast.error("Please check the required fields");
							return;
						}
						const [name, error] = firstError;
						const message = error && "message" in error ? error.message : void 0;
						toast.error(typeof message === "string" ? message : "Please check the required fields");
						document.querySelector(`[name="${CSS.escape(name)}"]`)?.focus();
					}),
					className: cn("mt-5 space-y-5", scrollable && "flex min-h-0 flex-1 flex-col overflow-hidden"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("grid min-w-0 grid-cols-1 gap-4 sm:grid-cols-2 sm:gap-5", scrollable && "min-h-0 flex-1 overflow-y-auto px-1"),
						children: [fields.map(renderField), children]
					}), footerActions ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
						className: "w-full shrink-0 justify-between gap-2 border-t border-border pt-4 sm:flex-row sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: footerActions
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								onClick: () => onOpenChange(false),
								disabled: isLoading,
								children: cancelLabel
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								disabled: isLoading,
								children: isLoading ? "Saving..." : submitLabel ?? (isEdit ? "Update" : "Create")
							})]
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
						className: "shrink-0 gap-2 border-t border-border pt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: () => onOpenChange(false),
							disabled: isLoading,
							children: cancelLabel
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: isLoading,
							children: isLoading ? "Saving..." : submitLabel ?? (isEdit ? "Update" : "Create")
						})]
					})]
				})
			})]
		})
	});
}
var fieldPresets = {
	file: (name, label, options) => ({
		name,
		label,
		type: "file",
		...options
	}),
	text: (name, label, options) => ({
		name,
		label,
		type: "text",
		...options
	}),
	email: (name, label, options) => ({
		name,
		label,
		type: "email",
		placeholder: "name@example.com",
		...options
	}),
	phone: (name, label, options) => ({
		name,
		label,
		type: "tel",
		placeholder: "Phone number",
		...options
	}),
	currency: (name, label, options) => ({
		name,
		label,
		type: "currency",
		placeholder: "0",
		min: 0,
		...options
	}),
	select: (name, label, optionsList, options) => ({
		name,
		label,
		type: "select",
		options: optionsList,
		...options
	}),
	searchableSelect: (name, label, optionsList, options) => ({
		name,
		label,
		type: "searchable-select",
		options: optionsList,
		...options
	}),
	multiSelect: (name, label, optionsList, options) => ({
		name,
		label,
		type: "multi-select",
		options: optionsList,
		colSpan: 2,
		...options
	}),
	checkbox: (name, label, options) => ({
		name,
		label,
		type: "checkbox",
		...options
	}),
	time: (name, label, options) => ({
		name,
		label,
		type: "time",
		...options
	}),
	textarea: (name, label, options) => ({
		name,
		label,
		type: "textarea",
		rows: 3,
		colSpan: 2,
		...options
	}),
	date: (name, label, options) => ({
		name,
		label,
		type: "date",
		...options
	}),
	password: (name, label, options) => ({
		name,
		label,
		type: "password",
		placeholder: "Enter password",
		...options
	}),
	number: (name, label, options) => ({
		name,
		label,
		type: "number",
		...options
	}),
	switch: (name, label, options) => ({
		name,
		label,
		type: "switch",
		...options
	}),
	name: (name, label, options) => ({
		name,
		label,
		type: "name",
		...options
	}),
	row: (fields, columns = 2) => ({
		name: `row-${fields.map((field) => field.name).join("-")}`,
		label: "",
		type: "row",
		fields,
		columns,
		colSpan: 2
	})
};
//#endregion
export { FormLabel as a, FormItem as i, FormControl as n, FormMessage as o, FormField as r, fieldPresets as s, EntityForm as t };
