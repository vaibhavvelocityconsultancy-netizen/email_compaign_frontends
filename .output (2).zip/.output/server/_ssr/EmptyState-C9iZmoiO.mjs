import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { j as Inbox } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/EmptyState-C9iZmoiO.js
var import_jsx_runtime = require_jsx_runtime();
function EmptyState({ title, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center justify-center px-6 py-14 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid size-11 place-items-center rounded-xl bg-brand-soft text-brand",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inbox, { className: "size-5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 font-display text-sm font-semibold",
				children: title
			}),
			hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-xs text-xs text-muted-foreground",
				children: hint
			})
		]
	});
}
function LoadingRows({ cols }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: Array.from({ length: 5 }).map((_, r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
		className: "border-b border-line last:border-0",
		children: Array.from({ length: cols }).map((_, c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
			className: "px-4 py-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-3.5 animate-pulse rounded bg-muted",
				style: { width: `${55 + (r * 13 + c * 17) % 40}%` }
			})
		}, c))
	}, r)) });
}
//#endregion
export { LoadingRows as n, EmptyState as t };
