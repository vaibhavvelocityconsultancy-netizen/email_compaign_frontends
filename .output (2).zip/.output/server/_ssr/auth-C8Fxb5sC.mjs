import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { r as Recoil_index_8 } from "../_libs/recoil.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-C8Fxb5sC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var authStateAtom = Recoil_index_8({
	key: "authState",
	default: {
		user: null,
		status: "loading"
	}
});
var AuthContext = (0, import_react.createContext)(null);
function useAuth() {
	const context = (0, import_react.useContext)(AuthContext);
	if (!context) throw new Error("useAuth must be used inside AuthProvider");
	return context;
}
//#endregion
export { authStateAtom as n, useAuth as r, AuthContext as t };
