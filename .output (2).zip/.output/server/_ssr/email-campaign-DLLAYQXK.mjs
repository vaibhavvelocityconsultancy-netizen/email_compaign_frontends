import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { b as Link, g as Outlet } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/email-campaign-DLLAYQXK.js
var import_jsx_runtime = require_jsx_runtime();
var TABS = [{
	to: "/marketing/email-campaign/templates",
	label: "Templates"
}, {
	to: "/marketing/email-campaign/sequences",
	label: "Sequences"
}];
var tabCls = "-mb-px border-b-2 px-4 py-2.5 text-sm transition-colors";
var activeCls = { className: "border-brand font-medium text-foreground" };
var inactiveCls = { className: "border-transparent text-muted-foreground hover:text-foreground" };
function EmailCampaignLayout() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-1 border-b border-line",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/marketing/email-campaign/campaigns",
				search: { create: false },
				className: tabCls,
				activeProps: activeCls,
				inactiveProps: inactiveCls,
				children: "Campaigns"
			}), TABS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: t.to,
				className: tabCls,
				activeProps: activeCls,
				inactiveProps: inactiveCls,
				children: t.label
			}, t.to))]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})]
	});
}
//#endregion
export { EmailCampaignLayout as component };
