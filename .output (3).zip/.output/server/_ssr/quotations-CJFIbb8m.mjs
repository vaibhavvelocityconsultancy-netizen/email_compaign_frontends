import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { P as FileCheckCorner, _ as Plus, s as Trash2, y as Pencil } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, t as Dialog } from "./dialog-BA-nrckz.mjs";
import { n as DataTable } from "./DataTable-DmCzJ7wu.mjs";
import { i as listCompanies } from "./company-api-Kb-tmU7s.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as deleteQuotation, c as getNextQuotationNumber, o as generateFinalOffer, p as updateQuotation, r as createQuotation, t as QUOTATION_STATUSES, u as getQuotations } from "./quotation-api-wRNZ3KqO.mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as ConfirmDialog } from "./ConfirmDialog-Rjd0NwWp.mjs";
import { a as enumType, c as objectType, i as coerce, l as stringType, n as arrayType, s as numberType } from "../_libs/zod.mjs";
import { t as StatusBadge } from "./StatusBadge-BMe1mW6r.mjs";
import { i as useFieldArray, o as useFormContext } from "../_libs/@hookform/resolvers+[...].mjs";
import { s as fieldPresets, t as EntityForm } from "./EntityForm-CgVD88J8.mjs";
import { a as DrawerTitle, i as DrawerHeader, n as DrawerContent, r as DrawerDescription, t as Drawer$1 } from "./drawer-DTNx6Hns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quotations-CJFIbb8m.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function computeTotals(v) {
	const subtotal = v.modules.reduce((s, m) => s + (Number(m.amount) || 0), 0);
	const taxable = Math.max(0, subtotal - (Number(v.discount) || 0));
	const tax = taxable * (Number(v.tax_percentage) || 0) / 100;
	return {
		subtotal,
		taxable,
		tax,
		total: taxable + tax + (Number(v.packing_charges) || 0)
	};
}
var money$1 = (n) => n.toLocaleString(void 0, {
	minimumFractionDigits: 2,
	maximumFractionDigits: 2
});
function QuotationModulesTable({ opportunities, disabled }) {
	const { control, register, watch, setValue } = useFormContext();
	const { fields, append, remove } = useFieldArray({
		control,
		name: "modules",
		keyName: "fieldKey"
	});
	const [moduleDrawerIndex, setModuleDrawerIndex] = (0, import_react.useState)(null);
	const opportunityId = watch("opportunity");
	const rows = watch("modules") ?? [];
	(opportunities.find((o) => o.id === opportunityId)?.modules ?? []).filter((m) => m.id);
	const totals = computeTotals({
		modules: rows,
		discount: watch("discount"),
		tax_percentage: watch("tax_percentage"),
		packing_charges: watch("packing_charges")
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "col-span-full space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg border border-line bg-surface",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex i\n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        +tems-center justify-between gap-2 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-semibold",
						children: "Modules"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						size: "sm",
						className: "gap-1.5",
						disabled,
						title: "Add module",
						onClick: () => {
							const nextIndex = fields.length;
							append({
								module: null,
								module_name: "",
								description: "",
								requirements: "",
								estimated_cost: 0,
								estimated_days: 0,
								priority: "MEDIUM",
								remarks: "",
								amount: 0
							});
							setModuleDrawerIndex(nextIndex);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " Add Module"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[640px] text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "border-y border-line text-left text-xs text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "w-10 px-4 py-2 font-medium",
									children: "#"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "w-56 px-2 py-2 font-medium",
									children: "Module name"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "w-56 px-2 py-2 font-medium",
									children: "Description"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "w-56 px-2 py-2 font-medium",
									children: "Requirements"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "w-28 px-2 py-2 font-medium",
									children: "Cost"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "w-24 px-2 py-2 font-medium",
									children: "Days"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "w-28 px-2 py-2 font-medium",
									children: "Priority"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "w-36 px-2 py-2 font-medium",
									children: "Remarks"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "w-36 px-2 py-2 text-right font-medium",
									children: "Amount"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "w-12 px-2 py-2" })
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [fields.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 10,
							className: "px-4 py-8 text-center text-muted-foreground",
							children: "No modules added. Click \"Add Module\" to create a custom quotation module."
						}) }), fields.map((f, i) => {
							const row = rows[i] ?? {};
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-line last:border-0 align-top",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 text-muted-foreground",
										children: i + 1
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-3 text-sm text-foreground",
										children: row.module_name || "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-3 text-sm text-foreground",
										children: row.description || "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-3 text-sm text-foreground",
										children: row.requirements || "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-3 text-right text-sm font-medium text-foreground",
										children: money$1(Number(row.estimated_cost ?? 0))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-3 text-right text-sm text-foreground",
										children: row.estimated_days ?? 0
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-3 text-sm text-foreground",
										children: row.priority || "MEDIUM"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-3 text-sm text-foreground",
										children: row.remarks || "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-3 text-right text-sm font-medium text-foreground",
										children: money$1(Number(row.amount ?? 0))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-end gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "button",
												variant: "ghost",
												size: "icon",
												disabled,
												onClick: () => setModuleDrawerIndex(i),
												"aria-label": `Edit module ${i + 1}`,
												title: "Edit module",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "button",
												variant: "ghost",
												size: "icon",
												className: "text-destructive",
												disabled,
												onClick: () => remove(i),
												"aria-label": `Remove module ${i + 1}`,
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
											})]
										})
									})
								]
							}, f.fieldKey);
						})] })]
					})
				})]
			}),
			moduleDrawerIndex !== null && rows[moduleDrawerIndex] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer$1, {
				open: true,
				onOpenChange: (open) => !open && setModuleDrawerIndex(null),
				direction: "right",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DrawerContent, {
					className: "inset-y-0 right-0 bottom-auto left-auto mt-0 h-full w-full max-w-xl rounded-none border-l",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DrawerHeader, {
						className: "border-b border-line text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DrawerTitle, { children: rows[moduleDrawerIndex].module_name || "New quotation module" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DrawerDescription, { children: "Create a separate module copy for this quotation." })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid flex-1 gap-3 overflow-y-auto p-5 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm sm:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Module name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									disabled,
									placeholder: "Inventory Management",
									...register(`modules.${moduleDrawerIndex}.module_name`)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Description"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									className: "min-h-24 w-full rounded-md border border-input bg-background px-3 py-2 text-sm",
									disabled,
									...register(`modules.${moduleDrawerIndex}.description`)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Requirements"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									className: "min-h-24 w-full rounded-md border border-input bg-background px-3 py-2 text-sm",
									disabled,
									...register(`modules.${moduleDrawerIndex}.requirements`)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Estimated cost"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: 0,
									step: "0.01",
									disabled,
									...register(`modules.${moduleDrawerIndex}.estimated_cost`, { valueAsNumber: true })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Estimated days"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: 0,
									step: 1,
									disabled,
									...register(`modules.${moduleDrawerIndex}.estimated_days`, { valueAsNumber: true })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Priority"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "h-10 w-full rounded-md border border-input bg-background px-3 text-sm",
									disabled,
									...register(`modules.${moduleDrawerIndex}.priority`),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "LOW",
											children: "Low"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "MEDIUM",
											children: "Medium"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "HIGH",
											children: "High"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Remarks"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									disabled,
									...register(`modules.${moduleDrawerIndex}.remarks`)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Quotation amount"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: 0,
									step: "0.01",
									disabled,
									...register(`modules.${moduleDrawerIndex}.amount`, { valueAsNumber: true })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex justify-end sm:col-span-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									onClick: () => setModuleDrawerIndex(null),
									children: "Done"
								})
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ml-auto w-full max-w-xs space-y-1.5 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Subtotal",
						value: money$1(totals.subtotal)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Taxable amount",
						value: money$1(totals.taxable)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Tax",
						value: money$1(totals.tax)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between border-t border-line pt-2 font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono",
							children: money$1(totals.total)
						})]
					})
				]
			})
		]
	});
}
function Row({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex justify-between text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-mono text-foreground",
			children: value
		})]
	});
}
var DELIVERY_OPTIONS = [
	"1 week",
	"2 weeks",
	"3 weeks",
	"4 weeks",
	"6 weeks",
	"8 weeks",
	"12 weeks"
];
var GST_SCHEMES = [{
	value: "INTRA_STATE",
	label: "Gujarat State — CGST 9% + SGST 9%"
}, {
	value: "INTER_STATE",
	label: "Inter State — IGST 18%"
}];
var ADDITIONAL_CHARGE_OPTIONS = [
	"Deployment / Setup Charges",
	"Hosting / Server Charges",
	"Domain Charges",
	"Maintenance & Support",
	"AMC Charges",
	"Third-party Integration Charges",
	"Training Charges",
	"Customization Charges",
	"Other Charges"
];
var schema = objectType({
	quotation_number: stringType().trim().min(1, "Quotation number is required"),
	company_name: stringType().optional(),
	company_id: coerce.number().int().positive("Select a company"),
	quotation_date: stringType().min(1, "Date is required"),
	delivery_timeline: stringType(),
	status: stringType().min(1),
	tax_type: stringType(),
	tax_percentage: coerce.number().min(0),
	discount: coerce.number().min(0),
	packing_charges: coerce.number().min(0),
	terms_conditions: stringType(),
	modules: arrayType(objectType({
		module: stringType().nullable(),
		module_name: stringType().trim().min(1, "Module name is required"),
		description: stringType(),
		requirements: stringType(),
		estimated_cost: numberType().min(0),
		estimated_days: numberType().int().min(0),
		priority: enumType([
			"LOW",
			"MEDIUM",
			"HIGH"
		]),
		remarks: stringType(),
		amount: numberType().min(0)
	}))
});
var money = (n) => n.toLocaleString(void 0, {
	minimumFractionDigits: 2,
	maximumFractionDigits: 2
});
var statusLabel = (s) => QUOTATION_STATUSES.find(([v]) => v === s)?.[1] ?? s;
var toInputDate = (value) => {
	if (!value) return "";
	const match = value.match(/^(\d{2})-(\d{2})-(\d{4})$/);
	return match ? `${match[3]}-${match[1]}-${match[2]}` : value;
};
function QuotationsPage() {
	const qc = useQueryClient();
	const navigate = useNavigate();
	const [formOpen, setFormOpen] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [newQuotationNumber, setNewQuotationNumber] = (0, import_react.useState)("");
	const [deleteTarget, setDeleteTarget] = (0, import_react.useState)(null);
	const [foModalOpen, setFoModalOpen] = (0, import_react.useState)(false);
	const [foScheme, setFoScheme] = (0, import_react.useState)("INTRA_STATE");
	const [foCharges, setFoCharges] = (0, import_react.useState)(ADDITIONAL_CHARGE_OPTIONS.map((label) => ({
		key: label,
		label,
		selected: false,
		amount: 0
	})));
	const quotationsQuery = useQuery({
		queryKey: ["quotations"],
		queryFn: getQuotations
	});
	const companiesQuery = useQuery({
		queryKey: ["companies"],
		queryFn: listCompanies
	});
	const quotations = quotationsQuery.data ?? [];
	const companies = companiesQuery.data ?? [];
	const baseQuotationTotal = editing?.totalAmount ?? 0;
	const additionalChargesTotal = foCharges.filter((charge) => charge.selected && Number(charge.amount) > 0).reduce((sum, charge) => sum + Number(charge.amount || 0), 0);
	const taxableWithCharges = baseQuotationTotal + additionalChargesTotal;
	const gstAmount = taxableWithCharges * (foScheme === "INTRA_STATE" ? 18 : 9) / 100;
	const grandTotalWithCharges = taxableWithCharges + gstAmount;
	const updateFoCharge = (key, changes) => {
		setFoCharges((current) => current.map((charge) => charge.key === key ? {
			...charge,
			...changes
		} : charge));
	};
	const openNewQuotation = async () => {
		try {
			const quotationNumber = await getNextQuotationNumber();
			setEditing(null);
			setNewQuotationNumber(quotationNumber);
			setFormOpen(true);
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Could not generate quotation number");
		}
	};
	const saveMutation = useMutation({
		mutationFn: (v) => {
			const t = computeTotals(v);
			const taxType = v.tax_type;
			const payload = {
				quotation_number: v.quotation_number,
				quotation_date: v.quotation_date,
				opportunity: editing?.opportunity || null,
				selected_company_id: v.company_id,
				status: v.status,
				subtotal: t.subtotal,
				discount: v.discount,
				taxable_amount: t.taxable,
				tax_type: taxType,
				tax_percentage: v.tax_percentage,
				tax_amount: t.tax,
				cgst_amount: taxType === "INTRA_STATE" ? t.tax / 2 : 0,
				sgst_amount: taxType === "INTRA_STATE" ? t.tax / 2 : 0,
				igst_amount: taxType && taxType !== "INTRA_STATE" ? t.tax : 0,
				packing_charges: v.packing_charges,
				total_amount: t.total,
				terms_conditions: v.terms_conditions,
				delivery_timeline: v.delivery_timeline,
				items: v.modules.map((module) => ({
					...module,
					module_name: module.module_name,
					estimated_cost: module.estimated_cost || null,
					estimated_days: module.estimated_days || null
				}))
			};
			return editing ? updateQuotation(editing.id, payload) : createQuotation(payload);
		},
		onSuccess: async () => {
			await qc.invalidateQueries({ queryKey: ["quotations"] });
			setFormOpen(false);
			toast.success(editing ? "Quotation updated" : "Quotation created");
		},
		onError: (e) => toast.error(e.message || "Could not save quotation")
	});
	const deleteMutation = useMutation({
		mutationFn: (q) => deleteQuotation(q.id),
		onSuccess: async () => {
			await qc.invalidateQueries({ queryKey: ["quotations"] });
			setDeleteTarget(null);
			toast.success("Quotation deleted");
		},
		onError: (e) => toast.error(e.message || "Could not delete quotation")
	});
	const foMutation = useMutation({
		mutationFn: (q) => generateFinalOffer(q.id),
		onSuccess: async (quotation) => {
			await qc.invalidateQueries({ queryKey: ["quotations"] });
			setEditing((current) => current ? {
				...current,
				finalOfferGenerated: quotation.finalOfferGenerated,
				finalOfferPdf: quotation.finalOfferPdf
			} : current);
			toast.success("Final offer created");
		},
		onError: (e) => toast.error(e.message || "Could not create final offer")
	});
	const columns = (0, import_react.useMemo)(() => [
		{
			key: "quotationNumber",
			header: "Quotation No",
			cell: (q) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-xs font-medium",
				children: q.quotationNumber
			})
		},
		{
			key: "companyName",
			header: "Company",
			cell: (q) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium",
				children: q.companyName || "—"
			})
		},
		{
			key: "quotationDate",
			header: "Date",
			filterType: "date",
			filterValue: (q) => q.quotationDate,
			cell: (q) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-xs text-muted-foreground",
				children: q.quotationDate ?? "—"
			})
		},
		{
			key: "totalAmount",
			header: "Total",
			className: "text-right",
			headerClassName: "text-right",
			cell: (q) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono",
				children: money(q.totalAmount)
			})
		},
		{
			key: "status",
			header: "Status",
			filterValue: (q) => q.status,
			cell: (q) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: statusLabel(q.status) })
		},
		{
			key: "actions",
			header: "Actions",
			sortable: false,
			filterable: false,
			className: "text-right",
			headerClassName: "text-right",
			cell: (q) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-end gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "grid size-8 place-items-center rounded-md text-muted-foreground hover:bg-background hover:text-foreground",
					"aria-label": `Edit ${q.quotationNumber}`,
					onClick: () => {
						setEditing(q);
						setFormOpen(true);
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "grid size-8 place-items-center rounded-md text-muted-foreground hover:bg-destructive/10 hover:text-destructive",
					"aria-label": `Delete ${q.quotationNumber}`,
					onClick: () => setDeleteTarget(q),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
				})]
			})
		}
	], []);
	const fields = (0, import_react.useMemo)(() => [fieldPresets.row([
		fieldPresets.text("quotation_number", "Quotation number", {
			required: true,
			readonly: true
		}),
		fieldPresets.select("company_id", "Company", companies.map((company) => ({
			value: company.id,
			label: company.name
		})), {
			required: true,
			disabled: companiesQuery.isLoading,
			placeholder: "Select company"
		}),
		fieldPresets.date("quotation_date", "Date", {
			required: true,
			defaultToToday: true
		})
	], 3), fieldPresets.row([fieldPresets.select("delivery_timeline", "Delivery Time", DELIVERY_OPTIONS.map((d) => ({
		value: d,
		label: d
	})), { placeholder: "Select" }), fieldPresets.select("status", "Status", QUOTATION_STATUSES.map(([value, label]) => ({
		value,
		label
	})), { required: true })], 3)], [companies, companiesQuery.isLoading]);
	const defaultValues = editing ? {
		quotation_number: editing.quotationNumber,
		company_id: editing.companyId ?? 0,
		quotation_date: toInputDate(editing.quotationDate),
		delivery_timeline: editing.deliveryTimeline,
		status: editing.status,
		tax_type: editing.taxType,
		tax_percentage: editing.taxPercentage,
		discount: editing.discount,
		packing_charges: editing.packingCharges,
		terms_conditions: editing.termsConditions,
		modules: editing.items.map((i) => ({
			module: i.module,
			module_name: i.moduleName,
			description: i.description,
			requirements: i.requirements,
			estimated_cost: i.estimatedCost ?? 0,
			estimated_days: i.estimatedDays ?? 0,
			priority: i.priority,
			remarks: i.remarks,
			amount: i.amount
		}))
	} : {
		quotation_number: newQuotationNumber,
		company_name: "",
		company_id: 0,
		quotation_date: "",
		delivery_timeline: "",
		status: "DRAFT",
		tax_type: "",
		tax_percentage: 0,
		discount: 0,
		packing_charges: 0,
		terms_conditions: "",
		modules: []
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rise",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-mono text-[11px] tracking-wide text-muted-foreground",
					children: "SALES"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-3xl font-bold tracking-tight",
					children: "Quotations"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rise",
				style: { animationDelay: "80ms" },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
					data: quotations,
					columns,
					searchKeys: [
						"quotationNumber",
						"companyName",
						"status"
					],
					searchPlaceholder: "Search quotations...",
					storageKey: "quotations",
					emptyMessage: quotationsQuery.isLoading ? "Loading quotations…" : "No quotations yet.",
					toolbarActions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "outline",
							className: "h-9 gap-1.5",
							onClick: () => navigate({
								to: "/tasks/form",
								search: {
									taskId: void 0,
									module: "QUOTATION",
									companyId: void 0,
									referenceId: void 0
								}
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " New Task"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							className: "h-9 gap-1.5",
							onClick: () => void openNewQuotation(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " New Quotation"]
						})]
					})
				}), quotationsQuery.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-destructive",
					children: quotationsQuery.error.message
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityForm, {
				open: formOpen,
				onOpenChange: setFormOpen,
				title: editing ? "Edit Quotation" : "New Quotation",
				fields,
				schema,
				defaultValues,
				isEdit: Boolean(editing),
				isLoading: saveMutation.isPending,
				submitLabel: editing ? "Update Quotation" : "Create Quotation",
				size: "full",
				footerActions: editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					size: "sm",
					variant: "outline",
					className: "h-8 gap-1.5",
					disabled: foMutation.isPending || editing.finalOfferGenerated,
					onClick: () => setFoModalOpen(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheckCorner, { className: "size-4" }), foMutation.isPending ? "Creating FO..." : editing.finalOfferGenerated ? "FO already generated" : "Create FO"]
				}) : void 0,
				onSubmit: async (v) => {
					await saveMutation.mutateAsync(v);
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuotationModulesTable, {
					opportunities: [],
					disabled: saveMutation.isPending
				})
			}, editing?.id ?? "new"),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: foModalOpen,
				onOpenChange: setFoModalOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-h-[90dvh] w-[calc(100vw-2rem)] max-w-3xl gap-0 overflow-y-auto p-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, {
						className: "border-b border-line px-5 py-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Generate Final Offer — GST Configuration" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-6 p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-sm font-medium text-foreground",
									children: "Sale Type / GST Scheme *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: foScheme,
									onChange: (event) => setFoScheme(event.target.value),
									className: "h-11 w-full rounded-xl border border-brand bg-transparent px-3 text-base text-foreground outline-none transition focus:border-brand",
									children: GST_SCHEMES.map((scheme) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: scheme.value,
										children: scheme.label
									}, scheme.value))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "text-base font-semibold text-foreground",
										children: "Additional Charges"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-muted-foreground",
										children: "Added only when a price is entered"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "overflow-hidden rounded-xl border border-line bg-background",
									children: foCharges.map((charge) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-[20px_minmax(0,1fr)_140px] items-center gap-3 border-b border-line px-3 py-3 last:border-b-0",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "checkbox",
												checked: charge.selected,
												onChange: () => {
													const nextSelected = !charge.selected;
													updateFoCharge(charge.key, {
														selected: nextSelected,
														amount: nextSelected ? charge.amount : 0
													});
												},
												className: "h-4 w-4 rounded border-line text-brand"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "text-sm font-medium text-foreground",
												children: charge.label
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "number",
												min: "0",
												step: "0.01",
												value: charge.amount,
												disabled: !charge.selected,
												onChange: (event) => {
													const nextAmount = Number(event.target.value) || 0;
													updateFoCharge(charge.key, {
														amount: nextAmount,
														selected: nextAmount > 0 || charge.selected
													});
												},
												className: "h-9 rounded-md border-line bg-background text-right",
												placeholder: "0"
											})
										]
									}, charge.key))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "rounded-xl border border-line bg-muted/20 p-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2 text-sm text-foreground",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Item Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-medium",
												children: ["₹", money(baseQuotationTotal)]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Additional Charges" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-medium",
												children: ["₹", money(additionalChargesTotal)]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Taxable Amount" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-medium",
												children: ["₹", money(taxableWithCharges)]
											})]
										}),
										foScheme === "INTRA_STATE" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "CGST @ 9%" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-medium",
												children: ["₹", money(gstAmount / 2)]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "SGST @ 9%" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-medium",
												children: ["₹", money(gstAmount / 2)]
											})]
										})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "IGST @ 18%" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-medium",
												children: ["₹", money(gstAmount)]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between border-t border-line pt-2 text-base font-semibold",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Grand Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["₹", money(grandTotalWithCharges)] })]
										})
									]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-end gap-3 pt-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "outline",
									onClick: () => setFoModalOpen(false),
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									className: "px-6",
									disabled: !editing || foMutation.isPending,
									onClick: async () => {
										if (!editing) return;
										setFoModalOpen(false);
										await foMutation.mutateAsync(editing);
									},
									children: foMutation.isPending ? "Creating FO..." : "Generate & Download"
								})]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: Boolean(deleteTarget),
				onClose: () => setDeleteTarget(null),
				onConfirm: () => deleteTarget && deleteMutation.mutate(deleteTarget),
				title: "Delete quotation",
				message: `Delete “${deleteTarget?.quotationNumber ?? "this quotation"}”?`,
				loading: deleteMutation.isPending
			})
		]
	});
}
//#endregion
export { QuotationsPage as component };
