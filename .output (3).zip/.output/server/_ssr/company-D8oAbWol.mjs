import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { A as request } from "./api-BXPFd1zj.mjs";
import { _ as Plus, n as Users, y as Pencil } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-BA-nrckz.mjs";
import { n as DataTable } from "./DataTable-DmCzJ7wu.mjs";
import { a as listCompanyContacts, c as updateCompany, i as listCompanies, n as createCompanyContact, t as createCompany } from "./company-api-Kb-tmU7s.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/company-D8oAbWol.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CompanyContactsDialog({ company, onOpenChange, onChanged }) {
	const [contacts, setContacts] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)();
	(0, import_react.useEffect)(() => {
		if (!company) return;
		let active = true;
		setLoading(true);
		setError(void 0);
		listCompanyContacts(company.id).then((results) => {
			if (active) setContacts(results);
		}).catch((loadError) => {
			if (active) setError(loadError instanceof Error ? loadError.message : "Could not load contacts.");
		}).finally(() => {
			if (active) setLoading(false);
		});
		return () => {
			active = false;
		};
	}, [company]);
	async function handleSubmit(event) {
		event.preventDefault();
		if (!company) return;
		const form = event.currentTarget;
		const formData = new FormData(form);
		const data = {
			name: String(formData.get("name") ?? "").trim(),
			designation: String(formData.get("designation") ?? "").trim(),
			phone: String(formData.get("phone") ?? "").trim(),
			email: String(formData.get("email") ?? "").trim(),
			is_primary: formData.get("is_primary") === "on"
		};
		if (!data.name) {
			setError("Contact name is required.");
			return;
		}
		setSaving(true);
		setError(void 0);
		try {
			await createCompanyContact(company.id, data);
			setContacts(await listCompanyContacts(company.id));
			form.reset();
			await onChanged();
			toast.success("Contact added.");
		} catch (saveError) {
			setError(saveError instanceof Error ? saveError.message : "Could not save contact.");
		} finally {
			setSaving(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: Boolean(company),
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sm:max-w-xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: company ? `${company.name} contacts` : "Company contacts" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Manage the people associated with this company." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-h-56 space-y-2 overflow-y-auto",
					children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-4 text-center text-sm text-muted-foreground",
						children: "Loading contacts…"
					}) : contacts.length ? contacts.map((contact) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-start justify-between gap-3 border-b py-2 last:border-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm font-medium",
								children: contact.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									contact.designation,
									contact.email,
									contact.phone
								].filter(Boolean).join(" · ") || "No contact details"
							})]
						}), contact.is_primary && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-primary",
							children: "Primary"
						})]
					}, contact.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-4 text-center text-sm text-muted-foreground",
						children: "No contacts added yet."
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleSubmit,
					className: "space-y-3 border-t pt-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: "Add contact"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									name: "name",
									"aria-label": "Contact name",
									placeholder: "Name",
									required: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									name: "designation",
									"aria-label": "Designation",
									placeholder: "Designation"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									name: "email",
									"aria-label": "Email",
									type: "email",
									placeholder: "Email"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									name: "phone",
									"aria-label": "Phone",
									type: "tel",
									placeholder: "Phone"
								})
							]
						}),
						error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							role: "alert",
							className: "text-sm text-destructive",
							children: error
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: () => onOpenChange(false),
							children: "Close"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: saving || !company,
							children: saving ? "Saving…" : "Add contact"
						})] })
					]
				})
			]
		})
	});
}
function unwrapListResponse(payload) {
	if (Array.isArray(payload)) return payload;
	if (!payload || typeof payload !== "object") return [];
	if (Array.isArray(payload.results)) return payload.results;
	if (Array.isArray(payload.data)) return payload.data;
	return [];
}
function CompanyFormDialog({ open, onOpenChange, company, onSaved }) {
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)();
	const [countries, setCountries] = (0, import_react.useState)([]);
	const [states, setStates] = (0, import_react.useState)([]);
	const [cities, setCities] = (0, import_react.useState)([]);
	const [selectedCountry, setSelectedCountry] = (0, import_react.useState)(company?.country ?? "");
	const [selectedState, setSelectedState] = (0, import_react.useState)(company?.state ?? "");
	const [selectedCity, setSelectedCity] = (0, import_react.useState)(company?.city ?? "");
	const [loadingLocations, setLoadingLocations] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setError(void 0);
		if (!open) return;
		let cancelled = false;
		async function loadLocations() {
			setLoadingLocations(true);
			try {
				const [countryResponse, stateResponse, cityResponse] = await Promise.all([
					request("/countries/"),
					request("/states/"),
					request("/cities/")
				]);
				if (cancelled) return;
				const countryList = unwrapListResponse(countryResponse);
				const stateList = unwrapListResponse(stateResponse);
				const cityList = unwrapListResponse(cityResponse);
				setCountries(countryList);
				setStates(stateList);
				setCities(cityList);
				setSelectedCountry(company?.country ?? "");
				setSelectedState(company?.state ?? "");
				setSelectedCity(company?.city ?? "");
			} catch (loadError) {
				if (!cancelled) toast.error(loadError instanceof Error ? loadError.message : "Could not load location masters");
			} finally {
				if (!cancelled) setLoadingLocations(false);
			}
		}
		loadLocations();
		return () => {
			cancelled = true;
		};
	}, [open, company]);
	const filteredStates = (0, import_react.useMemo)(() => states.filter((state) => selectedCountry === "" ? true : state.country === Number(selectedCountry)), [states, selectedCountry]);
	const filteredCities = (0, import_react.useMemo)(() => cities.filter((city) => selectedState === "" ? true : city.state === Number(selectedState)), [cities, selectedState]);
	async function handleSubmit(event) {
		event.preventDefault();
		const formData = new FormData(event.currentTarget);
		const data = {
			name: String(formData.get("name") ?? "").trim(),
			address: String(formData.get("address") ?? "").trim(),
			city: selectedCity === "" ? null : Number(selectedCity),
			state: selectedState === "" ? null : Number(selectedState),
			pincode: String(formData.get("pincode") ?? "").trim(),
			country: selectedCountry === "" ? null : Number(selectedCountry),
			gst_number: String(formData.get("gst_number") ?? "").trim()
		};
		if (!data.name) {
			setError("Company name is required.");
			return;
		}
		setSaving(true);
		setError(void 0);
		try {
			if (company) await updateCompany(company.id, data);
			else await createCompany(data);
			await onSaved();
			onOpenChange(false);
			toast.success(company ? "Company updated." : "Company added.");
		} catch (submitError) {
			setError(submitError instanceof Error ? submitError.message : "Could not save company.");
		} finally {
			setSaving(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sm:max-w-2xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: company ? "Edit company" : "Add company" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Company details and registration information." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: handleSubmit,
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm font-medium sm:col-span-2",
								children: ["Company name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									name: "name",
									required: true,
									defaultValue: company?.name ?? "",
									autoFocus: true
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm font-medium sm:col-span-2",
								children: ["Address", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									name: "address",
									defaultValue: company?.address ?? ""
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm font-medium",
								children: ["Country", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50",
									value: selectedCountry,
									onChange: (event) => {
										const nextCountry = event.target.value === "" ? "" : Number(event.target.value);
										setSelectedCountry(nextCountry);
										setSelectedState("");
										setSelectedCity("");
									},
									disabled: loadingLocations,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Select country"
									}), countries.map((country) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: country.id,
										children: country.name
									}, country.id))]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm font-medium",
								children: ["State", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50",
									value: selectedState,
									onChange: (event) => {
										const nextState = event.target.value === "" ? "" : Number(event.target.value);
										setSelectedState(nextState);
										setSelectedCity("");
									},
									disabled: loadingLocations || !filteredStates.length,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Select state"
									}), filteredStates.map((state) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: state.id,
										children: state.name
									}, state.id))]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm font-medium",
								children: ["City", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50",
									value: selectedCity,
									onChange: (event) => setSelectedCity(event.target.value === "" ? "" : Number(event.target.value)),
									disabled: loadingLocations || !filteredCities.length,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Select city"
									}), filteredCities.map((city) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: city.id,
										children: city.name
									}, city.id))]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm font-medium",
								children: ["PIN code", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									name: "pincode",
									defaultValue: company?.pincode ?? ""
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1.5 text-sm font-medium",
								children: ["GST number", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									name: "gst_number",
									defaultValue: company?.gst_number ?? ""
								})]
							})
						]
					}),
					error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "alert",
						className: "text-sm text-destructive",
						children: error
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						onClick: () => onOpenChange(false),
						disabled: saving,
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: saving || loadingLocations,
						children: saving ? "Saving…" : company ? "Save changes" : "Add company"
					})] })
				]
			})]
		})
	});
}
var SEARCH_KEYS = [
	"name",
	"city",
	"state",
	"gst_number",
	"pincode"
];
var formatDate = (value) => new Date(value).toLocaleDateString("en-IN", {
	day: "2-digit",
	month: "short",
	year: "numeric"
});
function CompaniesPage() {
	const [companies, setCompanies] = import_react.useState([]);
	const [loading, setLoading] = import_react.useState(true);
	const [formOpen, setFormOpen] = import_react.useState(false);
	const [editing, setEditing] = import_react.useState(null);
	const [contactsFor, setContactsFor] = import_react.useState(null);
	const refresh = import_react.useCallback(async () => {
		try {
			setCompanies(await listCompanies());
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Could not load companies");
		} finally {
			setLoading(false);
		}
	}, []);
	const openCompanyForm = import_react.useCallback((company = null) => {
		setEditing(company);
		setFormOpen(true);
	}, []);
	import_react.useEffect(() => {
		refresh();
	}, [refresh]);
	const columns = import_react.useMemo(() => [
		{
			key: "name",
			header: "Company",
			filterable: false,
			cell: (company) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate font-medium",
					children: company.name
				}), company.gst_number && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs text-muted-foreground",
					children: company.gst_number
				})]
			})
		},
		{
			key: "city",
			header: "Location",
			filterValue: (company) => company.city || null,
			cell: (company) => [company.city_name, company.state_name].filter(Boolean).join(", ") || "—"
		},
		{
			key: "country",
			header: "Country",
			cell: (company) => company.country_name || "—"
		},
		{
			key: "contacts",
			header: "Contacts",
			sortable: false,
			filterable: false,
			cell: (company) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setContactsFor(company),
				className: "inline-flex items-center gap-1.5 rounded-md px-1.5 py-1 text-sm text-primary transition-colors hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4" }), company.contacts_count ?? (company.is_contact ? "View" : "Add")]
			})
		},
		{
			key: "is_active",
			header: "Status",
			filterValue: (company) => company.is_active ? "Active" : "Inactive",
			cell: (company) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `rounded-md px-2 py-0.5 text-xs font-medium ${company.is_active ? "bg-good/10 text-good" : "bg-muted text-muted-foreground"}`,
				children: company.is_active ? "Active" : "Inactive"
			})
		},
		{
			key: "created_at",
			header: "Added",
			filterType: "date",
			filterValue: (company) => company.created_at,
			cell: (company) => formatDate(company.created_at)
		},
		{
			key: "actions",
			header: "",
			className: "w-10",
			cell: (company) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				className: "size-8",
				"aria-label": `Edit ${company.name}`,
				onClick: () => openCompanyForm(company),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
			})
		}
	], []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl font-semibold tracking-tight",
					children: "Companies"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: loading ? "Loading companies…" : `${companies.length} companies`
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					className: "gap-1.5",
					onClick: () => openCompanyForm(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Add company"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				data: companies,
				columns,
				searchKeys: SEARCH_KEYS,
				searchPlaceholder: "Search by name, city or GST number",
				emptyMessage: loading ? "Loading companies…" : "No companies yet. Add your first company.",
				storageKey: "companies",
				pageSize: 20
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompanyFormDialog, {
				open: formOpen,
				onOpenChange: setFormOpen,
				company: editing,
				onSaved: refresh
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompanyContactsDialog, {
				company: contactsFor,
				onOpenChange: (open) => !open && setContactsFor(null),
				onChanged: refresh
			})
		]
	});
}
//#endregion
export { CompaniesPage as component };
