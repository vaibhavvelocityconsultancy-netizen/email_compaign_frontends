import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/location-5Qnv5mtt.js
var TABS = [
	"country",
	"state",
	"city"
];
var $$splitComponentImporter = () => import("./location-DA4Zsidz.mjs");
var Route = createFileRoute("/location")({
	validateSearch: (search) => ({ tab: TABS.includes(search.tab) ? search.tab : "country" }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { TABS as n, Route as t };
