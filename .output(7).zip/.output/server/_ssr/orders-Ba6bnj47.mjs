import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/orders-Ba6bnj47.js
var $$splitComponentImporter = () => import("./orders-qA8I5V94.mjs");
var Route = createFileRoute("/sales/orders")({
	validateSearch: (search) => ({ soId: typeof search.soId === "string" ? search.soId : void 0 }),
	head: () => ({ meta: [{ title: "Sales Orders — Vantage CRM" }, {
		name: "description",
		content: "Review sales orders created from quotations."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
