import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { I as Eye, L as EyeOff, f as ShieldCheck } from "../_libs/lucide-react.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/AuthLayout-BQiOvwrQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AuthLayout({ title, subtitle, footer, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "grid min-h-screen bg-background lg:grid-cols-[minmax(340px,0.9fr)_1.1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "relative hidden min-h-screen overflow-hidden bg-ink px-10 py-9 text-white lg:flex lg:flex-col lg:justify-between xl:px-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute -right-24 top-24 size-80 rounded-full border border-white/10",
					"aria-hidden": "true"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute -right-8 top-40 size-48 rounded-full border border-brand/50",
					"aria-hidden": "true"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/login",
					className: "relative z-10 inline-flex w-fit items-center gap-3",
					"aria-label": "Vantage home",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-10 place-items-center rounded-xl bg-brand font-display text-xl font-bold",
						children: "V"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-display text-lg font-bold leading-none",
						children: "Vantage"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block font-mono text-[10px] tracking-[0.18em] text-white/45",
						children: "CRM · OPS"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative z-10 max-w-lg py-16",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-5 flex items-center gap-2 font-mono text-[11px] tracking-[0.16em] text-brand",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4" }), " PRIVATE WORKSPACE"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-5xl font-semibold leading-[1.08] xl:text-6xl",
							children: "A clearer view of every relationship."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-md text-sm leading-6 text-white/60",
							children: "Keep customer conversations, campaign activity, and follow-ups moving in one place."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-12 grid max-w-md grid-cols-3 border-y border-white/10 py-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-2xl font-semibold",
									children: "01"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-white/45",
									children: "Know the context"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "border-x border-white/10 px-5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-2xl font-semibold",
										children: "02"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-xs text-white/45",
										children: "Plan the next step"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pl-5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-2xl font-semibold",
										children: "03"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-xs text-white/45",
										children: "Keep momentum"
									})]
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "relative z-10 font-mono text-[10px] tracking-[0.14em] text-white/35",
					children: "VANTAGE CUSTOMER OPERATIONS"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "flex min-h-screen flex-col px-5 py-8 sm:px-10 lg:px-14",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-10 flex items-center gap-2 lg:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-9 place-items-center rounded-lg bg-brand font-display text-lg font-bold text-white",
						children: "V"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display font-bold",
						children: "Vantage"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "my-auto w-full max-w-[440px] self-center py-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-[10px] font-medium tracking-[0.18em] text-brand",
									children: "CUSTOMER OPERATIONS"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 font-display text-3xl font-semibold tracking-tight text-foreground",
									children: title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-muted-foreground",
									children: subtitle
								})
							]
						}),
						children,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-8 border-t border-line pt-5 text-center text-sm text-muted-foreground",
							children: footer
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-center font-mono text-[10px] tracking-wide text-muted-foreground/70",
					children: "SECURE ACCESS · VANTAGE CRM"
				})
			]
		})]
	});
}
function Field({ label, name, type = "text", autoComplete, placeholder, error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: name,
				className: "block text-sm font-medium text-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id: name,
				name,
				type,
				autoComplete,
				placeholder,
				"aria-invalid": Boolean(error),
				"aria-describedby": error ? `${name}-error` : void 0,
				className: `h-11 w-full rounded-md border bg-white px-3.5 text-sm outline-none transition focus-visible:ring-2 focus-visible:ring-brand/30 ${error ? "border-destructive" : "border-line focus:border-brand"}`
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				id: `${name}-error`,
				className: "text-xs text-destructive",
				children: error
			})
		]
	});
}
function PasswordField({ label, name, autoComplete, placeholder, error, hint }) {
	const [visible, setVisible] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					htmlFor: name,
					className: "text-sm font-medium text-foreground",
					children: label
				}), hint]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: name,
					name,
					type: visible ? "text" : "password",
					autoComplete,
					placeholder,
					"aria-invalid": Boolean(error),
					"aria-describedby": error ? `${name}-error` : void 0,
					className: `h-11 w-full rounded-md border bg-white px-3.5 pr-11 text-sm outline-none transition focus-visible:ring-2 focus-visible:ring-brand/30 ${error ? "border-destructive" : "border-line focus:border-brand"}`
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setVisible(!visible),
					className: "absolute inset-y-0 right-0 grid w-11 place-items-center text-muted-foreground hover:text-foreground",
					"aria-label": visible ? "Hide password" : "Show password",
					children: visible ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" })
				})]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				id: `${name}-error`,
				className: "text-xs text-destructive",
				children: error
			})
		]
	});
}
function FormError({ message }) {
	if (!message) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "alert",
		className: "rounded-md border border-destructive/25 bg-destructive/5 px-3.5 py-3 text-sm text-destructive",
		children: message
	});
}
var buttonClass = "inline-flex h-11 w-full items-center justify-center rounded-md bg-brand px-4 text-sm font-semibold text-white transition hover:bg-brand/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand/40 disabled:pointer-events-none disabled:opacity-60";
//#endregion
export { buttonClass as a, PasswordField as i, Field as n, FormError as r, AuthLayout as t };
