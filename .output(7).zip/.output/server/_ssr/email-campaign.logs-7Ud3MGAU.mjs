import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { I as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { g as getEmailLogs, m as getBatches, y as getLeads } from "./api-DLBnQGRx.mjs";
import { n as DataTable } from "./DataTable-DmCzJ7wu.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as StatusBadge } from "./StatusBadge-BMe1mW6r.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/email-campaign.logs-7Ud3MGAU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EmailLogsPage() {
	const campaignsQuery = useQuery({
		queryKey: ["campaigns"],
		queryFn: getBatches
	});
	const leadsQuery = useQuery({
		queryKey: ["leads"],
		queryFn: getLeads
	});
	const logsQuery = useQuery({
		queryKey: ["logs"],
		queryFn: getEmailLogs
	});
	const rows = (0, import_react.useMemo)(() => {
		const batchMap = new Map((campaignsQuery.data ?? []).map((campaign) => [campaign.id, campaign.name]));
		const leadMap = new Map((leadsQuery.data ?? []).map((lead) => [lead.id, `Enquiry #${lead.srNo} · ${lead.enquiryFor}`]));
		return (logsQuery.data ?? []).map((log) => ({
			id: log.id,
			batchId: log.batchId,
			batchName: batchMap.get(log.batchId) ?? "Unknown campaign",
			leadId: log.leadId,
			leadName: leadMap.get(log.leadId) ?? "Unknown lead",
			subject: log.subject,
			status: log.status,
			step: log.step,
			sentAt: log.sentAt,
			templateName: log.templateName || "—"
		}));
	}, [
		campaignsQuery.data,
		leadsQuery.data,
		logsQuery.data
	]);
	const columns = (0, import_react.useMemo)(() => [
		{
			key: "batchName",
			header: "Campaign",
			cell: (row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium",
				children: row.batchName
			})
		},
		{
			key: "leadName",
			header: "Lead",
			cell: (row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground",
				children: row.leadName
			})
		},
		{
			key: "subject",
			header: "Subject",
			cell: (row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground",
				children: row.subject
			})
		},
		{
			key: "templateName",
			header: "Template",
			cell: (row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-[11px]",
				children: row.templateName
			})
		},
		{
			key: "step",
			header: "Step",
			cell: (row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "font-mono text-[11px]",
				children: ["#", row.step]
			})
		},
		{
			key: "status",
			header: "Status",
			cell: (row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: row.status })
		},
		{
			key: "sentAt",
			header: "Sent At",
			filterType: "date",
			filterValue: (row) => row.sentAt,
			cell: (row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-[11px] text-muted-foreground",
				children: new Date(row.sentAt).toLocaleString()
			})
		}
	], []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rise flex flex-wrap items-end justify-between gap-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-mono text-[11px] tracking-wide text-muted-foreground",
				children: "COMMUNICATION"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-3xl font-bold tracking-tight",
				children: "Email Logs"
			})] })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rise",
			style: { animationDelay: "80ms" },
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				data: rows,
				columns,
				searchKeys: [
					"batchName",
					"leadName",
					"subject",
					"templateName"
				],
				searchPlaceholder: "Search logs...",
				storageKey: "email-logs",
				emptyMessage: logsQuery.isLoading ? "Loading email logs…" : "No emails have been sent yet."
			})
		})]
	});
}
//#endregion
export { EmailLogsPage as component };
