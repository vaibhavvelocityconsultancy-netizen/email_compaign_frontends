//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-fIQLCXNR.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/__root.tsx",
		children: [
			"/",
			"/access-control",
			"/company",
			"/country",
			"/customer-po",
			"/final-offer",
			"/location",
			"/login",
			"/marketing",
			"/order-dashboard",
			"/register",
			"/roles",
			"/tasks",
			"/user",
			"/sales/opportunities",
			"/sales/orders",
			"/sales/quotations",
			"/sales/"
		],
		preloads: [
			"/vc_email_crm/assets/index-P3q0btM8.js",
			"/vc_email_crm/assets/jsx-runtime-OQpaS_Dv.js",
			"/vc_email_crm/assets/react-dom-Ch54GZ4s.js",
			"/vc_email_crm/assets/Match-5cQgR4sj.js",
			"/vc_email_crm/assets/preload-helper-C-BKGnPd.js",
			"/vc_email_crm/assets/utils-DCvbpOtd.js",
			"/vc_email_crm/assets/link-CAl-Sa9v.js",
			"/vc_email_crm/assets/useMatch-BaG-rLLV.js",
			"/vc_email_crm/assets/matchContext-BLd14XSO.js",
			"/vc_email_crm/assets/useSelector-yWwUHw1M.js",
			"/vc_email_crm/assets/useRouter-FQeUpUVO.js",
			"/vc_email_crm/assets/useNavigate-bMnaDzZT.js",
			"/vc_email_crm/assets/useQuery-CRu0Hu6y.js",
			"/vc_email_crm/assets/useMutation-BT3iAFGa.js",
			"/vc_email_crm/assets/createLucideIcon-5JRSLlvH.js",
			"/vc_email_crm/assets/DataTable-DGJqtzCb.js",
			"/vc_email_crm/assets/x-DFhNn4Ci.js",
			"/vc_email_crm/assets/button-D0UaAm5H.js",
			"/vc_email_crm/assets/input-DoHRrl0J.js",
			"/vc_email_crm/assets/dist-DYAUkNtW.js",
			"/vc_email_crm/assets/api-DG4u4Z-j.js",
			"/vc_email_crm/assets/Modal-BZsGyKA9.js",
			"/vc_email_crm/assets/types-CTeloYrU.js",
			"/vc_email_crm/assets/quotation-api-B2sSVG3t.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/vc_email_crm/assets/index-P3q0btM8.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/routes-DMYKkWuy.js",
			"/vc_email_crm/assets/arrow-up-right-Dv0z1hcs.js",
			"/vc_email_crm/assets/StatCard-Ef07sW3W.js"
		]
	},
	"/company": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/company.tsx",
		children: void 0,
		preloads: ["/vc_email_crm/assets/company-R8HqgBiC.js", "/vc_email_crm/assets/company-api-B2BIvlmq.js"]
	},
	"/country": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/country.tsx",
		children: void 0,
		preloads: ["/vc_email_crm/assets/country-C4DJTpz-.js"]
	},
	"/customer-po": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/customer-po.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/customer-po-Cjhq4aYL.js",
			"/vc_email_crm/assets/file-text-CLhUqrtI.js",
			"/vc_email_crm/assets/shopping-cart-DWwt8raz.js",
			"/vc_email_crm/assets/upload-CDjpU4YU.js"
		]
	},
	"/final-offer": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/final-offer.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/final-offer-BzCvQ_O5.js",
			"/vc_email_crm/assets/file-text-CLhUqrtI.js",
			"/vc_email_crm/assets/drawer-DhfOT8D-.js"
		]
	},
	"/location": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/location.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/location-BoP-DWD_.js",
			"/vc_email_crm/assets/EntityForm-C8_UwkFl.js",
			"/vc_email_crm/assets/tabs-CAZmVI6D.js"
		]
	},
	"/login": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/login.tsx",
		children: void 0,
		preloads: ["/vc_email_crm/assets/login-cgGzKroo.js", "/vc_email_crm/assets/AuthLayout-DSOVgeVV.js"]
	},
	"/marketing": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/marketing.tsx",
		children: ["/marketing/email-campaign", "/marketing/leads"],
		preloads: [
			"/vc_email_crm/assets/marketing-BnimWJ1U.js",
			"/vc_email_crm/assets/EmptyState-DDcb9rny.js",
			"/vc_email_crm/assets/StatCard-Ef07sW3W.js",
			"/vc_email_crm/assets/StatusBadge-CxXEaw6p.js"
		]
	},
	"/order-dashboard": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/order-dashboard.tsx",
		children: void 0,
		preloads: ["/vc_email_crm/assets/order-dashboard-C5vK-EGn.js"]
	},
	"/register": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/register.tsx",
		children: void 0,
		preloads: ["/vc_email_crm/assets/register-BtKi7dSL.js", "/vc_email_crm/assets/AuthLayout-DSOVgeVV.js"]
	},
	"/tasks": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/tasks.tsx",
		children: [
			"/tasks/dashboard",
			"/tasks/form",
			"/tasks/"
		],
		preloads: ["/vc_email_crm/assets/tasks-OfWf9uOh.js"]
	},
	"/marketing/email-campaign": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/marketing/email-campaign.tsx",
		children: [
			"/marketing/email-campaign/campaigns",
			"/marketing/email-campaign/logs",
			"/marketing/email-campaign/sequences",
			"/marketing/email-campaign/templates",
			"/marketing/email-campaign/"
		],
		preloads: ["/vc_email_crm/assets/email-campaign-Y2LS2j8f.js"]
	},
	"/marketing/leads": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/marketing/leads.tsx",
		children: ["/marketing/leads/form"],
		preloads: ["/vc_email_crm/assets/leads-Dqi7MuOf.js", "/vc_email_crm/assets/upload-CDjpU4YU.js"]
	},
	"/sales/opportunities": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/sales/opportunities.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/opportunities-CBHkXGVo.js",
			"/vc_email_crm/assets/EntityForm-C8_UwkFl.js",
			"/vc_email_crm/assets/file-text-CLhUqrtI.js",
			"/vc_email_crm/assets/company-api-B2BIvlmq.js",
			"/vc_email_crm/assets/drawer-DhfOT8D-.js",
			"/vc_email_crm/assets/StatusBadge-CxXEaw6p.js"
		]
	},
	"/sales/orders": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/sales/orders.tsx",
		children: void 0,
		preloads: ["/vc_email_crm/assets/orders-BPYkWads.js", "/vc_email_crm/assets/company-api-B2BIvlmq.js"]
	},
	"/sales/quotations": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/sales/quotations.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/quotations-Co2FkNbZ.js",
			"/vc_email_crm/assets/EntityForm-C8_UwkFl.js",
			"/vc_email_crm/assets/company-api-B2BIvlmq.js",
			"/vc_email_crm/assets/drawer-DhfOT8D-.js",
			"/vc_email_crm/assets/StatusBadge-CxXEaw6p.js"
		]
	},
	"/tasks/dashboard": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/tasks/dashboard.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/dashboard-BAsOMWB2.js",
			"/vc_email_crm/assets/calendar-days-5GeYs19G.js",
			"/vc_email_crm/assets/target-BOizoJuW.js",
			"/vc_email_crm/assets/triangle-alert-DsgdhYG4.js"
		]
	},
	"/tasks/form": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/tasks/form.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/form-rJXeR9uR.js",
			"/vc_email_crm/assets/save-CK_SGmB_.js",
			"/vc_email_crm/assets/eye-4pwqTTee.js",
			"/vc_email_crm/assets/textarea-CY-dYm-r.js"
		]
	},
	"/sales/": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/sales/index.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/sales-DLPnmiQo.js",
			"/vc_email_crm/assets/arrow-up-right-Dv0z1hcs.js",
			"/vc_email_crm/assets/file-text-CLhUqrtI.js",
			"/vc_email_crm/assets/shopping-cart-DWwt8raz.js",
			"/vc_email_crm/assets/target-BOizoJuW.js"
		]
	},
	"/marketing/email-campaign/campaigns": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/marketing/email-campaign.campaigns.tsx",
		children: void 0,
		preloads: ["/vc_email_crm/assets/email-campaign.campaigns-MhqnBpg8.js", "/vc_email_crm/assets/eye-4pwqTTee.js"]
	},
	"/marketing/email-campaign/logs": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/marketing/email-campaign.logs.tsx",
		children: void 0,
		preloads: ["/vc_email_crm/assets/email-campaign.logs-0pf2GHcH.js"]
	},
	"/marketing/email-campaign/sequences": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/marketing/email-campaign.sequences.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/email-campaign.sequences-mqbUvoMX.js",
			"/vc_email_crm/assets/EntityForm-C8_UwkFl.js",
			"/vc_email_crm/assets/triangle-alert-DsgdhYG4.js"
		]
	},
	"/marketing/email-campaign/templates": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/marketing/email-campaign.templates.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/email-campaign.templates-DcYDk-YO.js",
			"/vc_email_crm/assets/EntityForm-C8_UwkFl.js",
			"/vc_email_crm/assets/tabs-CAZmVI6D.js"
		]
	},
	"/marketing/leads/form": {
		filePath: "C:/Users/ADMIN/OneDrive/Desktop/email/email_compaign_frontends/src/routes/marketing/leads.form.tsx",
		children: void 0,
		preloads: [
			"/vc_email_crm/assets/leads.form-DFiCubrn.js",
			"/vc_email_crm/assets/save-CK_SGmB_.js",
			"/vc_email_crm/assets/target-BOizoJuW.js",
			"/vc_email_crm/assets/company-api-B2BIvlmq.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
